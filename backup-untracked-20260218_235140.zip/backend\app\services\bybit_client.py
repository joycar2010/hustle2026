"""Bybit V5 API client"""
import hmac
import hashlib
import time
from typing import Dict, Any, Optional
import aiohttp
from app.core.config import settings


class BybitV5Client:
    """Async client for Bybit V5 API"""

    def __init__(self, api_key: str = "", api_secret: str = ""):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = settings.BYBIT_API_BASE
        self.session: Optional[aiohttp.ClientSession] = None
        self.recv_window = "5000"

    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create aiohttp session"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession()
        return self.session

    async def close(self):
        """Close the session"""
        if self.session and not self.session.closed:
            await self.session.close()

    def _sign(self, timestamp: str, params: str) -> str:
        """Generate HMAC SHA256 signature for V5 API"""
        param_str = timestamp + self.api_key + self.recv_window + params
        return hmac.new(
            self.api_secret.encode("utf-8"),
            param_str.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    async def _request(
        self,
        method: str,
        endpoint: str,
        signed: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        """Make HTTP request to Bybit API"""
        url = f"{self.base_url}{endpoint}"
        headers = {"Content-Type": "application/json"}

        if signed:
            timestamp = str(int(time.time() * 1000))

            # Prepare params string for signature
            if method == "GET":
                params = kwargs.get("params", {})
                param_str = "&".join([f"{k}={v}" for k, v in sorted(params.items())])
            else:
                import json
                param_str = json.dumps(kwargs.get("json", {})) if kwargs.get("json") else ""

            signature = self._sign(timestamp, param_str)

            headers.update({
                "X-BAPI-API-KEY": self.api_key,
                "X-BAPI-TIMESTAMP": timestamp,
                "X-BAPI-SIGN": signature,
                "X-BAPI-RECV-WINDOW": self.recv_window,
            })

        session = await self._get_session()

        try:
            async with session.request(method, url, headers=headers, **kwargs) as resp:
                data = await resp.json()

                if data.get("retCode") != 0:
                    raise Exception(f"Bybit API error: {data.get('retMsg', 'Unknown error')}")

                return data.get("result", {})
        except aiohttp.ClientError as e:
            raise Exception(f"Network error: {str(e)}")

    # Public endpoints (no authentication required)

    async def get_server_time(self) -> Dict[str, Any]:
        """Get server time"""
        return await self._request("GET", "/v5/market/time")

    async def get_tickers(self, category: str, symbol: str) -> Dict[str, Any]:
        """Get latest ticker information

        Args:
            category: Product type (linear, inverse, spot, option)
            symbol: Symbol name (e.g., XAUUSDT)
        """
        params = {"category": category, "symbol": symbol}
        return await self._request("GET", "/v5/market/tickers", params=params)

    async def get_orderbook(self, category: str, symbol: str, limit: int = 25) -> Dict[str, Any]:
        """Get orderbook data"""
        params = {"category": category, "symbol": symbol, "limit": limit}
        return await self._request("GET", "/v5/market/orderbook", params=params)

    async def get_klines(
        self,
        category: str,
        symbol: str,
        interval: str,
        limit: int = 200,
        start: Optional[int] = None,
        end: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Get kline/candlestick data"""
        params = {
            "category": category,
            "symbol": symbol,
            "interval": interval,
            "limit": limit,
        }
        if start:
            params["start"] = start
        if end:
            params["end"] = end

        return await self._request("GET", "/v5/market/kline", params=params)

    async def get_funding_rate(
        self,
        category: str,
        symbol: str,
        limit: int = 1,
    ) -> Dict[str, Any]:
        """Get funding rate history"""
        params = {"category": category, "symbol": symbol, "limit": limit}
        return await self._request("GET", "/v5/market/funding/history", params=params)

    # Private endpoints (authentication required)

    async def get_wallet_balance(self, account_type: str = "UNIFIED") -> Dict[str, Any]:
        """Get wallet balance

        Args:
            account_type: Account type (UNIFIED, CONTRACT, SPOT)
        """
        params = {"accountType": account_type}
        return await self._request("GET", "/v5/account/wallet-balance", signed=True, params=params)

    async def get_positions(
        self,
        category: str,
        symbol: Optional[str] = None,
        settle_coin: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get position information"""
        params = {"category": category}
        if symbol:
            params["symbol"] = symbol
        if settle_coin:
            params["settleCoin"] = settle_coin

        return await self._request("GET", "/v5/position/list", signed=True, params=params)

    async def get_account_info(self) -> Dict[str, Any]:
        """Get account information including risk ratio"""
        return await self._request("GET", "/v5/account/info", signed=True)

    async def get_transaction_log(
        self,
        account_type: str = "UNIFIED",
        category: Optional[str] = None,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """Get transaction log (P&L history)"""
        params = {"accountType": account_type, "limit": limit}
        if category:
            params["category"] = category
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time

        return await self._request("GET", "/v5/account/transaction-log", signed=True, params=params)

    async def get_fee_rate(self, category: str, symbol: str) -> Dict[str, Any]:
        """Get trading fee rate"""
        params = {"category": category, "symbol": symbol}
        return await self._request("GET", "/v5/account/fee-rate", signed=True, params=params)

    async def place_order(
        self,
        category: str,
        symbol: str,
        side: str,
        order_type: str,
        qty: str,
        price: Optional[str] = None,
        time_in_force: str = "GTC",
        reduce_only: bool = False,
        close_on_trigger: bool = False,
    ) -> Dict[str, Any]:
        """Place a new order"""
        data = {
            "category": category,
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "qty": qty,
        }

        if order_type == "Limit":
            if price is None:
                raise ValueError("Price is required for Limit orders")
            data["price"] = price
            data["timeInForce"] = time_in_force

        if reduce_only:
            data["reduceOnly"] = True

        if close_on_trigger:
            data["closeOnTrigger"] = True

        return await self._request("POST", "/v5/order/create", signed=True, json=data)

    async def cancel_order(
        self,
        category: str,
        symbol: str,
        order_id: Optional[str] = None,
        order_link_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Cancel an active order"""
        if not order_id and not order_link_id:
            raise ValueError("Either order_id or order_link_id is required")

        data = {"category": category, "symbol": symbol}
        if order_id:
            data["orderId"] = order_id
        if order_link_id:
            data["orderLinkId"] = order_link_id

        return await self._request("POST", "/v5/order/cancel", signed=True, json=data)

    async def get_order(
        self,
        category: str,
        symbol: str,
        order_id: Optional[str] = None,
        order_link_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Query order status"""
        if not order_id and not order_link_id:
            raise ValueError("Either order_id or order_link_id is required")

        params = {"category": category, "symbol": symbol}
        if order_id:
            params["orderId"] = order_id
        if order_link_id:
            params["orderLinkId"] = order_link_id

        return await self._request("GET", "/v5/order/realtime", signed=True, params=params)

    async def get_open_orders(
        self,
        category: str,
        symbol: Optional[str] = None,
        limit: int = 50,
    ) -> Dict[str, Any]:
        """Get all open orders"""
        params = {"category": category, "limit": limit}
        if symbol:
            params["symbol"] = symbol

        return await self._request("GET", "/v5/order/realtime", signed=True, params=params)

    async def cancel_all_orders(
        self,
        category: str,
        symbol: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Cancel all open orders"""
        data = {"category": category}
        if symbol:
            data["symbol"] = symbol

        return await self._request("POST", "/v5/order/cancel-all", signed=True, json=data)
