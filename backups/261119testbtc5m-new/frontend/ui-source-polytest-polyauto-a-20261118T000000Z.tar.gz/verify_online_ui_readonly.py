"""Read-only deployed UI verification. Never click settings/save/trading controls."""
import asyncio
import json
from pathlib import Path
import sys
import time

from playwright.async_api import async_playwright

HERE=Path(__file__).resolve().parent


async def main():
    base=(sys.argv[1] if len(sys.argv)>1 else 'https://polytest.hustle2026.xyz').rstrip('/')
    errors=[];mutations=[];data_requests=[];warnings=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
        page=await browser.new_page(viewport={'width':1440,'height':1050})
        page.on('pageerror',lambda error:errors.append(str(error)))
        def track(request):
            if '/api/' in request.url:
                if request.method not in {'GET','HEAD','OPTIONS'}:mutations.append({'method':request.method,'url':request.url.split('?')[0]})
                if '/api/orders' in request.url or '/api/pnl/daily' in request.url:data_requests.append(request.url.split('/api/',1)[-1])
        page.on('request',track)
        await page.goto(base+'/?readonly-p2p3-verification='+str(int(time.time())),wait_until='domcontentloaded',timeout=60000)
        panel=page.get_by_role('region',name='PAPER 同条件对照')
        await panel.wait_for(timeout=45000)
        await page.locator('.kpi-strip').get_by_text('模拟账户余额',exact=True).wait_for(timeout=45000)
        response=await page.request.get(base+'/api/state',timeout=20000)
        assert response.ok, response.status
        state=await response.json()
        assert state.get('active_lane')=='paper',state.get('active_lane')
        lane=(state.get('mode_split') or {}).get('paper') or {}
        assert lane.get('source')=='isolated_p3_public_paper',lane.get('source')
        assert lane.get('group')=='FILTERED',lane.get('group')
        cards=page.locator('.kpi-strip')
        assert 'LIVE' not in await cards.inner_text()
        await cards.locator('.kpi-card').filter(has_text='模拟账户余额').click()
        modal=page.locator('.data-modal-dialog')
        await modal.get_by_text('PAPER 模拟资金 / FILTERED 独立账本',exact=True).wait_for()
        await modal.locator('.data-modal-close').click()
        await cards.locator('.kpi-card').filter(has_text='模拟持仓成本').click()
        await modal.get_by_text('PAPER 当前持仓 / FILTERED',exact=True).wait_for()
        assert '链上持仓' not in await modal.inner_text()
        await modal.locator('.data-modal-close').click()
        await cards.locator('.kpi-card').filter(has_text='今日损益').click()
        await modal.locator('.positions-sync-note').filter(has_text='FILTERED 独立 Paper 账本').wait_for(timeout=30000)
        await modal.locator('.data-modal-close').click()
        await page.locator('.pencil-metric').filter(has_text='全部订单').click()
        await modal.get_by_text('BTC PAPER / 模拟成交记录',exact=True).wait_for()
        await modal.locator('.data-modal-close').click()
        await page.get_by_role('button',name='查看BTC模拟数据',exact=True).click()
        await modal.get_by_text('BTC / PAPER 模拟数据',exact=True).wait_for()
        assert 'Live 最近记录' not in await modal.inner_text()
        await modal.locator('.data-modal-close').click()
        await page.locator('.strategy-menu > summary').click()
        settings=page.locator('.strategy-menu-popover')
        await settings.wait_for(state='visible')
        settings_size=await settings.evaluate('(node)=>{const b=node.getBoundingClientRect();return {width:b.width,height:b.height,left:b.left,top:b.top,right:b.right,bottom:b.bottom,viewportWidth:innerWidth,viewportHeight:innerHeight,fields:node.querySelectorAll("input,select").length}}')
        if settings_size['width']<600 or settings_size['left']<-1 or settings_size['right']>1441 or settings_size['bottom']>1051:
            warnings.append('Strategy settings require desktop width/height correction.')
        await page.screenshot(path=str(HERE.parent/'online-p2p3-settings.png'),full_page=True)
        close_settings=page.get_by_role('button',name='关闭策略管理',exact=True)
        if await close_settings.is_visible():await close_settings.click()
        else:await page.locator('.strategy-menu > summary').click()
        agent_images=await page.locator('.openclaw-agent-dock .agent-avatar img').evaluate_all('(nodes)=>nodes.map(n=>({src:n.getAttribute("src"),loaded:n.complete&&n.naturalWidth>0}))')
        assert len(agent_images)==8 and all(row['loaded'] for row in agent_images),agent_images
        await page.locator('.openclaw-agent-dock .agent-card').first.focus()
        await page.keyboard.press('Enter')
        await modal.wait_for(state='visible')
        assert 'OpenClaw' in await modal.inner_text()
        await modal.locator('.data-modal-close').click()
        media_path=await page.locator('video').get_attribute('src')
        media=await page.request.head(base+media_path,timeout=20000)
        assert media.ok,media.status
        await panel.locator('.paper-comparison-method summary').click()
        assert '48h 可复核' in await panel.inner_text() and '72h 计划结束' in await panel.inner_text()
        await page.screenshot(path=str(HERE.parent/'online-p2p3-desktop.png'),full_page=True)
        await page.set_viewport_size({'width':390,'height':844})
        await page.locator('.strategy-menu > summary').click()
        await settings.wait_for(state='visible')
        mobile_settings=await settings.evaluate('(node)=>{const r=node.getBoundingClientRect();return {width:r.width,height:r.height,left:r.left,right:r.right,top:r.top,bottom:r.bottom,scroll:node.scrollWidth,client:node.clientWidth}}')
        assert mobile_settings['left']>=9 and mobile_settings['right']<=381 and mobile_settings['top']>=11 and mobile_settings['bottom']<=833,mobile_settings
        assert mobile_settings['scroll']<=mobile_settings['client'],mobile_settings
        await page.screenshot(path=str(HERE.parent/'online-p2p3-settings-mobile.png'),full_page=True)
        await page.get_by_role('button',name='关闭策略管理',exact=True).click()
        await panel.scroll_into_view_if_needed()
        size=await panel.evaluate('(node)=>({client:node.clientWidth,scroll:node.scrollWidth})')
        assert size['scroll']<=size['client']+1,size
        await page.screenshot(path=str(HERE.parent/'online-p2p3-mobile.png'),full_page=True)
        assert not errors,errors
        assert not mutations,mutations
        assert not [url for url in data_requests if 'lane=live' in url],data_requests
        result={'url':base,'mode':'read_only_browser','active_lane':state.get('active_lane'),
                'paper_source':lane.get('source'),'paper_group':lane.get('group'),
                'paper_capital_usd':lane.get('capital_base_usd'),'paper_cash_usd':lane.get('cash_usd'),
                'script_urls':await page.locator('script[src]').evaluate_all('(nodes)=>nodes.map(n=>n.src)'),
                'paper_modals_checked':['wallet','positions','daily','orders','product'],
                'settings_dimensions':settings_size,'settings_mobile':mobile_settings,'openclaw_images':agent_images,
                'music_resource':{'path':media_path,'status':media.status,'content_type':media.headers.get('content-type'),'content_length':media.headers.get('content-length')},
                'comparison_text':await panel.inner_text(),'mobile_no_panel_overflow':True,
                'page_errors':errors,'mutations':mutations,'data_requests':data_requests,'warnings':warnings}
        (HERE.parent/'online-p2p3-browser.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps(result,ensure_ascii=True,indent=2))
        await browser.close()


if __name__=='__main__':asyncio.run(main())
