"""Offline browser verification: Paper UI updates, null valuation, stale data, layout."""
import asyncio
from functools import partial
import http.server
import json
from pathlib import Path
import threading
import time
from urllib.parse import urlparse

from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent
AUDIT = HERE.parents[1] / 'polytest-analysis-20261110'


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


async def main():
    state = json.loads((AUDIT / 'trades-state.json').read_text(encoding='utf-8'))
    start = time.time()-3600
    group = dict(virtual_capital_usd=236.006313, net_pnl_usd=1.2345, equity_complete=True,
                 realized_pnl_usd=1.3, fees_usd=.0655, fills=5, open_positions_count=1,
                 pending_orders=0, candidates=12, accepted=5, max_drawdown_usd=.4321,
                 daily_allow_entries=True, blocked={'FALSE_BREAKOUT': 4, 'MOMENTUM_DECAY': 3})
    summary = dict(mode='paper', updated_at=time.time(), started_at=start,
                   validation_after_ts=start+48*3600, ends_at=start+72*3600,
                   elapsed_hours=1, validation_complete=False, validation_state='COLLECTING',
                   experiment_state='RUNNING', groups={'BASELINE':group.copy(), 'FILTERED':group.copy()},
                   calibration={'settled_markets':19,'observed_markets':24,'min_markets_per_bin':30,
                                'bins':{'up-90s':{'markets':19,'ready':False}}},
                   health={'status':'RUNNING','signal_source':'chainlink_rtds','signal_window_sec':60,
                           'stream':{'market':{'connected':True}}})
    summary['groups']['FILTERED'].update(net_pnl_usd=None, equity_complete=False,
                                         fills=0, blocked={'PROBABILITY_WARMUP':12})
    server = http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(HERE/'dist')))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    status = 200
    calls = []
    errors = []
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
            page = await browser.new_page(viewport={'width':1440,'height':1050})
            page.on('pageerror',lambda error:errors.append(str(error)))
            await page.route_web_socket('**/api/ws/state',lambda socket:socket.close())
            async def respond(route):
                path = urlparse(route.request.url).path
                calls.append((route.request.method,path))
                payload = state if path=='/api/state' else summary if path=='/api/paper/comparison' else {'rows':[],'total':0,'available':True}
                await route.fulfill(status=status if path=='/api/paper/comparison' else 200,
                                    content_type='application/json; charset=utf-8',body=json.dumps(payload))
            await page.route('**/api/**',respond)
            await page.goto(f'http://127.0.0.1:{server.server_port}',wait_until='domcontentloaded')
            panel = page.get_by_role('region',name='PAPER 同条件对照')
            await panel.get_by_text('+$1.2345',exact=True).wait_for()
            assert '$236.006313' in await panel.inner_text()
            filtered = panel.locator('[data-paper-group=FILTERED]')
            assert '部分持仓缺少可成交估值' in await filtered.inner_text()
            assert '概率校准等待' in await filtered.inner_text()
            assert '19 / 已观察 24' in await panel.inner_text()
            assert '验证未完成' in await panel.inner_text()
            await panel.locator('.paper-comparison-method summary').click()
            assert '48h 可复核' in await panel.inner_text() and '72h 计划结束' in await panel.inner_text()
            await panel.scroll_into_view_if_needed()
            await page.screenshot(path=str(HERE.parent/'comparison-ui-desktop.png'),full_page=True)
            summary['groups']['BASELINE']['net_pnl_usd']=-.9876
            summary['updated_at']=time.time()
            await panel.get_by_text('-$0.9876',exact=True).wait_for(timeout=8000)
            assert await panel.get_by_text('-$0.9876',exact=True).evaluate("node=>getComputedStyle(node).color")=='rgb(255, 117, 132)'
            status=503
            await panel.get_by_text('对照数据暂不可用，等待恢复',exact=True).wait_for(timeout=8000)
            assert '-$0.9876' in await panel.inner_text(), 'Network failure must preserve last observations.'
            assert '数据过期' in await panel.inner_text()
            await page.set_viewport_size({'width':390,'height':844})
            await panel.scroll_into_view_if_needed()
            dims=await panel.evaluate('(node)=>({client:node.clientWidth,scroll:node.scrollWidth})')
            assert dims['scroll']<=dims['client']+1,dims
            await page.screenshot(path=str(HERE.parent/'comparison-ui-mobile.png'),full_page=True)
            assert not errors,errors
            assert all(method=='GET' for method,_ in calls),calls
            result={'mode':'offline_mock_no_orders','updates_rendered':True,'null_valuation_not_zero':True,
                    'stale_observation_retained':True,'mobile_no_panel_overflow':True,
                    'mutations':0,'page_errors':errors,'comparison_requests':sum(path=='/api/paper/comparison' for _,path in calls)}
            (HERE.parent/'comparison-ui-browser.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
            print(json.dumps(result,indent=2))
            await browser.close()
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':
    asyncio.run(main())
