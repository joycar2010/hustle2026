"""Render the candidate UI against recorded public data; no live orders/API calls."""
import asyncio
from functools import partial
import http.server
import json
from pathlib import Path
import sys
import threading
from urllib.parse import parse_qs, urlparse

from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'candidate'))
from server.chain_statistics import coherent_points, summarize_activity_period

AUDIT = HERE.parents[1] / 'polytest-analysis-20261110'
read = lambda name: json.loads((AUDIT / name).read_text(encoding='utf-8'))
state = read('trades-state.json')
orders = read('trades-orders-all.json')['rows']
daily = read('trades-daily.json')
positions = read('trades-positions-closed.json')['rows']
points, _ = coherent_points(read('accounting-official-user-pnl.json')['data']['points'],
                            read('accounting-official-user-stats.json')['data']['all_time_pnl'])
NOW = 1794331257.
state['risk_snapshot'] = {
    'mode': 'live', 'state': 'OK', 'available': True, 'allow_entries': False,
    'valuation': 'marked_account_equity', 'day_start_equity_usd': 235.45,
    'capital_base_usd': 235.45, 'equity_usd': 233.95,
    'daily_net_pnl_usd': -1.50, 'position_value_usd': 0.0571,
    'max_daily_loss_fraction': 0.03, 'data_as_of': NOW,
    'worker_running': False, 'execution_state': 'WORKER_STOPPED',
}


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


async def main():
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(HERE / 'dist')))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    calls = []
    errors = []
    try:
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe', headless=True)
            page = await browser.new_page(viewport={'width': 1440, 'height': 1050})
            page.on('pageerror', lambda error: errors.append(str(error)))
            await page.route_web_socket('**/api/ws/state', lambda socket: socket.close())

            async def respond(route):
                url = urlparse(route.request.url)
                query = parse_qs(url.query)
                if url.path == '/api/state':
                    payload = state
                elif url.path == '/api/orders':
                    offset = int(query.get('offset', ['0'])[0])
                    limit = int(query.get('limit', ['20'])[0])
                    start = float(query['start_ts'][0]) if 'start_ts' in query else None
                    end = float(query['end_ts'][0]) if 'end_ts' in query else None
                    lane = query.get('lane', ['live'])[0]
                    calls.append(dict(lane=lane, start_ts=start, end_ts=end, offset=offset))
                    selected = [row for row in orders if (start is None or row['ts'] >= start) and (end is None or row['ts'] < end)]
                    payload = {'rows': selected[offset:offset + limit], 'total': len(selected), 'offset': offset,
                               'limit': limit, 'lane': lane, 'source': 'data_api_v2', 'available': True,
                               'updated_at': NOW, 'activity_as_of': max((row['ts'] for row in selected), default=None),
                               'period_summary': summarize_activity_period(orders, start, end, positions, points, NOW)}
                elif url.path == '/api/pnl/daily':
                    payload = daily
                else:
                    payload = {'rows': [], 'total': 0, 'available': True}
                await route.fulfill(content_type='application/json; charset=utf-8', body=json.dumps(payload))

            await page.route('**/api/**', respond)
            await page.goto(f'http://127.0.0.1:{server.server_port}', wait_until='domcontentloaded')
            risk_note = page.locator('.pencil-board-main > .live-risk-equity-note')
            await risk_note.wait_for(timeout=20000)
            risk_text = await risk_note.inner_text()
            assert '$235.45' in risk_text and '$233.95' in risk_text, risk_text
            assert '\u5386\u53f2\u5f85\u5151\u6362\u5c3e\u4ed3' in risk_text, risk_text
            risk_card = page.locator('.pencil-risk-row .pencil-metric').first
            assert '0.6% / 3.0%' in await risk_card.inner_text()
            assert 'PAPER' not in await risk_card.inner_text()
            await page.locator('.pencil-metric').filter(has_text='全部订单').click(timeout=20000)
            modal = page.locator('.data-modal-dialog')
            await modal.wait_for()
            await modal.locator('.orders-lane-tab').get_by_text('实盘', exact=True).click()
            await modal.get_by_role('button', name='昨日', exact=True).click()
            await page.wait_for_function("document.querySelector('.data-modal-dialog')?.innerText.includes('-$0.097740') || document.querySelector('.data-modal-dialog')?.innerText.includes('-$0.10')")
            before = await modal.locator('.orders-summary-grid').inner_text()
            assert '69 / 14' in before, before
            assert '$1.977890' in before, before
            await modal.get_by_role('button', name='下一页 ›', exact=True).click()
            await page.wait_for_timeout(350)
            after = await modal.locator('.orders-summary-grid').inner_text()
            assert before == after, (before, after)
            assert calls[-1]['offset'] == 20, calls
            assert calls[-1]['start_ts'] == 1794240000, calls
            assert calls[-1]['end_ts'] == 1794326400, calls
            assert await modal.locator('input[type=date]').count() == 2
            await page.screenshot(path=str(HERE.parent / 'period-ui-desktop.png'), full_page=True)
            await page.set_viewport_size({'width': 390, 'height': 844})
            await page.screenshot(path=str(HERE.parent / 'period-ui-mobile.png'), full_page=True)
            state['risk_snapshot'].update(day_start_equity_usd=None, capital_base_usd=None, equity_usd=None, daily_net_pnl_usd=None, available=False, state='UNKNOWN')
            await page.reload(wait_until='domcontentloaded')
            await page.wait_for_function("document.querySelector('.pencil-risk-row .pencil-metric')?.innerText.includes('— / 3.0%')")
            assert '\u65e5\u521d\u6743\u76ca —' in await risk_note.inner_text()
            assert not errors, errors
            result = {'mode': 'offline_recorded_public_data', 'summary_stable_across_pages': True,
                      'live_risk_uses_day_start_equity': True, 'unknown_baseline_not_zero': True,
                      'live_risk_note': risk_text,
                      'beijing_filter_requests': calls, 'page_errors': errors,
                      'summary_text': after}
            (HERE.parent / 'period-ui-browser.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
            print(json.dumps(result, ensure_ascii=True, indent=2))
            await browser.close()
    finally:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    asyncio.run(main())
