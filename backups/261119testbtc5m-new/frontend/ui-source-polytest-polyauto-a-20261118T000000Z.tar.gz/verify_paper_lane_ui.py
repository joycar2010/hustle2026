"""Offline contaminated-state test: active Paper never borrows live/legacy values."""
import asyncio
from functools import partial
import http.server
import json
from pathlib import Path
import threading
import time
from urllib.parse import parse_qs,urlparse

from playwright.async_api import async_playwright

HERE=Path(__file__).resolve().parent
AUDIT=HERE.parents[1]/'polytest-analysis-20261110'


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):pass


async def main():
    state=json.loads((AUDIT/'trades-state.json').read_text(encoding='utf-8'))
    stamp=time.time()
    state.update(active_lane='paper',bot_mode='live',paper_positions=[{
        'market_slug':'btc-updown-5m-1794341100','asset':'BTC','side':'UP',
        'size':7.,'remaining_size':5.,'entry_price':.85,'notional_usd':4.25}],
        pnl={'realized_usd':-999.,'wins':999,'losses':999,'pending':999})
    state['service_modes']['BTC']['live_enabled']=True
    state['wallet']['balance_pusd']=9999.
    state['wallet']['value_usd']=8888.
    lane=dict(cash_usd=231.75,equity_usd=235.25,capital_base_usd=236.006313,
              realized_usd=.12,daily_economic_pnl_usd=-.756313,cumulative_realized_usd=1.2345,
              cumulative_wins=2,cumulative_losses=1,wins=1,losses=1,pending=1,
              open_value_usd=4.25,source='isolated_p3_public_paper',group='FILTERED',stale=False,
              by_asset={'BTC':{'realized_usd':.12,'wins':1,'losses':1,'pending':1}},
              cumulative_by_asset={'BTC':{'realized_usd':1.2345,'wins':2,'losses':1}})
    state['mode_split']['paper']=lane
    daily={'lane':'paper','source':'isolated_p3_public_paper','available':True,'stale':False,
           'rows':[{'day':'2026-11-11','realized_usd':.12,'wins':1,'losses':1,'capital_base_usd':236.006313}],
           'total_days':1,'capital_base_usd':236.006313}
    order={'id':1,'ts':stamp,'dry_run':True,'asset':'BTC','side':'REDEEM','activity_type':'REDEEM',
           'market_slug':'btc-updown-5m-1794341100','size':5.,'filled_size':5.,'price':1.,
           'status':'filled','cashflow_usd':5.,'fee_usd':0.,'source':'isolated_p3_public_paper'}
    calls=[];errors=[]
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(HERE/'dist')))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    try:
        async with async_playwright() as p:
            browser=await p.chromium.launch(executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',headless=True)
            page=await browser.new_page(viewport={'width':1440,'height':1050})
            page.on('pageerror',lambda e:errors.append(str(e)))
            await page.route_web_socket('**/api/ws/state',lambda socket:socket.close())
            async def respond(route):
                url=urlparse(route.request.url);query=parse_qs(url.query)
                calls.append({'method':route.request.method,'path':url.path,'query':query})
                if url.path=='/api/state':payload=state
                elif url.path=='/api/orders':payload={'rows':[order],'total':1,'available':True,'source':'isolated_p3_public_paper'}
                elif url.path=='/api/pnl/daily':payload=daily
                elif url.path=='/api/paper/comparison':payload={'mode':'paper','available':False}
                else:payload={'rows':[],'total':0,'available':True}
                await route.fulfill(content_type='application/json; charset=utf-8',body=json.dumps(payload))
            await page.route('**/api/**',respond)
            await page.goto(f'http://127.0.0.1:{server.server_port}',wait_until='domcontentloaded')
            cards=page.locator('.kpi-strip')
            await cards.get_by_text('模拟账户余额',exact=True).wait_for()
            text=await cards.inner_text()
            assert '$231.75' in text and '$4.25' in text and '-$0.76' in text,text
            assert '999' not in text and '8888' not in text and 'LIVE' not in text,text
            assert '50.0%' in text,text
            await cards.locator('.kpi-card').filter(has_text='模拟持仓成本').click()
            modal=page.locator('.data-modal-dialog')
            await modal.get_by_text('PAPER 当前持仓 / FILTERED',exact=True).wait_for()
            modal_text=await modal.inner_text()
            assert '0.850' in modal_text or '0.85' in modal_text,modal_text
            assert 'NaN' not in modal_text and '链上持仓' not in modal_text,modal_text
            await modal.locator('.data-modal-close').click()
            await cards.locator('.kpi-card').filter(has_text='模拟账户余额').click()
            await modal.get_by_text('PAPER 模拟资金 / FILTERED 独立账本',exact=True).wait_for()
            assert '$231.75' in await modal.inner_text()
            await modal.locator('.data-modal-close').click()
            await cards.locator('.kpi-card').filter(has_text='今日损益').click()
            await modal.get_by_text('FILTERED 独立 Paper 账本 · 按北京时间自然日',exact=True).wait_for()
            assert '+$0.12' in await modal.inner_text(),await modal.inner_text()
            await modal.locator('.data-modal-close').click()
            await page.get_by_role('button',name='查看BTC模拟数据',exact=True).click()
            await modal.get_by_text('BTC / PAPER 模拟数据',exact=True).wait_for()
            assert 'Live 最近记录' not in await modal.inner_text()
            await modal.locator('.data-modal-close').click()
            await page.locator('.pencil-metric').filter(has_text='全部订单').click()
            await modal.get_by_text('BTC PAPER / 模拟成交记录',exact=True).wait_for()
            await modal.get_by_text('+$5.00',exact=True).wait_for()
            assert '兑换' in await modal.inner_text()
            await page.screenshot(path=str(HERE.parent/'paper-lane-isolation-desktop.png'),full_page=True)
            await modal.locator('.data-modal-close').click()
            await page.locator('.strategy-menu > summary').click()
            settings=page.get_by_role('dialog',name='BTC 策略管理',exact=True)
            dims=await settings.evaluate('(node)=>{const r=node.getBoundingClientRect();return {width:r.width,height:r.height,left:r.left,top:r.top,bottom:r.bottom,cx:r.left+r.width/2,cy:r.top+r.height/2}}')
            assert dims['width']>=1000 and abs(dims['cx']-720)<2 and abs(dims['cy']-525)<2,dims
            assert dims['top']>=19 and dims['bottom']<=1031,dims
            await page.screenshot(path=str(HERE.parent/'strategy-layout-desktop.png'),full_page=True)
            await settings.get_by_role('button',name='关闭策略管理',exact=True).click()
            await page.set_viewport_size({'width':390,'height':844})
            await page.locator('.strategy-menu > summary').click()
            mobile_dims=await settings.evaluate('(node)=>{const r=node.getBoundingClientRect();return {width:r.width,height:r.height,left:r.left,right:r.right,top:r.top,bottom:r.bottom,scroll:node.scrollWidth,client:node.clientWidth}}')
            assert mobile_dims['left']>=9 and mobile_dims['right']<=381 and mobile_dims['top']>=11 and mobile_dims['bottom']<=833,mobile_dims
            assert mobile_dims['scroll']<=mobile_dims['client'],mobile_dims
            await page.screenshot(path=str(HERE.parent/'strategy-layout-mobile.png'),full_page=True)
            await settings.get_by_role('button',name='关闭策略管理',exact=True).click()
            await page.screenshot(path=str(HERE.parent/'paper-lane-isolation-mobile.png'),full_page=True)
            assert all(c['method']=='GET' for c in calls),calls
            assert not [c for c in calls if c['query'].get('lane')==['live']],calls
            assert not [c for c in calls if '/funding' in c['path'] or '/polymarket/' in c['path']],calls
            assert not errors,errors
            result={'mode':'offline_mock_contaminated_live_state','active_lane_overrides_stale_live_flag':True,
                    'paper_balance_and_pnl_isolated':True,'paper_positions_entry_price_supported':True,
                    'paper_wallet_no_chain_fetch':True,'product_and_history_paper_only':True,
                    'redemption_cashflow_positive':True,'mutations':0,'page_errors':errors,
                    'strategy_desktop':dims,'strategy_mobile':mobile_dims,
                    'data_requests':[c for c in calls if c['path'] in {'/api/orders','/api/pnl/daily'}]}
            (HERE.parent/'paper-lane-ui-browser.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
            print(json.dumps(result,indent=2))
            await browser.close()
    finally:
        server.shutdown();server.server_close()


if __name__=='__main__':asyncio.run(main())
