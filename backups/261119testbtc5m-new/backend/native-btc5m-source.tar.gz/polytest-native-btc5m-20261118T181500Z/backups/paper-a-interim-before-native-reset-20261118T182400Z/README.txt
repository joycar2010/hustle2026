20261118T182400Z  paper ledger moved before native bridge reset
