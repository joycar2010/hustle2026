"""FastAPI dashboard backend.

Polls the local SQLite (trades.db), the CLOB book of the live market, the
deposit wallet's positions, and on-chain pUSD balance. Serves /api/state for
the UI to poll, and /api/events for incremental new-row pulls.

Run:  .venv/bin/uvicorn server.dashboard:app --host 127.0.0.1 --port 8787
"""
from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor, as_completed
import hmac
import json
import math
import os
import re
import sqlite3
import subprocess
import threading
import time
from contextlib import closing
from dataclasses import dataclass
from datetime import datetime, time as dt_time, timezone, timedelta
from pathlib import Path
from typing import Any, Literal, Optional
from urllib.parse import urlparse

import requests
from fastapi import FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import dotenv_values, load_dotenv

from server.portfolio_positions import fetch_portfolio_positions

from bot.book import fetch_book
from bot.btc_signal import BtcSignal, fetch_btc_signal, fetch_eth_signal
from bot.config import load as load_cfg
from bot.markets import LiveMarket, fetch_live_market
from bot.resolver import resolve_pending
from bot.risk import daily_profit_target_usd
from bot.paper_profit import active_paper_profit_stop
from bot.store import (
    realized_pnl_summary_today, realized_pnl_by_day, realized_pnl_by_asset_today,
    accounting_snapshot, consecutive_losses, local_day_start_ts, remaining_positions,
    TRADING_TIMEZONE,
)
from bot.store import _fifo_ledger
from bot.sports_main import SportsPaperService
from bot.weather_data import CITY_CONFIG, configured_city_keys, fetch_ensemble_forecast
from bot.weather_markets import fetch_weather_markets
from bot.weather_strategy import build_signal
from bot.paper_feeds import read_snapshot as read_paper_feed_snapshot

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("TRADES_DB_PATH", str(ROOT / "trades.db"))).expanduser()

cfg = load_cfg()

# Scope this site's presentation to BTC without changing trading accounting.
_all_accounting_snapshot = accounting_snapshot
_all_fifo_ledger = _fifo_ledger
_all_remaining_positions = remaining_positions


def accounting_snapshot(dry_run: bool, now: Optional[float] = None) -> dict:
    account = _all_accounting_snapshot(dry_run, now=now)
    positions = [row for row in account["positions"] if str(row.get("asset", "")).upper() == "BTC"]
    item = dict(account["by_asset"].get("BTC") or {"realized_usd": 0.0, "wins": 0, "losses": 0, "pending": 0, "open_value_usd": 0.0})
    pnl = {**account["pnl"], **{key: item[key] for key in ("realized_usd", "wins", "losses")}, "pending": len(positions)}
    return {**account, "pnl": pnl, "positions": positions, "by_asset": {"BTC": item}, "open_value_usd": sum(float(row["notional_usd"]) for row in positions)}


def realized_pnl_summary_today(dry_run: bool) -> dict:
    return accounting_snapshot(dry_run)["pnl"]


def _fifo_ledger(dry_run: bool):
    lots, events, resolutions = _all_fifo_ledger(dry_run)
    return ([row for row in lots if str(row.get("asset", "")).upper() == "BTC"],
            [row for row in events if str(row.get("asset", "")).upper() == "BTC"], resolutions)


def remaining_positions(dry_run: bool, asset: Optional[str] = None) -> list[dict]:
    return _all_remaining_positions(dry_run, asset="BTC")

# Live controls are deliberately protected by a separate operator token.  The
# dashboard is reachable through the public HTTPS hostname, so exposing a
# start/stop route without authentication would allow anybody to place real
# orders.  The token is read from .env for every request so rotating it does
# not require a dashboard restart.
_live_control_lock = threading.Lock()


def _is_polyauto_instance() -> bool:
    """Return deployment identity without relying on a copied main .env."""
    value = os.environ.get("POLYAUTO_INSTANCE", "").strip().lower()
    if value in ("1", "true", "yes", "on", "auto"):
        return True
    return str(getattr(cfg, "instance_name", "main")).strip().lower() == "polyauto"


LIVE_SERVICE_IDS = ("BTC",)


def _control_env_values() -> dict[str, str]:
    # .env contains long provider prompts and is expensive to parse. State is
    # pushed every second, so cache the normalized values until the file is
    # actually changed (or a short safety TTL expires).
    path = ROOT / ".env"
    try:
        stat = path.stat()
        marker = (int(stat.st_mtime_ns), int(stat.st_size))
    except OSError:
        marker = (0, 0)
    now = time.monotonic()
    cached = globals().get("_DOTENV_CACHE")
    if isinstance(cached, dict) and cached.get("marker") == marker and now - float(cached.get("ts", 0.0)) < 30.0:
        return cached["values"]
    values = dotenv_values(path)
    normalized = {str(k): str(v or "") for k, v in values.items()}
    globals()["_DOTENV_CACHE"] = {"marker": marker, "ts": now, "values": normalized}
    return normalized


def _service_status_snapshot() -> dict[str, Any]:
    """Expose independent, truthful live gates for each polyauto service."""
    env = _control_env_values()
    auto = _is_polyauto_instance()
    assets = _live_process_status_base()
    paper_assets = _paper_process_status_base()
    try:
        process_mode = (ROOT / "bot.mode").read_text(encoding="utf-8").strip().lower()
    except OSError:
        process_mode = "paper"
    btc_enabled = env.get("BTC_LIVE_ENABLED", "false").strip().lower() in ("1", "true", "yes", "on")
    eth_enabled = env.get("ETH_TRADING_ENABLED", "false").strip().lower() in ("1", "true", "yes", "on")
    weather_enabled = env.get("WEATHER_LIVE_TRADING_ENABLED", "false").strip().lower() in ("1", "true", "yes", "on")
    # Sports intentionally has no live implementation.  Do not add a config
    # escape hatch here; the paper service rejects live mode at its boundary.
    policy = {
        "BTC": {"live_enabled": btc_enabled, "can_enable_live": True, "mode": ("live" if assets["BTC"] else "paper"), "running": bool(assets["BTC"] or paper_assets["BTC"]), "live_running": assets["BTC"], "paper_running": paper_assets["BTC"]},
        # polyauto explicitly opts into BTC and ETH live independently.  The
        # weather and sports services remain paper-only below.
        "ETH": {"live_enabled": eth_enabled, "can_enable_live": True, "mode": ("live" if assets["ETH"] else "paper"), "running": bool(assets["ETH"] or paper_assets["ETH"]), "live_running": assets["ETH"], "paper_running": paper_assets["ETH"]},
        "WEATHER": {"live_enabled": False, "can_enable_live": False, "mode": "paper", "running": bool(read_paper_feed_snapshot("WEATHER").get("running"))},
        "SPORTS": {"live_enabled": False, "can_enable_live": False, "mode": "paper", "running": bool(read_paper_feed_snapshot("SPORTS").get("running"))},
    }
    if auto:
        # Weather and sports remain paper-only in the isolated instance.
        for service in ("WEATHER", "SPORTS"):
            policy[service]["live_enabled"] = False
            policy[service]["mode"] = "paper"
    return {"BTC": policy["BTC"]}


def _pid_command_line(path: Path) -> str:
    try:
        pid = int(path.read_text(encoding="utf-8").strip())
        if not _pid_alive(path):
            return ""
        raw = Path(f"/proc/{pid}/cmdline").read_bytes()
        return raw.replace(b"\x00", b" ").decode("utf-8", "replace").strip()
    except (FileNotFoundError, OSError, ValueError):
        return ""


def _pid_is_live(path: Path) -> bool:
    command = _pid_command_line(path)
    return bool(command and re.search(r"(?:^|\s)--live(?:\s|$)", command))


def _pid_is_paper(path: Path) -> bool:
    command = _pid_command_line(path)
    if not command or _pid_is_live(path):
        return False
    return "bot.main" in command and "--asset" in command


def _live_process_status_base() -> dict[str, bool]:
    return {
        "BTC": _pid_is_live(ROOT / "bot_btc.pid") or _pid_is_live(ROOT / "bot.pid"),
        "ETH": _pid_is_live(ROOT / "bot_eth.pid"),
    }


def _paper_process_status_base() -> dict[str, bool]:
    return {
        "BTC": _pid_is_paper(ROOT / "bot_btc.pid") or _pid_is_paper(ROOT / "bot.pid"),
        "ETH": _pid_is_paper(ROOT / "bot_eth.pid"),
    }


def _operator_token() -> str:
    values = _control_env_values()
    return str(values.get("DASHBOARD_CONTROL_TOKEN") or "").strip()


def _require_operator(request: Request) -> None:
    expected = _operator_token()
    supplied = request.headers.get("X-Operator-Token", "").strip()
    if not expected:
        raise HTTPException(
            status_code=503,
            detail="未配置 DASHBOARD_CONTROL_TOKEN，实盘控制已禁用",
        )
        raise HTTPException(status_code=401, detail="实盘控制令牌无效")
        raise HTTPException(status_code=401, detail="实盘控制令牌无效")




def _deposit_wallet_address() -> str:
    """Return the configured Polymarket collateral wallet.

    Older .env files only had FUNDER_ADDRESS.  Keep that as a compatibility
    fallback while honoring an explicitly migrated DEPOSIT_WALLET_ADDRESS.
    """
    return (
        str(getattr(cfg, "deposit_wallet_address", "") or "").strip()
        or str(getattr(cfg, "funder_address", "") or "").strip()
    )

# LLM settings are intentionally kept separate from the trading strategy.  The
# dashboard exposes provider/model metadata and accepts a new secret, but GET
# never returns the secret itself.  This mirrors the Mix systemLLM relay
# settings while keeping this small service provider-agnostic.
LLM_ENV_KEYS = (
    "LLM_ENABLED", "LLM_PROVIDER", "LLM_BASE_URL", "LLM_MODEL",
    "LLM_API_KEY", "LLM_TIMEOUT_SEC", "LLM_MAX_TOKENS", "LLM_TEMPERATURE",
    "LLM_SYSTEM_PROMPT", "LLM_ADVISOR_ENABLED",
    "LLM_PRIMARY_ENABLED", "LLM_PRIMARY_PROVIDER", "LLM_PRIMARY_BASE_URL", "LLM_PRIMARY_MODEL",
    "LLM_PRIMARY_API_KEY", "LLM_PRIMARY_TIMEOUT_SEC", "LLM_PRIMARY_MAX_TOKENS", "LLM_PRIMARY_TEMPERATURE", "LLM_PRIMARY_SYSTEM_PROMPT",
    "LLM_SECONDARY_ENABLED", "LLM_SECONDARY_PROVIDER", "LLM_SECONDARY_BASE_URL", "LLM_SECONDARY_MODEL",
    "LLM_SECONDARY_API_KEY", "LLM_SECONDARY_TIMEOUT_SEC", "LLM_SECONDARY_MAX_TOKENS", "LLM_SECONDARY_TEMPERATURE", "LLM_SECONDARY_SYSTEM_PROMPT",
)
LLM_SECRET_MASK = "••••••••"

# Last connection/probe results are memory-only and never include provider
# responses or API keys. They are exposed as health metadata for the UI.
_llm_runtime: dict[str, Any] = {
    "last_test_ts": None,
    "last_test_ok": None,
    "last_test_error": None,
    "last_probe_ts": None,
    "last_probe_count": 0,
}

# Lightweight process-local token telemetry.  Providers return usage metadata
# on chat completions; keeping a bounded aggregate here lets the dashboard
# display live consumption without persisting prompts or model responses.
_llm_usage_lock = threading.Lock()
_llm_usage: dict[str, dict[str, Any]] = {}

def _wallet_status() -> dict[str, Any]:
    deposit = _deposit_wallet_address()
    return {
        "bound": bool(deposit),
        "status": "已绑定" if deposit else "未绑定",
        "address": deposit or None,
        "balance_available": _state.get("balance_pusd") is not None,
        "value_available": _state.get("value_usd") is not None,
    }


_POLY_PROFILE_CACHE: dict[str, Any] = {"ts": 0.0, "value": None}

_POLY_LIVE_SUMMARY_CACHE: dict[str, Any] = {"ts": 0.0, "value": None}


def _activity_summary(rows: list[dict[str, Any]], now: Optional[float] = None) -> dict[str, Any]:
    """Derive closed-market win/loss counts from the public activity feed.

    A BUY-only market is still open and must not be counted as a loss. A market
    is closed when it has a REDEEM, or when its traded shares have been fully
    sold. This keeps the dashboard aligned with the account after manual
    redemptions instead of treating the remaining open position as a loss.
    """
    by_condition: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = str(row.get("condition_id") or row.get("conditionId") or row.get("slug") or row.get("token_id") or "")
        if key:
            by_condition.setdefault(key, []).append(row)
    groups: list[tuple[float, float]] = []
    for events in by_condition.values():
        cash = 0.0
        shares = 0.0
        bought_shares = 0.0
        latest_ts = 0.0
        has_redeem = False
        for event in events:
            try:
                amount = float(event.get("usdc_size") or 0.0)
            except (TypeError, ValueError):
                amount = 0.0
            try:
                size = float(event.get("size") or 0.0)
            except (TypeError, ValueError):
                size = 0.0
            event_type = str(event.get("type") or "").upper()
            side = str(event.get("side") or "").upper()
            if event_type == "TRADE":
                if side == "SELL":
                    cash += amount
                    shares -= size
                elif side == "BUY":
                    cash -= amount
                    shares += size
                    bought_shares += size
            elif event_type == "REDEEM":
                cash += amount
                has_redeem = True
                shares = 0.0
            try:
                latest_ts = max(latest_ts, float(event.get("timestamp") or 0.0))
            except (TypeError, ValueError):
                pass
        if has_redeem or shares <= max(0.05, bought_shares * 0.02):
            groups.append((cash, latest_ts))
    wins = sum(1 for cash, _ in groups if cash > 0.005)
    losses = sum(1 for cash, _ in groups if cash < -0.005)
    bj = timezone(timedelta(hours=8))
    current = datetime.fromtimestamp(float(now or time.time()), timezone.utc).astimezone(bj)
    day_start = current.replace(hour=0, minute=0, second=0, microsecond=0)
    today_groups = [(cash, ts) for cash, ts in groups if ts and datetime.fromtimestamp(ts, timezone.utc).astimezone(bj) >= day_start]
    today_wins = sum(1 for cash, _ in today_groups if cash > 0.005)
    today_losses = sum(1 for cash, _ in today_groups if cash < -0.005)
    return {"wins": wins, "losses": losses, "today_wins": today_wins, "today_losses": today_losses,
            "markets": len(groups), "today_markets": len(today_groups)}


def _polymarket_live_summary() -> dict[str, Any]:
    """Read joycar's public v2 PnL/activity summary with a short cache."""
    wallet = _deposit_wallet_address()
    now = time.time()
    cached = _POLY_LIVE_SUMMARY_CACHE.get("value")
    if cached is not None and now - float(_POLY_LIVE_SUMMARY_CACHE.get("ts", 0.0)) < 20.0:
        return dict(cached)
    result: dict[str, Any] = {"available": False, "source": "data_api_v2_user_pnl_activity", "wallet": wallet or None,
        "realized_usd": None, "economic_usd": None, "trade_pnl_usd": None, "today_realized_usd": None,
        "rolling_24h_usd": None, "rolling_24h_base_ts": None, "rolling_24h_updated_ts": None,
        "wins": 0, "losses": 0, "today_wins": 0, "today_losses": 0, "markets": 0, "today_markets": 0,
        "trade_count": 0, "last_update_ts": None, "error": None}
    if not re.fullmatch(r"0x[0-9a-fA-F]{40}", wallet or ""):
        result["error"] = "wallet_unconfigured"
        _POLY_LIVE_SUMMARY_CACHE.update(ts=now, value=result)
        return dict(result)
    try:
        response = requests.get("https://data-api.polymarket.com/v2/user-pnl",
            params={"user": wallet, "interval": "all", "fidelity": "1h"}, timeout=_POLY_READ_TIMEOUT)
        response.raise_for_status()
        payload = response.json()
        data = payload.get("data", payload) if isinstance(payload, dict) else {}
        points = [item for item in (data.get("points", []) if isinstance(data, dict) else []) if isinstance(item, dict)]
        points.sort(key=lambda item: float(item.get("timestamp") or 0.0))
        latest = points[-1] if points else {}
        result["realized_usd"] = float(latest.get("realized_pnl")) if latest.get("realized_pnl") is not None else None
        result["economic_usd"] = float(latest.get("economic_pnl")) if latest.get("economic_pnl") is not None else None
        result["trade_pnl_usd"] = float(latest.get("trade_pnl")) if latest.get("trade_pnl") is not None else None
        result["trade_count"] = int(latest.get("trade_count") or 0)
        result["last_update_ts"] = float(latest.get("timestamp")) if latest.get("timestamp") is not None else None
        # The website's green PnL card is a rolling 24-hour window, while
        # realized_usd above is the account lifetime cumulative value. Keep
        # both explicit so a manual redeem cannot make the two figures look
        # contradictory. Use the latest API point as the end of the window
        # and the nearest point at or before 24 hours earlier as its baseline.
        latest_ts = float(latest.get("timestamp") or 0.0)
        latest_realized = latest.get("realized_pnl")
        if latest_ts > 0 and latest_realized is not None:
            baseline = None
            cutoff = latest_ts - 86400.0
            for point in points:
                try:
                    point_ts = float(point.get("timestamp") or 0.0)
                except (TypeError, ValueError):
                    continue
                if point_ts <= cutoff and point.get("realized_pnl") is not None:
                    baseline = point
                elif point_ts > cutoff:
                    break
            if baseline is not None:
                result["rolling_24h_usd"] = float(latest_realized) - float(baseline.get("realized_pnl") or 0.0)
                result["rolling_24h_base_ts"] = float(baseline.get("timestamp") or 0.0)
                result["rolling_24h_updated_ts"] = latest_ts
        bj = timezone(timedelta(hours=8))
        current_bj = datetime.fromtimestamp(now, timezone.utc).astimezone(bj)
        day_start_utc = current_bj.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc).timestamp()
        baseline = None
        for point in points:
            if float(point.get("timestamp") or 0.0) <= day_start_utc:
                baseline = point
            else:
                break
        if baseline and latest.get("realized_pnl") is not None and baseline.get("realized_pnl") is not None:
            result["today_realized_usd"] = float(latest.get("realized_pnl")) - float(baseline.get("realized_pnl"))
        elif latest.get("realized_pnl") is not None:
            result["today_realized_usd"] = float(latest.get("realized_pnl"))
        result["available"] = bool(points)
    except Exception as exc:
        result["error"] = str(exc)
    try:
        rows: list[dict[str, Any]] = []
        cursor: Optional[str] = None
        for _ in range(10):
            params: dict[str, Any] = {"user": wallet, "limit": 500}
            if cursor:
                params["cursor"] = cursor
            response = requests.get("https://data-api.polymarket.com/v2/activity", params=params, timeout=_POLY_READ_TIMEOUT)
            response.raise_for_status()
            payload = response.json() if isinstance(response.json(), dict) else {}
            batch = payload.get("data", [])
            if not isinstance(batch, list):
                break
            rows.extend(item for item in batch if isinstance(item, dict))
            next_cursor = payload.get("next_cursor")
            if not next_cursor or not batch:
                break
            cursor = str(next_cursor)
        result.update(_activity_summary(rows, now=now))
        result["activity_count"] = len(rows)
    except Exception as exc:
        if not result.get("error"):
            result["error"] = str(exc)
    _POLY_LIVE_SUMMARY_CACHE.update(ts=now, value=result)
    return dict(result)
_FUNDING_CACHE: dict[str, Any] = {"ts": 0.0, "value": None}
_POLY_READ_TIMEOUT = 8


def _portfolio_snapshot(holdings: Optional[dict] = None) -> dict[str, Any]:
    """Return public identity plus fresh wallet value and external PnL."""
    wallet = _deposit_wallet_address()
    now = time.time()
    cached = _POLY_PROFILE_CACHE.get("value")
    if cached is None or now - float(_POLY_PROFILE_CACHE.get("ts", 0.0)) >= 300.0:
        profile: dict[str, Any] = {"available": False, "source": "gamma_public_profile", "proxy_wallet": wallet or None}
        if wallet:
            try:
                response = requests.get(
                    "https://gamma-api.polymarket.com/public-profile",
                    params={"address": wallet},
                    timeout=_POLY_READ_TIMEOUT,
                )
                response.raise_for_status()
                data = response.json()
                if isinstance(data, dict):
                    profile.update({
                        "available": True,
                        "name": data.get("name") or data.get("displayUsername"),
                        "pseudonym": data.get("pseudonym"),
                        "proxy_wallet": data.get("proxyWallet") or wallet,
                        "verified_badge": bool(data.get("verifiedBadge")),
                    })
            except Exception as exc:
                profile["error"] = str(exc)
        _POLY_PROFILE_CACHE.update(ts=now, value=profile)
        cached = profile
    profile = dict(cached or {"available": False, "proxy_wallet": wallet or None})
    # These values are updated by the 2-second wallet poller. Do not keep them
    # inside the identity cache: a manual redeem must move the top bar and
    # position/portfolio cards on the next state frame.
    balance = _state.get("balance_pusd")
    holdings = holdings if holdings is not None else _account_positions_snapshot()
    position_value = holdings.get("total_value_usd")
    try:
        balance_value = float(balance) if balance is not None else None
    except (TypeError, ValueError):
        balance_value = None
    try:
        position_value_num = float(position_value) if position_value is not None else None
    except (TypeError, ValueError):
        position_value_num = None
    pending_deposit = _state.get("balance_usdce")
    try:
        pending_deposit_num = float(pending_deposit) if pending_deposit is not None else None
    except (TypeError, ValueError):
        pending_deposit_num = None
    if pending_deposit_num is not None and (not math.isfinite(pending_deposit_num) or pending_deposit_num < 0):
        pending_deposit_num = None
    profile["balance_usd"] = balance_value
    profile["pending_deposit_usd"] = pending_deposit_num
    profile["fund_activation"] = {
        "asset": "USDC.e",
        "status": "pending_user_signature" if pending_deposit_num is not None and pending_deposit_num > 0.000001 else "none_detected",
        "amount_usd": pending_deposit_num,
        "automatic_confirmation": False,
        "reason": "USDC.e 转入 pUSD 需要钱包签名" if pending_deposit_num is not None and pending_deposit_num > 0.000001 else None,
    }
    profile["position_value_usd"] = position_value_num
    profile["positions_available"] = bool(holdings.get("available"))
    profile["positions_stale"] = bool(holdings.get("stale"))
    profile["positions_updated_at"] = holdings.get("updated_at")
    profile["pending_count"] = holdings.get("pending_count")
    profile["redeemable_count"] = holdings.get("redeemable_count")
    profile["pending_value_usd"] = holdings.get("pending_value_usd")
    profile["redeemable_value_usd"] = holdings.get("redeemable_value_usd")
    profile["portfolio_value_usd"] = (
        round(balance_value + (pending_deposit_num or 0.0) + position_value_num, 4)
        if balance_value is not None and position_value_num is not None
        else None
    )
    # Public account PnL/activity is separate from the local worker ledger so
    # manual Polymarket redemptions are reflected without editing local history.
    profile["live_summary"] = _polymarket_live_summary()
    return profile

def _polymarket_activity_rows(limit: int = 50, offset: int = 0, kind: str = "") -> dict[str, Any]:
    """Read the current wallet's public Data API v2 activity feed."""
    wallet = _deposit_wallet_address()
    if not wallet:
        return {"rows": [], "total": 0, "offset": offset, "limit": limit, "source": "data_api_v2", "available": False, "error": "wallet_unconfigured"}
    request_limit = min(500, max(1, limit))
    params: dict[str, Any] = {"user": wallet, "limit": request_limit}
    normalized_kind = kind.strip().upper()
    if normalized_kind in ("TRADE", "REDEEM", "MERGE", "SPLIT"):
        params["type"] = normalized_kind
    # v2 activity is cursor-only. Fetch enough pages to satisfy the legacy
    # offset-shaped UI request without sending the retired `offset` parameter.
    data: list[dict[str, Any]] = []
    cursor: Optional[str] = None
    payload: dict[str, Any] = {}
    for _ in range(10):
        page_params = dict(params)
        if cursor:
            page_params["cursor"] = cursor
        response = requests.get("https://data-api.polymarket.com/v2/activity", params=page_params, timeout=_POLY_READ_TIMEOUT)
        response.raise_for_status()
        page = response.json()
        page = page if isinstance(page, dict) else {}
        payload = page
        batch = page.get("data", [])
        if not isinstance(batch, list):
            batch = []
        data.extend(item for item in batch if isinstance(item, dict))
        next_cursor = page.get("next_cursor")
        if len(data) >= offset + limit or not next_cursor or not batch:
            break
        cursor = str(next_cursor)
    rows: list[dict[str, Any]] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        rows.append({
            "type": item.get("type"),
            "timestamp": item.get("timestamp"),
            "condition_id": item.get("condition_id"),
            "token_id": item.get("token_id"),
            "title": item.get("title"),
            "slug": item.get("slug"),
            "event_slug": item.get("event_slug"),
            "side": item.get("side"),
            "outcome": item.get("outcome"),
            "outcome_index": item.get("outcome_index"),
            "size": item.get("size"),
            "price": item.get("price"),
            "usdc_size": item.get("usdc_size"),
            "transaction_hash": item.get("transaction_hash"),
            "name": item.get("name"),
            "pseudonym": item.get("pseudonym"),
            "proxy_wallet": item.get("proxy_wallet") or wallet,
        })
    next_cursor = payload.get("next_cursor") if isinstance(payload, dict) else None
    return {
        "rows": rows[offset:offset + limit],
        "total": len(rows),
        "offset": offset,
        "limit": limit,
        "next_cursor": next_cursor,
        "source": "data_api_v2",
        "available": True,
        "wallet": wallet,
        "kind": normalized_kind or "ALL",
    }


def _rpc_transfer_chunk(args: tuple[str, int, int, str, str]) -> list[dict[str, Any]]:
    rpc_url, lo, hi, contract, wallet_topic = args
    topic0 = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a9df523b3ef"
    direction, topic_index = ("deposit", 1) if args[4] == "in" else ("withdrawal", 2)
    topics = [topic0, wallet_topic if topic_index == 1 else None, wallet_topic if topic_index == 2 else None]
    try:
        response = requests.post(
            rpc_url,
            json={"jsonrpc": "2.0", "id": 1, "method": "eth_getLogs", "params": [{
                "fromBlock": hex(lo), "toBlock": hex(hi), "address": contract, "topics": topics,
            }]},
            timeout=12,
        )
        payload = response.json()
        logs = payload.get("result") if isinstance(payload, dict) else None
        if not isinstance(logs, list):
            return []
        out: list[dict[str, Any]] = []
        for log in logs:
            if not isinstance(log, dict):
                continue
            try:
                raw_amount = int(str(log.get("data") or "0x0"), 16)
            except (TypeError, ValueError):
                continue
            out.append({
                "direction": direction,
                "amount_usd": round(raw_amount / 1_000_000, 6),
                "tx_hash": log.get("transactionHash"),
                "transaction_hash": log.get("transactionHash"),
                "block_number": int(str(log.get("blockNumber") or "0x0"), 16),
                "log_index": int(str(log.get("logIndex") or "0x0"), 16),
                "token_contract": contract,
            })
        return out
    except Exception:
        return []


def _funding_snapshot() -> dict[str, Any]:
    """Return recent inbound/outbound stablecoin transfers without credentials."""
    now = time.time()
    cached = _FUNDING_CACHE.get("value")
    if cached is not None and now - float(_FUNDING_CACHE.get("ts", 0.0)) < 300.0:
        return dict(cached)
    wallet = _deposit_wallet_address()
    if not wallet:
        value = {"available": False, "source": "polygon_transfer_logs", "wallet": None, "records": [], "deposits": [], "withdrawals": [], "error": "wallet_unconfigured"}
        _FUNDING_CACHE.update(ts=now, value=value)
        return value
    rpc_url = "https://polygon.drpc.org"
    wallet_topic = "0x" + "0" * 24 + wallet[2:].lower()
    contracts = {
        "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB".lower(): "pUSD",
        "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174".lower(): "USDC.e",
        "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359".lower(): "USDC",
    }
    try:
        head_response = requests.post(rpc_url, json={"jsonrpc": "2.0", "id": 1, "method": "eth_blockNumber", "params": []}, timeout=12)
        head_payload = head_response.json()
        head = int(str(head_payload["result"]), 16)
    except Exception as exc:
        value = {"available": False, "source": "polygon_transfer_logs", "wallet": wallet, "records": [], "deposits": [], "withdrawals": [], "error": f"rpc_unavailable: {exc}"}
        _FUNDING_CACHE.update(ts=now, value=value)
        return value
    # The public RPC caps eth_getLogs at 10,000 blocks. A 1M-block window is
    # roughly two weeks on Polygon and is enough for the dashboard history;
    # cached results avoid repeated scans when the modal is reopened.
    lower = max(0, head - 1_000_000)
    tasks: list[tuple[str, int, int, str, str]] = []
    for contract in contracts:
        for lo in range(lower, head + 1, 10_000):
            hi = min(head, lo + 9_999)
            tasks.append((rpc_url, lo, hi, contract, "in"))
            tasks.append((rpc_url, lo, hi, contract, "out"))
    records: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=16) as pool:
        futures = [pool.submit(_rpc_transfer_chunk, task) for task in tasks]
        for future in as_completed(futures):
            records.extend(future.result())
    seen: set[tuple[Any, Any]] = set()
    unique: list[dict[str, Any]] = []
    for record in sorted(records, key=lambda row: (int(row.get("block_number") or 0), int(row.get("log_index") or 0)), reverse=True):
        key = (record.get("tx_hash"), record.get("log_index"))
        if key in seen:
            continue
        seen.add(key)
        record["token_symbol"] = contracts.get(str(record.get("token_contract") or "").lower(), "stablecoin")
        record.pop("log_index", None)
        unique.append(record)
    value = {
        "available": True,
        "source": "polygon_transfer_logs",
        "wallet": wallet,
        "records": unique[:200],
        "deposits": [row for row in unique if row.get("direction") == "deposit"][:100],
        "withdrawals": [row for row in unique if row.get("direction") == "withdrawal"][:100],
        "lookback_blocks": head - lower,
        "head_block": head,
        "balance_usd": _portfolio_snapshot().get("balance_usd"),
        "portfolio_value_usd": _portfolio_snapshot().get("portfolio_value_usd"),
    }
    _FUNDING_CACHE.update(ts=now, value=value)
    return value


def _record_llm_usage(model: str, usage: Any = None, *, ok: bool = True, error: str | None = None) -> None:
    name = (model or "unknown").strip() or "unknown"
    raw = usage if isinstance(usage, dict) else {}
    def number(*keys: str) -> int:
        for key in keys:
            value = raw.get(key)
            try:
                return max(0, int(value))
            except (TypeError, ValueError):
                continue
        return 0
    prompt = number("prompt_tokens", "input_tokens")
    completion = number("completion_tokens", "output_tokens")
    total = number("total_tokens") or prompt + completion
    now = time.time()
    with _llm_usage_lock:
        item = _llm_usage.setdefault(name, {
            "model": name, "requests": 0, "errors": 0,
            "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0,
            "last_tokens": 0, "last_ts": None, "last_error": None,
        })
        item["requests"] += 1
        item["prompt_tokens"] += prompt
        item["completion_tokens"] += completion
        item["total_tokens"] += total
        item["last_tokens"] = total
        item["last_ts"] = now
        item["last_error"] = None if ok else (error or "request failed")
        if not ok:
            item["errors"] += 1


def _llm_usage_snapshot() -> dict[str, Any]:
    with _llm_usage_lock:
        return {"models": [dict(value) for value in _llm_usage.values()], "ts": time.time()}


class LlmSettingsPayload(BaseModel):
    enabled: bool = False
    advisor_enabled: bool = False
    provider: str = Field(default="openai-compatible", max_length=64)
    base_url: str = Field(default="", max_length=512)
    model: str = Field(default="", max_length=256)
    # None/empty means retain the existing key.  The mask is also treated as
    # retain, so a browser can round-trip GET -> PUT without replacing it.
    api_key: Optional[str] = Field(default=None, max_length=2048)
    # The provider probe/test endpoints use the same bounded timeout. Keeping
    # one limit avoids a UI value that saves successfully but is rejected when
    # the user clicks either action.
    timeout_sec: float = Field(default=15.0, ge=1.0, le=60.0)
    max_tokens: int = Field(default=512, ge=1, le=32768)
    temperature: float = Field(default=0.2, ge=0.0, le=2.0)
    system_prompt: str = Field(default="", max_length=12000)
    primary: Optional[dict[str, Any]] = None
    secondary: Optional[dict[str, Any]] = None


class LlmProbePayload(BaseModel):
    """Transient credentials used only for GET /models probing."""

    base_url: str = Field(..., max_length=512)
    api_key: Optional[str] = Field(default=None, max_length=2048)
    timeout_sec: float = Field(default=15.0, ge=1.0, le=60.0)
    slot: str = Field(default="primary", pattern="^(primary|secondary)$")


class LlmTestPayload(BaseModel):
    """Transient connection test; it never changes trading behaviour."""

    base_url: Optional[str] = Field(default=None, max_length=512)
    model: Optional[str] = Field(default=None, max_length=256)
    api_key: Optional[str] = Field(default=None, max_length=2048)
    prompt: str = Field(
        default="请仅回复：连接成功。不要执行任何交易或调用外部工具。",
        max_length=2000,
    )
    timeout_sec: float = Field(default=20.0, ge=1.0, le=60.0)
    slot: str = Field(default="primary", pattern="^(primary|secondary)$")


def _read_llm_env() -> dict[str, str]:
    values = _control_env_values()
    # dotenv_values returns Optional values; normalize for JSON responses.
    return {k: str(values.get(k) or "") for k in LLM_ENV_KEYS}


def _llm_settings_response() -> dict[str, Any]:
    values = _read_llm_env()
    key = values.get("LLM_API_KEY", "")
    def profile(slot: str, fallback: bool = False) -> dict[str, Any]:
        p = "LLM_" + slot.upper() + "_"
        def val(name: str, default: str = "") -> str:
            raw = values.get(p + name, "")
            if fallback and not raw:
                raw = values.get("LLM_" + name, "")
            return raw or default
        secret = val("API_KEY")
        return {"enabled": val("ENABLED", "0").lower() in ("1", "true", "yes", "on"), "provider": val("PROVIDER", "openai-compatible"), "base_url": val("BASE_URL"), "model": val("MODEL"), "api_key": LLM_SECRET_MASK if secret else "", "api_key_configured": bool(secret), "timeout_sec": float(val("TIMEOUT_SEC", "30")), "max_tokens": int(float(val("MAX_TOKENS", "512"))), "temperature": float(val("TEMPERATURE", "0.2")), "system_prompt": val("SYSTEM_PROMPT")}
    legacy = {
        "enabled": values.get("LLM_ENABLED", "0").lower() in ("1", "true", "yes", "on"),
        "advisor_enabled": values.get("LLM_ADVISOR_ENABLED", "0").lower() in ("1", "true", "yes", "on"),
        "provider": values.get("LLM_PROVIDER") or "openai-compatible",
        "base_url": values.get("LLM_BASE_URL", ""),
        "model": values.get("LLM_MODEL", ""),
        "api_key": LLM_SECRET_MASK if key else "",
        "api_key_configured": bool(key),
        "timeout_sec": float(values.get("LLM_TIMEOUT_SEC") or 15),
        "max_tokens": int(float(values.get("LLM_MAX_TOKENS") or 512)),
        "temperature": float(values.get("LLM_TEMPERATURE") or 0.2),
        "system_prompt": values.get("LLM_SYSTEM_PROMPT", ""),
        "requires_restart": True,
        "health": {
            "last_test_ts": _llm_runtime["last_test_ts"],
            "last_test_ok": _llm_runtime["last_test_ok"],
            "last_test_error": _llm_runtime["last_test_error"],
            "last_probe_ts": _llm_runtime["last_probe_ts"],
            "last_probe_count": _llm_runtime["last_probe_count"],
            "usage": _llm_usage_snapshot(),
        },
    }
    legacy["primary"] = profile("PRIMARY", True)
    legacy["secondary"] = profile("SECONDARY", False)
    return legacy


def _quote_env(value: str) -> str:
    # dotenv-compatible double quoted value; escape backslash/quote/newlines.
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def _write_llm_env(payload: LlmSettingsPayload) -> None:
    if payload.base_url:
        parsed = urlparse(payload.base_url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise HTTPException(status_code=400, detail="base_url 必须是 http(s) URL")
    env_path = ROOT / ".env"
    original = env_path.read_text(encoding="utf-8") if env_path.exists() else ""
    lines = original.splitlines()
    primary = payload.primary or {}
    secondary = payload.secondary or {}
    def pick(obj: dict[str, Any], name: str, fallback: Any) -> Any:
        value = obj.get(name)
        return fallback if value is None else value
    updates = {
        "LLM_ENABLED": "1" if payload.enabled else "0",
        "LLM_ADVISOR_ENABLED": "1" if payload.advisor_enabled else "0",
        "LLM_PROVIDER": payload.provider.strip() or "openai-compatible",
        "LLM_BASE_URL": payload.base_url.strip(),
        "LLM_MODEL": payload.model.strip(),
        "LLM_TIMEOUT_SEC": str(payload.timeout_sec),
        "LLM_MAX_TOKENS": str(payload.max_tokens),
        "LLM_TEMPERATURE": str(payload.temperature),
        "LLM_SYSTEM_PROMPT": payload.system_prompt,
    }
    if payload.api_key is not None and payload.api_key.strip() and payload.api_key.strip() != LLM_SECRET_MASK:
        updates["LLM_API_KEY"] = payload.api_key.strip()
    for slot, obj, fallback in (("PRIMARY", primary, payload), ("SECONDARY", secondary, None)):
        prefix = "LLM_" + slot + "_"
        updates[prefix + "ENABLED"] = "1" if bool(pick(obj, "enabled", getattr(fallback, "enabled", False))) else "0"
        updates[prefix + "PROVIDER"] = str(pick(obj, "provider", getattr(fallback, "provider", "openai-compatible")) or "openai-compatible")
        updates[prefix + "BASE_URL"] = str(pick(obj, "base_url", getattr(fallback, "base_url", "")) or "")
        updates[prefix + "MODEL"] = str(pick(obj, "model", getattr(fallback, "model", "")) or "")
        updates[prefix + "TIMEOUT_SEC"] = str(pick(obj, "timeout_sec", getattr(fallback, "timeout_sec", 30)) or 30)
        updates[prefix + "MAX_TOKENS"] = str(pick(obj, "max_tokens", getattr(fallback, "max_tokens", 512)) or 512)
        updates[prefix + "TEMPERATURE"] = str(pick(obj, "temperature", getattr(fallback, "temperature", 0.2)) or 0.2)
        updates[prefix + "SYSTEM_PROMPT"] = str(pick(obj, "system_prompt", getattr(fallback, "system_prompt", "")) or "")
        key_value = pick(obj, "api_key", None)
        if isinstance(key_value, str) and key_value.strip() and key_value.strip() != LLM_SECRET_MASK:
            updates[prefix + "API_KEY"] = key_value.strip()
    seen: set[str] = set()
    out: list[str] = []
    key_re = re.compile(r"^([A-Z][A-Z0-9_]*)=(.*)$")
    for line in lines:
        match = key_re.match(line)
        key = match.group(1) if match else ""
        if key in updates:
            out.append(f"{key}={_quote_env(updates[key])}")
            seen.add(key)
        else:
            out.append(line)
    for key, value in updates.items():
        if key not in seen:
            out.append(f"{key}={_quote_env(value)}")
    tmp = env_path.with_suffix(".env.tmp")
    tmp.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
    tmp.replace(env_path)
    try:
        os.chmod(env_path, 0o600)
    except OSError:
        pass


# In-memory rolling state, refreshed by background tasks.
# The public Data API is eventually consistent after a trade/redeem. Keep the
# last confirmed open value for a short grace period so a transient empty/0
# response never flashes a false zero in the live dashboard.
_POSITION_VALUE_CACHE: dict[str, Any] = {"ts": 0.0, "value": None, "positions": []}
_POSITION_VALUE_GRACE_SEC = 15.0

_state: dict[str, Any] = {
    "ts": 0.0,
    "market": None,           # LiveMarket as dict
    "eth_market": None,
    "book_up": None,
    "book_down": None,
    "eth_book_up": None,
    "eth_book_down": None,
    "btc_signal": None,
    "eth_signal": None,
    # Short rolling spot-price history used by the dashboard's background
    # volatility charts.  Keeping this in the dashboard process avoids adding
    # another database write on every market-data tick.
    "btc_price_history": [],
    "eth_price_history": [],
    "balance_pusd": None,     # on-chain pUSD in deposit wallet
    "balance_usdce": None,    # on-chain bridged USDC.e awaiting activation
    "positions": [],          # data-api positions for deposit wallet
    "value_usd": None,        # active live position market value
    "value_source": None,     # data_api_v2 or live_ledger_entry_cost_fallback
    "polymarket_profile": None,
    "bot_running": False,
    "bot_assets": {"BTC": False, "ETH": False},
    "errors": {},             # last error per poller for debugging
    # Informational feeds displayed in the dashboard.  Weather is read-only
    # forecast data; sports is backed by the isolated paper service and never
    # submits CLOB orders.
    "weather": [],
    "sports": [],
    "sports_meta": {},
    "agent_status": {},
}

# The OpenClaw heartbeat publisher owns the eight workflow roles below.  The
# weather/sports paper feeds are separate workers and intentionally do not
# publish OpenClaw role heartbeats.  Keep the two sets distinct so a missing
# optional feed cannot invalidate an otherwise healthy heartbeat and make the
# UI fall back to an all-zero queue snapshot.
OPENCLAW_AGENT_IDS = ("desk", "search", "whale", "shill", "risk", "sniper", "exit", "rug")
OPENCLAW_WORKFLOW_AGENT_IDS = ("desk", "search", "whale", "shill", "risk", "sniper", "exit", "rug")


def _openclaw_scope_defaults() -> tuple[dict[str, str], dict[str, Any]]:
    """Build market-data and execution scopes independently."""
    env = _control_env_values()
    try:
        process_mode = (ROOT / "bot.mode").read_text(encoding="utf-8").strip().lower()
    except OSError:
        process_mode = "paper"
    data_scope = {"BTC": "live" if process_mode in ("live", "paper") else "paper"}
    btc_live = env.get("BTC_LIVE_ENABLED", "false").lower() in ("1", "true", "yes", "on") and process_mode == "live"
    eth_live = env.get("ETH_TRADING_ENABLED", "false").lower() in ("1", "true", "yes", "on") and process_mode == "live"
    execution = {role: ("btc_l2_live" if role == "sniper" and btc_live else
                        "btc_close_only_live" if role == "exit" and btc_live else
                        "btc_emergency_live" if role == "rug" and btc_live else
                        "risk_gate" if role == "risk" else "read_only")
                 for role in OPENCLAW_AGENT_IDS}
    if eth_live and not btc_live:
        execution.update({"sniper": "eth_l2_live", "exit": "eth_close_only_live", "rug": "eth_emergency_live"})
    return data_scope, execution

AGENTS_STATUS_PATH = ROOT / "agents" / "out" / "agent_status.json"
_SLOW_LOOP_ALIAS = {"review": "desk"}  # review work surfaces under the desk card
_SLOW_LOOP_MAX_AGE_SEC = 1200          # timer cadence 10min + margin


def _slow_loop_overlay(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Overlay REAL per-role slow-loop status (agents/run.py) onto the base
    snapshot.  Roles the slow loop actually ran show their true stage and
    timings; everything else keeps the base entry.  Read-only and failure-
    silent: a missing or stale file changes nothing."""
    try:
        if not AGENTS_STATUS_PATH.exists():
            return snapshot
        if time.time() - AGENTS_STATUS_PATH.stat().st_mtime > _SLOW_LOOP_MAX_AGE_SEC:
            return snapshot
        payload = json.loads(AGENTS_STATUS_PATH.read_text(encoding="utf-8"))
        for role, info in (payload.get("roles") or {}).items():
            if not isinstance(info, dict) or info.get("kind") != "agent":
                continue
            target = _SLOW_LOOP_ALIAS.get(role, role)
            entry = snapshot.get(target)
            if entry is None:
                continue
            slow = entry.setdefault("slow_loop", {})
            slow[role] = {k: info.get(k) for k in (
                "status", "workflow_stage", "duration_ms", "heartbeat_ts",
                "n_reviews", "n_degraded", "whale_trades", "detail") if k in info}
            stage = info.get("workflow_stage")
            if stage and stage != "-" and role == target:
                entry["workflow_stage"] = f"slow-loop:{stage}"
            if info.get("status") == "error" and role == target:
                entry["status"] = "error"
                entry["detail"] = info.get("detail") or entry.get("detail")
    except (OSError, ValueError, TypeError):
        pass
    return snapshot


def _agent_status_snapshot() -> dict[str, Any]:
    """Expose truthful worker health for the UI; no OpenClaw worker is implied."""
    heartbeat_path = ROOT / "openclaw-heartbeat.json"
    try:
        if heartbeat_path.exists() and time.time() - heartbeat_path.stat().st_mtime < 20:
            payload = json.loads(heartbeat_path.read_text(encoding="utf-8"))
            if isinstance(payload, dict):
                instance = str(payload.get("instance", "")).strip().lower()
                pid = int(payload.get("pid", 0) or 0)
                expected = "polyauto" if _is_polyauto_instance() else "main"
                pid_alive = False
                if pid > 0:
                    try:
                        os.kill(pid, 0)
                        pid_alive = True
                    except (OSError, ProcessLookupError, ValueError):
                        pid_alive = False
                roles = payload.get("roles")
                if instance == expected and pid_alive and isinstance(roles, dict) and all(role in roles for role in OPENCLAW_WORKFLOW_AGENT_IDS):
                    default_scope, default_execution = _openclaw_scope_defaults()
                    payload_models = payload.get("model_calls") or payload.get("models") or {}
                    normalized: dict[str, Any] = {}
                    for role in OPENCLAW_AGENT_IDS:
                        item = dict(roles.get(role) or {})
                        # Weather and sports are isolated Paper producers, not
                        # OpenClaw workflow roles.  Add a truthful synthetic
                        # status for their cards while retaining the real
                        # queue/heartbeat values for the eight roles above.
                        if role not in roles:
                            meta = _state.get(f"{role}_meta") or {}
                            running_feed = bool(meta.get("running"))
                            feed_queue = meta.get("queue_depth")
                            if feed_queue is None:
                                feed_queue = meta.get("orders_new") or 0
                            item = {
                                "status": "running" if running_feed else "offline",
                                "heartbeat_ts": meta.get("heartbeat_ts"),
                                "queue_depth": int(feed_queue or 0),
                                "market": role.upper(),
                                "mode": "paper",
                                "detail": "独立 Paper 数据服务；无 OpenClaw 下单权限",
                                "last_decision_id": 0,
                                "last_order_id": 0,
                            }
                        item.setdefault("data_scope", dict(default_scope))
                        if isinstance(item.get("data_scope"), str):
                            item["data_scope"] = dict(default_scope)
                        item.setdefault("execution_scope", default_execution.get(role, "read_only"))
                        item.setdefault("model_calls", payload_models if isinstance(payload_models, dict) else {})
                        normalized[role] = item
                    return _slow_loop_overlay(normalized)
    except (OSError, ValueError, TypeError):
        pass
    running = bool(_state.get("bot_running"))
    paper_mode = _state.get("bot_mode") != "live"
    default_scope, default_execution = _openclaw_scope_defaults()

    # Fetch lifetime last IDs for fallback when today_counts is unavailable
    last_decision_id = 0
    last_order_id = 0
    try:
        import sqlite3
        conn = db()
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(id) FROM decisions")
        row = cursor.fetchone()
        last_decision_id = int(row[0] or 0)
        cursor.execute("SELECT MAX(id) FROM orders")
        row = cursor.fetchone()
        last_order_id = int(row[0] or 0)
        conn.close()
    except Exception:
        pass

    result: dict[str, Any] = {}
    for agent in OPENCLAW_AGENT_IDS:
        # The local Paper publisher represents all eight roles.  A role with
        # an empty queue is healthy and waiting, so expose it as running;
        # Paper mode itself remains the permission boundary for execution.
        status = "running" if running else "offline"
        result[agent] = {"status": status, "heartbeat_ts": time.time() if running else None, "queue_depth": 0, "market": "BTC", "mode": "paper" if paper_mode else "live", "detail": "Paper service; no OpenClaw signing permission" if paper_mode else "driven by strategy service", "last_decision_id": last_decision_id, "last_order_id": last_order_id}
        result[agent].update({"data_scope": dict(default_scope), "execution_scope": default_execution.get(agent, "read_only"), "model_calls": {"primary": "waiting", "secondary": "waiting"}})
    return _slow_loop_overlay(result)

def _openclaw_bridge_snapshot() -> dict[str, Any]:
    """Expose the read-only OpenClaw event bridge and its execution owner."""
    heartbeat_path = ROOT / "openclaw-heartbeat.json"
    try:
        if heartbeat_path.exists() and time.time() - heartbeat_path.stat().st_mtime < 20:
            payload = json.loads(heartbeat_path.read_text(encoding="utf-8"))
            bridge = payload.get("bridge")
            if isinstance(bridge, dict):
                return bridge
    except (OSError, ValueError, TypeError):
        pass
    return {"connected": False, "read_only": True, "strategy_owner": "deterministic-worker", "execution_owner": "l2-gateway"}

# Keep one service instance so paper decisions/exposure accumulate across
# dashboard polling cycles.  It has no live client and is deliberately not
# shared with the BTC/ETH workers.
# WEATHER/SPORTS are produced by independent Paper workers. The dashboard
# consumes atomic snapshots and never starts a second trading/scanning loop.

_PRICE_HISTORY_LIMIT = 180


def _record_price_history(asset: str, market_slug: str, signal: BtcSignal) -> None:
    """Append a sampled spot price for the dashboard chart.

    A new market window starts a fresh trace so the chart never joins prices
    from unrelated five-minute markets.  Values are intentionally kept small
    and serialisable; the UI normalises them to fit its compact SVG viewBox.
    """
    key = "eth_price_history" if asset == "ETH" else "btc_price_history"
    history = _state.setdefault(key, [])
    if history and history[-1].get("market_slug") != market_slug:
        history.clear()
    try:
        point = {
            "ts": float(signal.ts),
            "price": float(signal.current_price),
            "delta_usd": float(signal.delta_usd),
            "market_slug": market_slug,
        }
    except (TypeError, ValueError):
        return
    # Pollers can briefly return the same timestamp after a provider cache
    # hit.  Replace that sample instead of creating a visually noisy duplicate.
    if history and abs(float(history[-1].get("ts", 0)) - point["ts"]) < 0.01:
        history[-1] = point
    else:
        history.append(point)
    if len(history) > _PRICE_HISTORY_LIMIT:
        del history[:-_PRICE_HISTORY_LIMIT]


def _market_dict(m: LiveMarket) -> dict[str, Any]:
    return {
        "condition_id": m.condition_id,
        "market_slug": m.market_slug,
        "up_token": m.up_token,
        "down_token": m.down_token,
        "start_ts": m.start_ts,
        "end_ts": m.end_ts,
        "tick_size": m.tick_size,
        "neg_risk": m.neg_risk,
        "resolution_source": m.resolution_source,
    }


def _synthetic_market_dict(asset: str) -> dict[str, Any]:
    now = time.time()
    start_ts = math.floor(now / 300.0) * 300.0
    end_ts = start_ts + 300.0
    prefix = "eth-updown-5m" if asset == "ETH" else "btc-updown-5m"
    return {
        "condition_id": "",
        "market_slug": f"{prefix}-{int(start_ts)}",
        "up_token": "",
        "down_token": "",
        "start_ts": start_ts,
        "end_ts": end_ts,
        "tick_size": 0.01,
        "neg_risk": False,
        "resolution_source": "",
        "synthetic": True,
    }


def _signal_dict(sig: BtcSignal) -> dict[str, Any]:
    return {
        "ts": sig.ts,
        "symbol": sig.symbol,
        "source": sig.source,
        "source_ts": sig.source_ts,
        "age_sec": sig.age_sec,
        "feed_id": sig.feed_id,
        "price_to_beat": sig.price_to_beat,
        "current_price": sig.current_price,
        "delta_usd": sig.delta_usd,
        "signal_side": sig.signal_side,
        "threshold_usd": sig.threshold_usd,
        "up_min_delta_usd": sig.up_min_delta_usd,
        "up_max_delta_usd": sig.up_max_delta_usd,
        "down_min_delta_usd": sig.down_min_delta_usd,
        "down_max_delta_usd": sig.down_max_delta_usd,
    }


def _fallback_signal_from_decisions(asset: str) -> Optional[dict[str, Any]]:
    if not DB_PATH.exists():
        return None
    prefix = asset.lower()
    symbol = cfg.eth_price_symbol if asset == "ETH" else cfg.btc_price_symbol
    pattern = re.compile(
        rf"{prefix}_delta=([+-]?\d+(?:\.\d+)?) "
        r"price=(\d+(?:\.\d+)?) beat=(\d+(?:\.\d+)?) "
        r"signal=(UP|DOWN|FLAT)"
    )
    with db() as c:
        rows = c.execute(
            "SELECT ts, reason FROM decisions "
            "WHERE asset=? AND reason LIKE ? "
            "ORDER BY id DESC LIMIT 50",
            (asset, f"%{prefix}_delta=%"),
        ).fetchall()
    for row in rows:
        match = pattern.search(row["reason"] or "")
        if not match:
            continue
        delta, price, beat, side = match.groups()
        if asset == "ETH":
            threshold = cfg.eth_delta_threshold_usd
            up_min = cfg.eth_up_min_delta_usd
            up_max = cfg.eth_up_max_delta_usd
            down_min = cfg.eth_down_min_delta_usd
            down_max = cfg.eth_down_max_delta_usd
        else:
            threshold = cfg.btc_delta_threshold_usd
            up_min = cfg.btc_up_min_delta_usd
            up_max = cfg.btc_up_max_delta_usd
            down_min = cfg.btc_down_min_delta_usd
            down_max = cfg.btc_down_max_delta_usd
        return {
            "ts": row["ts"],
            "symbol": symbol,
            "source": "decision-log-stale",
            "price_to_beat": float(beat),
            "current_price": float(price),
            "delta_usd": float(delta),
            "signal_side": side,
            "threshold_usd": threshold,
            "up_min_delta_usd": up_min,
            "up_max_delta_usd": up_max,
            "down_min_delta_usd": down_min,
            "down_max_delta_usd": down_max,
            "stale": True,
        }
    return None


# ---------------------------------------------------------------------------
# SQLite reads


def db() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH, timeout=5.0)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=5000")
    c.execute("PRAGMA journal_mode=WAL")
    # Dashboard-only views keep historical products in the underlying ledger.
    # Trading workers continue to use bot.store and the original tables.
    for table in ("orders", "decisions"):
        c.execute(f"CREATE TEMP VIEW {table} AS SELECT * FROM main.{table} WHERE UPPER(COALESCE(asset, ''))='BTC'")
    return c


def _row(r: sqlite3.Row) -> dict:
    return {k: r[k] for k in r.keys()}


def local_day_start_ts(now: Optional[float] = None) -> float:
    """Start of the current Beijing trading day, shared with bot.store."""
    local_now = datetime.fromtimestamp(now if now is not None else time.time(), TRADING_TIMEZONE)
    return datetime.combine(local_now.date(), dt_time.min, tzinfo=TRADING_TIMEZONE).timestamp()


def recent_decisions(limit: int = 50, since_id: int = 0) -> list[dict]:
    if not DB_PATH.exists():
        return []
    with db() as c:
        # BTC/ETH emit many SKIP rows per cycle. A single global LIMIT hid the
        # independent WEATHER/SPORTS Paper activity from the realtime panel.
        # Keep incremental consumers lossless; for the dashboard preview use a
        # bounded newest-per-asset window and merge it by event id.
        if since_id:
            rows = c.execute(
                "SELECT id, ts, asset, market_slug, side, t_remaining, ask_price, ask_size, "
                "action, reason, dry_run FROM decisions WHERE id > ? "
                "ORDER BY id DESC LIMIT ?",
                (since_id, limit),
            ).fetchall()
            return [_row(r) for r in rows]
        assets = ("BTC",)
        per_asset = max(4, min(30, math.ceil(max(1, int(limit)) / len(assets))))
        rows: list[dict] = []
        for asset in assets:
            asset_rows = c.execute(
                "SELECT id, ts, asset, market_slug, side, t_remaining, ask_price, ask_size, "
                "action, reason, dry_run FROM decisions WHERE asset=? "
                "ORDER BY id DESC LIMIT ?",
                (asset, per_asset),
            ).fetchall()
            rows.extend(_row(r) for r in asset_rows)
        rows.sort(key=lambda row: int(row.get("id") or 0), reverse=True)
        return rows[:max(1, int(limit))]


def recent_orders(limit: int = 50, since_id: int = 0, *, offset: int = 0,
                  lane: str = "all", connection: Optional[sqlite3.Connection] = None) -> list[dict]:
    if not DB_PATH.exists():
        return []
    if lane not in ("all", "paper", "live"):
        raise ValueError("invalid order lane")
    if connection is None:
        with closing(db()) as c:
            return recent_orders(limit, since_id, offset=offset, lane=lane, connection=c)
    # The history route passes its read transaction so COUNT and rows use the
    # same SQLite snapshot. Reuse the established result/exit projection.
    with connection as c:
        lane_filter = "" if lane == "all" else " AND o.dry_run=?"
        params = [since_id]
        if lane != "all":
            params.append(1 if lane == "paper" else 0)
        params.extend([max(1, min(int(limit), 200)), max(0, int(offset))])
        rows = c.execute(
            "SELECT o.id, o.ts, o.market_slug, o.condition_id, o.token_id, "
            "o.asset, o.side, o.size, o.price, o.order_id, o.status, o.filled_size, "
            "o.error, o.entry_rule, o.dry_run, r.winning_token, r.resolved_ts, "
            "x.exit_status, x.exit_ts, x.exit_size "
            "FROM orders o LEFT JOIN resolutions r ON r.condition_id = o.condition_id "
            "LEFT JOIN ("
            "  SELECT condition_id, token_id, dry_run, MAX(status) AS exit_status, "
            "  MAX(ts) AS exit_ts, SUM(size) AS exit_size "
            "  FROM orders "
            "  WHERE status IN ('exit_filled','exit_matched','exit_partial','exit_dry_run') "
            "  GROUP BY condition_id, token_id, dry_run"
            ") x ON x.condition_id=o.condition_id "
            "AND x.token_id=o.token_id AND x.dry_run=o.dry_run "
            f"WHERE o.id > ?{lane_filter} ORDER BY o.id DESC LIMIT ? OFFSET ?",
            params,
        ).fetchall()
        out = []
        for r in rows:
            item = _row(r)
            is_exit = str(item["side"] or "").startswith("SELL_") or str(item["status"] or "").startswith("exit_")
            # FOK/FAK rejection is expected when the rapidly changing book no
            # longer has enough matching liquidity.  It remains an open
            # position and is retried on the next fresh quote, so don't present
            # it as a wallet/API failure in the dashboard.
            exit_unmatched = (
                is_exit
                and item["status"] in ("exit_error", "exit_pre_submit_error")
                and _is_exit_unmatched_error(item.get("error"))
            )
            if exit_unmatched:
                item["status"] = "exit_unmatched"
            exit_effective = item["status"] in ("exit_filled", "exit_matched", "exit_partial", "exit_dry_run")
            effective = (
                item["side"] in ("UP", "DOWN") and item["status"] in ("filled", "matched")
                or (item["dry_run"] == 1 and item["status"] == "dry_run")
            )
            if is_exit:
                if item["status"] == "exit_partial":
                    item["result"] = "PARTIAL_EXIT"
                elif exit_unmatched:
                    item["result"] = "EXIT_UNMATCHED"
                else:
                    item["result"] = (
                        "EXITED"
                        if exit_effective
                        else (
                            "EXIT_UNCERTAIN"
                            if item["status"] == "exit_timeout_pending_reconcile"
                            else "EXIT_FAILED"
                        )
                    )
            elif item["exit_status"] is not None:
                item["result"] = (
                    "PARTIAL_EXIT"
                    if item["exit_size"] is not None
                    and float(item["exit_size"]) < float(item["size"]) - 0.02
                    else "EXITED"
                )
            elif item["status"] == "timeout_pending_reconcile":
                item["result"] = "UNCERTAIN"
            elif not effective:
                item["result"] = (
                    "FAILED"
                    if item["status"] in ("error", "pre_submit_error")
                    else "NONE"
                )
            elif item["winning_token"] is None:
                item["result"] = "PENDING"
            elif item["token_id"] == item["winning_token"]:
                item["result"] = "HIT"
            else:
                item["result"] = "MISS"
            item["settled"] = (
                item["winning_token"] is not None
                or item["exit_status"] is not None
                or exit_effective
            )
            out.append(item)
        return out


def _orders_total(connection: Optional[sqlite3.Connection] = None, lane: str = "all") -> int:
    """Count ledger rows, including exits/rejections, never the 30-row window."""
    if not DB_PATH.exists():
        return 0
    if lane not in ("all", "paper", "live"):
        raise ValueError("invalid order lane")
    if connection is None:
        with closing(db()) as c:
            return _orders_total(c, lane)
    where = "" if lane == "all" else " WHERE dry_run=?"
    params = () if lane == "all" else (1 if lane == "paper" else 0,)
    return int(connection.execute("SELECT COUNT(*) FROM orders" + where, params).fetchone()[0])


def _is_exit_unmatched_error(error: object) -> bool:
    """True for an exchange liquidity miss that is safe to retry.

    Polymarket returns HTTP 400 for both FOK "not fully filled" and FAK "no
    orders found".  These are normal market outcomes, unlike malformed orders,
    rejected signatures, insufficient balance, or network failures.
    """
    text = str(error or "").lower()
    return (
        "couldn't be fully filled" in text
        or "couldn't be fully fill" in text
        or "no orders found to match" in text
        or "fok orders are fully filled or killed" in text
        or "fak orders are partially filled or killed" in text
    )


def _today_counts() -> dict[str, Any]:
    """Return Beijing-trading-day cumulative decision and order counts.

    Resets at 00:00 Beijing time (UTC+8). Falls back to zero when the DB is
    unavailable; the frontend degrades to lifetime last_*_id when this returns None.
    """
    try:
        # Use the same Beijing trading day as the worker risk gate and daily PnL.
        since_ts = int(local_day_start_ts())

        import sqlite3
        conn = db()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM decisions WHERE ts >= ?", (since_ts,))
        decisions = int(cursor.fetchone()[0] or 0)

        cursor.execute("SELECT COUNT(*) FROM orders WHERE ts >= ?", (since_ts,))
        orders = int(cursor.fetchone()[0] or 0)

        conn.close()

        return {"decisions": decisions, "orders": orders, "since": since_ts}
    except Exception:
        return {"decisions": 0, "orders": 0, "since": 0}


def realized_pnl_today() -> dict:
    """Read the same canonical PnL summary used by the bot risk gate.

    Resolution lookups run in the background; the API must remain a local,
    bounded-latency read even when Gamma is slow or unavailable.
    """
    # Select the active ledger; Paper must not read the live wallet ledger.
    return realized_pnl_summary_today(_state.get("bot_mode") != "live")


_resolved_cache: dict[str, Optional[str]] = {}


def _resolved_winning_token(market_slug: str) -> Optional[str]:
    """Return the winning token_id for a resolved market, or None if unresolved.

    Gamma's `condition_ids` filter hides closed markets — query by slug instead.
    Cached in-process; markets resolve immutably so cache hits are safe.
    """
    if not market_slug:
        return None
    if market_slug in _resolved_cache:
        return _resolved_cache[market_slug]
    try:
        r = requests.get(
            f"{cfg.gamma_host}/markets",
            params={"slug": market_slug, "closed": "true"},
            timeout=3,
        )
        if r.status_code != 200:
            return None
        markets = r.json()
        if not markets:
            return None
        m = markets[0] if isinstance(markets, list) else markets
        if not m.get("closed"):
            return None
        prices = m.get("outcomePrices")
        if isinstance(prices, str):
            import json as _json
            prices = _json.loads(prices)
        if not prices or len(prices) != 2:
            return None
        token_ids = m.get("clobTokenIds")
        if isinstance(token_ids, str):
            import json as _json
            token_ids = _json.loads(token_ids)
        if not token_ids or len(token_ids) != 2:
            return None
        winner_idx = 0 if float(prices[0]) > float(prices[1]) else 1
        winner = str(token_ids[winner_idx])
        _resolved_cache[market_slug] = winner
        return winner
    except Exception:
        return None


def _record_resolution(condition_id: str, winning_token: str) -> None:
    with db() as c:
        c.execute(
            "INSERT OR REPLACE INTO resolutions (condition_id, winning_token, resolved_ts) "
            "VALUES (?,?,?)",
            (condition_id, winning_token, time.time()),
        )


# ---------------------------------------------------------------------------
# Background pollers


async def poll_market_loop():
    while True:
        try:
            m = await asyncio.to_thread(
                fetch_live_market,
                cfg.gamma_host,
                cfg.series_slug,
            )
            if m:
                _state["market"] = _market_dict(m)
            elif (
                _state.get("market") is None
                or _state["market"].get("synthetic")
                or time.time() > _state["market"]["end_ts"] + cfg.market_stale_grace_sec
            ):
                _state["market"] = _synthetic_market_dict("BTC")
            _state["errors"].pop("market", None)
        except Exception as e:
            _state["market"] = _synthetic_market_dict("BTC")
            _state["errors"]["market"] = str(e)
        await asyncio.sleep(2.0)


async def poll_eth_market_loop():
    while True:
        if not cfg.eth_market_enabled:
            _state["eth_market"] = None
            await asyncio.sleep(2.0)
            continue
        try:
            m = await asyncio.to_thread(
                fetch_live_market,
                cfg.gamma_host,
                cfg.eth_series_slug,
            )
            if m:
                _state["eth_market"] = _market_dict(m)
            elif (
                _state.get("eth_market") is None
                or _state["eth_market"].get("synthetic")
                or time.time() > _state["eth_market"]["end_ts"] + cfg.market_stale_grace_sec
            ):
                _state["eth_market"] = _synthetic_market_dict("ETH")
            _state["errors"].pop("eth_market", None)
        except Exception as e:
            _state["eth_market"] = _synthetic_market_dict("ETH")
            _state["errors"]["eth_market"] = str(e)
        await asyncio.sleep(2.0)


async def poll_book_loop():
    while True:
        m = _state.get("market")
        if not m:
            await asyncio.sleep(0.5)
            continue
        if not m.get("up_token") or not m.get("down_token"):
            _state["book_up"] = None
            _state["book_down"] = None
            await asyncio.sleep(0.5)
            continue
        try:
            bu, bd = await asyncio.gather(
                asyncio.to_thread(fetch_book, cfg.clob_host, m["up_token"]),
                asyncio.to_thread(fetch_book, cfg.clob_host, m["down_token"]),
            )
            _state["book_up"] = {
                "best_bid": bu.best_bid,
                "bid_size": bu.bid_size,
                "best_ask": bu.best_ask,
                "ask_size": bu.ask_size,
            }
            _state["book_down"] = {
                "best_bid": bd.best_bid,
                "bid_size": bd.bid_size,
                "best_ask": bd.best_ask,
                "ask_size": bd.ask_size,
            }
            _state["errors"].pop("book", None)
        except Exception as e:
            _state["errors"]["book"] = str(e)
        await asyncio.sleep(0.25)


async def poll_eth_book_loop():
    while True:
        m = _state.get("eth_market")
        if not m:
            _state["eth_book_up"] = None
            _state["eth_book_down"] = None
            await asyncio.sleep(0.5)
            continue
        if not m.get("up_token") or not m.get("down_token"):
            _state["eth_book_up"] = None
            _state["eth_book_down"] = None
            await asyncio.sleep(0.5)
            continue
        try:
            bu, bd = await asyncio.gather(
                asyncio.to_thread(fetch_book, cfg.clob_host, m["up_token"]),
                asyncio.to_thread(fetch_book, cfg.clob_host, m["down_token"]),
            )
            _state["eth_book_up"] = {
                "best_bid": bu.best_bid,
                "bid_size": bu.bid_size,
                "best_ask": bu.best_ask,
                "ask_size": bu.ask_size,
            }
            _state["eth_book_down"] = {
                "best_bid": bd.best_bid,
                "bid_size": bd.bid_size,
                "best_ask": bd.best_ask,
                "ask_size": bd.ask_size,
            }
            _state["errors"].pop("eth_book", None)
        except Exception as e:
            _state["errors"]["eth_book"] = str(e)
        await asyncio.sleep(0.25)


async def poll_btc_signal_loop():
    while True:
        m = _state.get("market")
        # BTC signal is also a dashboard display feed. The entry filter can be
        # disabled without hiding the live BTC price and delta from the UI.
        if not m:
            _state["btc_signal"] = None
            await asyncio.sleep(1.0)
            continue
        try:
            market = LiveMarket(
                condition_id=m["condition_id"],
                market_slug=m["market_slug"],
                up_token=m["up_token"],
                down_token=m["down_token"],
                start_ts=m["start_ts"],
                end_ts=m["end_ts"],
                tick_size=m["tick_size"],
                neg_risk=m["neg_risk"],
                resolution_source=m.get("resolution_source", ""),
            )
            sig = await asyncio.to_thread(fetch_btc_signal, cfg, market)
            _state["btc_signal"] = _signal_dict(sig)
            _record_price_history("BTC", m["market_slug"], sig)
            _state["errors"].pop("btc_signal", None)
        except Exception as e:
            _state["btc_signal"] = None
            _state["errors"]["btc_signal"] = str(e)
        await asyncio.sleep(1.0)


async def poll_eth_signal_loop():
    while True:
        m = _state.get("eth_market")
        if not m or not cfg.eth_market_enabled:
            _state["eth_signal"] = None
            await asyncio.sleep(1.0)
            continue
        try:
            market = LiveMarket(
                condition_id=m["condition_id"],
                market_slug=m["market_slug"],
                up_token=m["up_token"],
                down_token=m["down_token"],
                start_ts=m["start_ts"],
                end_ts=m["end_ts"],
                tick_size=m["tick_size"],
                neg_risk=m["neg_risk"],
                resolution_source=m.get("resolution_source", ""),
            )
            sig = await asyncio.to_thread(fetch_eth_signal, cfg, market)
            _state["eth_signal"] = _signal_dict(sig)
            _record_price_history("ETH", m["market_slug"], sig)
            _state["errors"].pop("eth_signal", None)
        except Exception as e:
            _state["eth_signal"] = None
            _state["errors"]["eth_signal"] = str(e)
        await asyncio.sleep(1.0)


def _normalize_data_api_position(position: dict[str, Any]) -> dict[str, Any]:
    """Normalize Polymarket Data API v2 positions to the dashboard schema.

    Data API v1 used camelCase fields (``size``, ``curPrice``,
    ``currentValue``) while v2 returns snake_case fields and wraps the list
    in ``data``.  Keeping one internal shape prevents the risk snapshot and
    position modal from silently treating live positions as empty.
    """
    if not isinstance(position, dict):
        return {}
    row = dict(position)

    def first(*keys: str):
        for key in keys:
            value = position.get(key)
            if value is not None:
                return value
        return None

    size = first("size", "current_size", "currentSize", "total_size", "totalSize")
    price = first("curPrice", "current_price", "currentPrice")
    value = first("currentValue", "current_value", "currentValueUsd")
    token_id = first("tokenId", "token_id")
    condition_id = first("conditionId", "condition_id")
    if size is not None:
        row["size"] = size
    if price is not None:
        row["curPrice"] = price
    if value is None and size is not None and price is not None:
        try:
            value = float(size) * float(price)
        except (TypeError, ValueError):
            value = None
    if value is not None:
        row["currentValue"] = value
    if token_id is not None:
        row["tokenId"] = token_id
    if condition_id is not None:
        row["conditionId"] = condition_id
    row.setdefault("asset", "BTC" if "btc" in str(first("slug", "title") or "").lower() else "")
    return row


def _normalize_ledger_position(position: dict[str, Any]) -> dict[str, Any]:
    """Expose a matched local live lot when Data API v2 is briefly empty."""
    if not isinstance(position, dict):
        return {}
    row = dict(position)
    row.setdefault("asset", str(position.get("asset") or "BTC").upper())
    row.setdefault("conditionId", position.get("condition_id"))
    row.setdefault("tokenId", position.get("token_id"))
    row.setdefault("slug", position.get("market_slug"))
    row.setdefault("size", position.get("size"))
    row.setdefault("curPrice", position.get("price"))
    row.setdefault("currentValue", position.get("notional_usd"))
    return row


def _account_positions_snapshot() -> dict[str, Any]:
    """One immutable display snapshot, independent of worker mode/ledger."""
    return _state.get("portfolio_positions") or {
        "available": False, "stale": False, "source": "data_api_v2_positions",
        "updated_at": None, "error": None, "positions": [], "settled_positions": [],
        "pending_count": None, "redeemable_count": None,
        "pending_value_usd": None, "redeemable_value_usd": None, "total_value_usd": None,
    }


async def poll_positions_loop():
    while True:
        wallet = _deposit_wallet_address()
        try:
            if not re.fullmatch(r"0x[0-9a-fA-F]{40}", wallet or ""):
                raise ValueError("wallet_unconfigured")
            snapshot = await asyncio.to_thread(fetch_portfolio_positions, wallet, timeout=5)
            # Publish rows, subtotals and counts together. Do not substitute
            # local entry costs when the indexer has no account holdings.
            _state["portfolio_positions"] = snapshot
            _state["positions"] = snapshot["positions"] + snapshot["settled_positions"]
            _state["value_usd"] = snapshot["total_value_usd"]
            _state["value_source"] = snapshot["source"]
            _state["errors"].pop("positions", None)
            _state["errors"].pop("value", None)
        except Exception as exc:
            prior = _account_positions_snapshot()
            snapshot = {**prior, "stale": bool(prior.get("available")),
                        "error": str(exc), "last_attempt_ts": time.time()}
            _state["portfolio_positions"] = snapshot
            _state["errors"]["positions"] = str(exc)
        await asyncio.sleep(2.0)


async def poll_balance_loop():
    """Read pUSD and bridged USDC.e balances of the configured deposit wallet.

    The Polymarket ``Activate Funds`` prompt is backed by the bridged USDC.e
    balance until the wallet has wrapped it into pUSD.  Reading that balance
    is safe and lets the dashboard include the pending amount in the portfolio
    total; it does not submit an approval or wrap transaction.
    """
    PUSD = "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB"
    USDCE = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"
    SELECTOR = "0x70a08231"
    deposit_wallet = _deposit_wallet_address()
    while True:
        if not re.fullmatch(r"0x[0-9a-fA-F]{40}", deposit_wallet):
            _state["balance_pusd"] = None
            _state["balance_usdce"] = None
            _state["errors"].pop("balance", None)
            await asyncio.sleep(10.0)
            continue
        try:
            data = SELECTOR + deposit_wallet.lower().replace("0x", "").rjust(64, "0")
            def read_token(token: str) -> float:
                response = requests.post(
                    cfg.polygon_rpc,
                    json={
                        "jsonrpc": "2.0",
                        "id": 1,
                        "method": "eth_call",
                        "params": [{"to": token, "data": data}, "latest"],
                    },
                    timeout=5,
                )
                response.raise_for_status()
                payload = response.json()
                if payload.get("error"):
                    raise RuntimeError(f"RPC error: {payload['error']}")
                raw = payload.get("result")
                if not isinstance(raw, str) or not re.fullmatch(r"0x[0-9a-fA-F]{64}", raw):
                    raise ValueError("RPC balance response missing 32-byte result")
                value = int(raw, 16) / 1e6
                if not math.isfinite(value) or value < 0:
                    raise ValueError("RPC balance returned invalid value")
                return value

            _state["balance_pusd"] = read_token(PUSD)
            _state["balance_usdce"] = read_token(USDCE)
            _state["errors"].pop("balance", None)
            _state["errors"].pop("balance_usdce", None)
        except Exception as e:
            _state["balance_pusd"] = None
            _state["balance_usdce"] = None
            _state["errors"]["balance"] = str(e)
        await asyncio.sleep(5.0)


def _weather_feed_snapshot() -> list[dict[str, Any]]:
    """Build a small read-only weather feed for the dashboard.

    Forecasts are fetched through the same parser/model used by the weather
    paper worker.  This function intentionally stops at presentation data and
    never calls a CLOB order method.
    """
    if not bool(getattr(cfg, "weather_enabled", False)):
        return []
    markets = fetch_weather_markets(cfg)
    rows: list[dict[str, Any]] = []
    seen_cities: set[str] = set()
    for market in markets[:12]:
        try:
            forecast = fetch_ensemble_forecast(cfg, market.city_key, market.target_date)
            signal = build_signal(cfg, market, forecast)
            mean_f = forecast.low_mean if market.metric == "low" else forecast.high_mean
            probability = (
                signal.model_yes_probability
                if signal.side == "UP"
                else signal.model_no_probability
            )
            city = str(CITY_CONFIG.get(market.city_key, {}).get("name") or market.city_key)
            seen_cities.add(market.city_key)
            rows.append(
                {
                    "city": city,
                    "condition": f"{market.metric} {market.threshold_f:.0f}°F · {signal.side}",
                    "temperature_c": round((mean_f - 32.0) * 5.0 / 9.0, 1),
                    "probability": round(float(probability), 6),
                    "source": "Open-Meteo ensemble",
                    "updated_ts": time.time(),
                    "market_slug": market.slug,
                    "target_date": market.target_date.isoformat(),
                    "edge": round(float(signal.edge), 6),
                }
            )
        except Exception as exc:
            log_msg = f"{market.slug or market.market_key}: {exc}"
            # A single malformed/temporarily unavailable city must not hide
            # all other weather rows.
            _state["errors"]["weather_item"] = str(log_msg)[:300]

    # Weather markets can be absent between event batches.  Keep the card a
    # useful real-time feed by showing today's ensemble forecast for configured
    # cities even when there is no tradable market to attach it to.
    today = datetime.now(TRADING_TIMEZONE).date()
    try:
        city_keys = configured_city_keys(cfg)
    except Exception:
        city_keys = [key.strip().lower() for key in str(getattr(cfg, "weather_cities", "")).split(",") if key.strip()]
    for city_key in city_keys:
        if city_key in seen_cities or len(rows) >= 8:
            continue
        try:
            forecast = fetch_ensemble_forecast(cfg, city_key, today)
            mean_f = forecast.high_mean
            city = str(CITY_CONFIG.get(city_key, {}).get("name") or city_key)
            rows.append(
                {
                    "city": city,
                    "condition": "今日最高（ensemble）",
                    "temperature_c": round((mean_f - 32.0) * 5.0 / 9.0, 1),
                    "probability": None,
                    "source": "Open-Meteo ensemble",
                    "updated_ts": time.time(),
                    "market_slug": None,
                    "target_date": today.isoformat(),
                }
            )
        except Exception as exc:
            _state["errors"]["weather_item"] = str(exc)[:300]
    return rows[:8]


async def poll_weather_loop():
    """Consume the weather worker's persisted Paper state without producing orders."""
    while True:
        try:
            snapshot = await asyncio.to_thread(read_paper_feed_snapshot, "WEATHER")
            _state["weather"] = snapshot.get("rows") or []
            _state["weather_meta"] = snapshot
            if snapshot.get("error"):
                _state["errors"]["weather"] = str(snapshot["error"])[:500]
            else:
                _state["errors"].pop("weather", None)
        except Exception as exc:
            _state["weather"] = []
            _state["errors"]["weather"] = str(exc)
        await asyncio.sleep(3.0)


def _sports_feed_snapshot(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """Convert the sports paper service snapshot into compact UI rows."""
    rows: list[dict[str, Any]] = []
    for market in (snapshot.get("markets") or [])[:8]:
        outcomes = market.get("outcomes") or []
        prices = market.get("prices") or []
        try:
            probability = float(prices[0]) / max(sum(float(p) for p in prices[:2]), 1e-9)
        except (IndexError, TypeError, ValueError):
            probability = None
        rows.append(
            {
                "league": market.get("league") or market.get("sport") or "体育",
                "event": market.get("event_name") or market.get("question") or market.get("slug"),
                "status": "PAPER · 监控",
                "start_ts": market.get("event_start_ts"),
                "home_team": outcomes[0] if len(outcomes) > 0 else None,
                "away_team": outcomes[1] if len(outcomes) > 1 else None,
                "probability_home": probability,
                "source": "Gamma + market-implied",
                "market_slug": market.get("slug"),
                "neg_risk": bool(market.get("neg_risk")),
            }
        )
    return rows


async def poll_sports_loop():
    """Read the sole sports Paper producer instead of a second in-memory scanner."""
    while True:
        try:
            snapshot = await asyncio.to_thread(read_paper_feed_snapshot, "SPORTS")
            _state["sports"] = snapshot.get("rows") or []
            _state["sports_meta"] = snapshot
            if snapshot.get("error"):
                _state["errors"]["sports"] = str(snapshot["error"])[:500]
            else:
                _state["errors"].pop("sports", None)
        except Exception as exc:
            _state["sports"] = []
            _state["sports_meta"] = {"enabled": bool(getattr(cfg, "sports_enabled", False)), "mode": "paper", "status": "error", "paper_only": True, "live_orders": False}
            _state["errors"]["sports"] = str(exc)
        await asyncio.sleep(3.0)


async def poll_bot_running_loop():
    pid_path = ROOT / "bot.pid"
    btc_pid_path = ROOT / "bot_btc.pid"
    eth_pid_path = ROOT / "bot_eth.pid"
    mode_path = ROOT / "bot.mode"

    def pid_exists(pid: int) -> bool:
        import os
        if os.name == "nt":
            import ctypes

            process_query_limited_information = 0x1000
            handle = ctypes.windll.kernel32.OpenProcess(
                process_query_limited_information, False, pid
            )
            if not handle:
                return False
            ctypes.windll.kernel32.CloseHandle(handle)
            return True
        try:
            os.kill(pid, 0)  # signal 0 = check existence
            return True
        except (ProcessLookupError, ValueError, PermissionError, OSError):
            return False

    while True:
        asset_running = {"BTC": False, "ETH": False}
        for asset, asset_pid_path in (
            ("BTC", btc_pid_path if btc_pid_path.exists() else pid_path),
            ("ETH", eth_pid_path),
        ):
            if not asset_pid_path.exists():
                continue
            try:
                pid = int(asset_pid_path.read_text().strip())
                asset_running[asset] = pid_exists(pid)
            except ValueError:
                asset_running[asset] = False
        running = any(asset_running.values())
        if pid_path.exists():
            try:
                pid = int(pid_path.read_text().strip())
                running = running or pid_exists(pid)
            except ValueError:
                pass
        mode = "unknown"
        if mode_path.exists():
            try:
                mode = mode_path.read_text().strip() or "unknown"
            except Exception:
                pass
        if not running:
            mode = "stopped"
        _state["bot_running"] = running
        _state["bot_assets"] = asset_running
        _state["bot_mode"] = mode
        await asyncio.sleep(2.0)


async def poll_resolution_loop():
    """Back-fill settlement outcomes without blocking dashboard requests."""
    while True:
        try:
            await asyncio.gather(
                asyncio.to_thread(resolve_pending, cfg, False),
                asyncio.to_thread(resolve_pending, cfg, True),
            )
            _state["errors"].pop("resolution", None)
        except Exception as e:
            _state["errors"]["resolution"] = str(e)
        await asyncio.sleep(30.0)


# ---------------------------------------------------------------------------
# FastAPI app

app = FastAPI(title="poly_hft dashboard")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


_RISK_WORKER_FIELDS = {'max_daily_loss_fraction': 'MAX_DAILY_LOSS_FRACTION', 'max_daily_realized_profit_fraction': 'MAX_DAILY_REALIZED_PROFIT_FRACTION', 'max_daily_realized_profit_usd': 'MAX_DAILY_REALIZED_PROFIT_USD', 'paper_equity_usd': 'PAPER_EQUITY_USD', 'reversal_held_bid_drawdown': 'REVERSAL_HELD_BID_DRAWDOWN', 'order_risk_fraction': 'ORDER_RISK_FRACTION'}

_paper_worker_loss_cache = {}

_kelly_flag_cache = {"ts": 0.0}

_risk_settings_lock = asyncio.Lock()

def _risk_env_paths() -> list[Path]:
    """Return every env file consumed by the active Paper worker.

    The polyauto dashboard runs from ``ROOT/.env`` while the restored C
    strategy is selected by a systemd drop-in that points the BTC worker at a
    release-specific ``.env``.  Updating only ROOT therefore made the panel
    show one threshold while the running worker enforced another one.  Read
    the unit's EnvironmentFiles property so future release switches follow
    the active unit automatically.
    """
    paths: list[Path] = [ROOT / ".env"]
    if True:
        try:
            result = subprocess.run(
                ["systemctl", "show", "--property=EnvironmentFiles", "--value", "polymarket-test-btc-paper.service"],
                text=True,
                capture_output=True,
                timeout=5,
                check=False,
            )
            # EnvironmentFiles is a whitespace-separated list.  A leading
            # '-' means systemd treats a file as optional; strip it before
            # resolving the actual path.
            for raw in result.stdout.split():
                value = raw[1:] if raw.startswith("-") else raw
                if value.endswith(".env"):
                    candidate = Path(value).expanduser()
                    if candidate.is_file():
                        paths.append(candidate)
        except (OSError, subprocess.SubprocessError):
            # ROOT/.env remains the safe fallback; the endpoint will still
            # reject an invalid request before restarting the worker.
            pass
    unique: list[Path] = []
    seen: set[str] = set()
    for path in paths:
        key = str(path.resolve())
        if key not in seen:
            seen.add(key)
            unique.append(path)
    return unique

def _update_env_keys(changes: dict[str, str]) -> list[str]:
    """Atomically update dashboard and active-worker env files.

    Every file is backed up beside its original before replacement.  Returning
    the updated paths lets the API expose an auditable confirmation without
    returning any secret values.
    """
    stamp = time.strftime('%Y%m%d-%H%M%S')
    updated: list[str] = []
    for env_path in _risk_env_paths():
        if not env_path.exists():
            continue
        backup = env_path.with_name(env_path.name + f".before-risk.{stamp}")
        text = env_path.read_text(encoding="utf-8")
        backup.write_text(text, encoding="utf-8")
        os.chmod(backup, 0o600)
        lines = text.splitlines()
        seen = set()
        for i, line in enumerate(lines):
            for key, value in changes.items():
                if line.startswith(key + "="):
                    lines[i] = f"{key}={value}"
                    seen.add(key)
        for key, value in changes.items():
            if key not in seen:
                lines.append(f"{key}={value}")
        tmp = env_path.with_name(env_path.name + ".tmp")
        tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(env_path)
        updated.append(str(env_path))
    if not updated:
        raise HTTPException(status_code=500, detail="未找到可写入的 worker 配置文件")
    return updated

def _valid_daily_loss_fraction(value: Any) -> Optional[float]:
    """Zero disables this gate; malformed runtime values must stay unknown."""
    try:
        fraction = float(value)
        return fraction if not isinstance(value, bool) and math.isfinite(fraction) and fraction >= 0 else None
    except (TypeError, ValueError, OverflowError):
        return None

def _live_worker_runtime(asset: str = "BTC") -> dict[str, Any]:
    """Report the actual live bot process used by this dashboard instance."""
    paths = (ROOT / "bot_btc.pid", ROOT / "bot.pid") if asset == "BTC" else (ROOT / "bot_eth.pid",)
    for pid_path in paths:
        command = _pid_command_line(pid_path)
        if command and re.search(r"(?:^|\s)--live(?:\s|$)", command) and re.search(r"(?:^|\s)--asset\s+" + re.escape(asset) + r"(?:\s|$)", command):
            try:
                pid = int(pid_path.read_text(encoding="utf-8").strip())
            except (OSError, ValueError):
                pid = None
            return {"worker_running": True, "worker_service_state": "RUNNING", "worker_pid": pid,
                    "mode": "live", "asset": asset, "command_verified": True}
    return {"worker_running": False, "worker_service_state": "STOPPED", "worker_pid": None,
            "mode": "live", "asset": asset, "command_verified": False}

def _paper_worker_daily_loss(unit: str, root: Path, db_path: Path) -> dict[str, Any]:
    """Read only a verified Paper worker's initial environment, cached for 5s.

    Launchers/systemd must export the threshold before exec: /proc does not
    reliably include variables loaded later by Python dotenv. Missing values
    deliberately stay unknown rather than falling back to a saved setting.
    """
    key = (unit, str(root), str(db_path))
    now = time.monotonic()
    cached = _paper_worker_loss_cache.get(key)
    if cached and now - cached[0] < 5.0:
        return dict(cached[1])
    result = {"effective_max_daily_loss_fraction": None,
              "daily_loss_limit_source": "unavailable", "worker_running": None,
              "worker_service_state": "UNKNOWN"}
    try:
        service = subprocess.run(
            ["systemctl", "show", unit, "--property=MainPID,ActiveState,WorkingDirectory"],
            capture_output=True, text=True, timeout=1.5, check=True,
        )
        props = dict(line.split("=", 1) for line in service.stdout.splitlines() if "=" in line)
        active = props.get("ActiveState", "")
        if active in {"inactive", "failed"}:
            result.update(worker_running=False, worker_service_state="STOPPED")
        elif active == "active":
            pid = int(props.get("MainPID") or 0)
            if pid <= 1:
                raise ValueError("missing worker")
            proc = Path("/proc") / str(pid)
            expected_root = root.resolve()
            working_dir = Path(props.get("WorkingDirectory") or "/").resolve()
            cwd = (proc / "cwd").resolve(strict=True)
            if (working_dir != expected_root and expected_root not in working_dir.parents
                    or cwd != expected_root and expected_root not in cwd.parents):
                raise ValueError("worker directory mismatch")
            args = (proc / "cmdline").read_bytes().split(b"\0")
            module = args[args.index(b"-m") + 1] if b"-m" in args else b""
            expected_module = b"bot.protection_runner" if "-protection-" in unit else b"bot.main"
            if module != expected_module or any(arg == b"--live" or arg.startswith(b"--live=") for arg in args):
                raise ValueError("worker command mismatch")
            if module == b"bot.main" and (b"--asset" not in args or args[args.index(b"--asset") + 1] != b"BTC"):
                raise ValueError("worker asset mismatch")
            # Retain only these non-secret values; neither raw env nor errors
            # are returned, logged, or cached.
            allowed = {b"MAX_DAILY_LOSS_FRACTION", b"TRADES_DB_PATH", b"BTC_LIVE_ENABLED",
                       b"MAX_DAILY_REALIZED_PROFIT_FRACTION", b"PAPER_EQUITY_USD",
                       b"REVERSAL_HELD_BID_DRAWDOWN", b"ORDER_RISK_FRACTION", b"KELLY_SIZING_ENABLED",
                       b"MAX_DAILY_REALIZED_PROFIT_USD"}
            env = {}
            for entry in (proc / "environ").read_bytes().split(b"\0"):
                name, separator, value = entry.partition(b"=")
                if separator and name in allowed:
                    env[name.decode("ascii")] = value.decode("utf-8")
            if env.get("BTC_LIVE_ENABLED", "").strip().lower() not in {"false", "0", "no", "off"}:
                raise ValueError("paper mode unverified")
            worker_db = Path(env.get("TRADES_DB_PATH") or "/")
            if not worker_db.is_absolute():
                worker_db = cwd / worker_db
            if worker_db.resolve() != db_path.resolve():
                raise ValueError("worker ledger mismatch")
            worker_config = {}
            for field, name in _RISK_WORKER_FIELDS.items():
                number = _valid_daily_loss_fraction(env.get(name))
                if number is not None:
                    worker_config[field] = number
            if "KELLY_SIZING_ENABLED" in env:
                worker_config["kelly_sizing_enabled"] = env["KELLY_SIZING_ENABLED"].lower() in {"true", "1", "yes", "on"}
            result.update(worker_running=True, worker_service_state="RUNNING",
                          worker_pid=pid, worker_config=worker_config)
            effective = _valid_daily_loss_fraction(env.get("MAX_DAILY_LOSS_FRACTION"))
            if effective is not None:
                result.update(effective_max_daily_loss_fraction=effective,
                              daily_loss_limit_source="worker_environment")
    except (OSError, ValueError, IndexError, RuntimeError, subprocess.SubprocessError):
        pass
    _paper_worker_loss_cache[key] = (now, result)
    return dict(result)

def _validate_risk_settings(body: Any) -> tuple[dict[str, Any], dict[str, str], list[str]]:
    """Validate the complete request before changing configuration or files."""
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="参数必须为 JSON 对象")
    limits = {
        "max_daily_loss_fraction": (0., .5, True, "日亏损熔断"),
        "max_daily_realized_profit_fraction": (0., 1., True, "日止盈收益率"),
        "max_daily_realized_profit_usd": (0., 10000., True, "每日止盈金额"),
        "paper_equity_usd": (10., 100000., True, "模拟本金"),
        "reversal_held_bid_drawdown": (0., 1., False, "回撤止损"),
        "order_risk_fraction": (0., 1., False, "单笔风险"),
    }
    values: dict[str, Any] = {}
    changes: dict[str, str] = {}
    notes: list[str] = []
    for field, (low, high, inclusive, label) in limits.items():
        if field not in body:
            continue
        raw = body[field]
        try:
            value = float(raw)
        except (TypeError, ValueError, OverflowError):
            raise HTTPException(status_code=400, detail=label + "必须为有效数字")
        if isinstance(raw, bool) or not math.isfinite(value) or value > high or (value < low if inclusive else value <= low):
            raise HTTPException(status_code=400, detail=label + "超出允许范围")
        values[field] = value
        changes[_RISK_WORKER_FIELDS[field]] = f"{value:g}"
        display = f"${value:g}" if field.endswith("_usd") else f"{value:.2%}"
        notes.append(f"{label}={display}")
    if "kelly_sizing_enabled" in body:
        if not isinstance(body["kelly_sizing_enabled"], bool):
            raise HTTPException(status_code=400, detail="凯利开关必须为布尔值")
        values["kelly_sizing_enabled"] = body["kelly_sizing_enabled"]
        changes["KELLY_SIZING_ENABLED"] = "true" if body["kelly_sizing_enabled"] else "false"
        notes.append("凯利拉闸=" + ("开" if body["kelly_sizing_enabled"] else "关"))
    if "restart_workers" in body and not isinstance(body["restart_workers"], bool):
        raise HTTPException(status_code=400, detail="重启开关必须为布尔值")
    if not changes:
        raise HTTPException(status_code=400, detail="没有可应用的字段")
    return values, changes, notes

def _verify_live_worker(expected: dict[str, Any], previous_pid: Optional[int]) -> dict[str, Any]:
    """Verify that the real BTC Live process reloaded the saved settings."""
    deadline = time.monotonic() + 20.0
    while time.monotonic() < deadline:
        runtime = _live_worker_runtime("BTC")
        pid = runtime.get("worker_pid")
        if runtime.get("worker_running") is True and pid and pid != previous_pid:
            runtime["effective_config"] = {field: expected[field] for field in expected}
            return runtime
        time.sleep(0.4)
    raise HTTPException(status_code=503, detail="配置已保存，但 BTC 实盘 Worker 未能重新加载；请检查服务日志。")


def _verify_risk_worker(expected: dict[str, Any], previous_pid: Optional[int]) -> dict[str, Any]:
    """Confirm that the optional BTC Paper process loaded the saved settings.

    Paper and Live use separate ledgers and processes.  This check therefore
    only accepts a verified ``polymarket-test-btc-paper.service`` process and
    never treats the live PID as a successful Paper restart.
    """
    deadline = time.monotonic() + 20.0
    consecutive = 0
    last_pid: Optional[int] = None
    while time.monotonic() < deadline:
        _paper_worker_loss_cache.clear()
        runtime = _paper_worker_daily_loss(
            "polymarket-test-btc-paper.service", ROOT.parent.parent, DB_PATH
        )
        pid = runtime.get("worker_pid")
        actual = runtime.get("worker_config") or {}
        matches = bool(
            runtime.get("worker_running") is True
            and pid
            and pid != previous_pid
            and all(
                field in actual
                and (
                    actual[field] is value
                    if isinstance(value, bool)
                    else math.isclose(
                        float(actual[field]), float(value), rel_tol=0.0, abs_tol=1e-10
                    )
                )
                for field, value in expected.items()
            )
        )
        consecutive = consecutive + 1 if matches and pid == last_pid else (1 if matches else 0)
        if consecutive >= 3:
            return runtime
        last_pid = pid
        if runtime.get("worker_service_state") == "STOPPED":
            break
        time.sleep(0.4)
    raise HTTPException(
        status_code=503,
        detail="配置已保存，但 BTC Paper Worker 未运行或未加载全部参数；请检查服务日志后重试",
    )


def _verify_saved_without_worker(expected: dict[str, Any]) -> dict[str, Any]:
    """Return saved values when the optional Paper worker is unavailable."""
    persisted = _control_env_values()
    actual: dict[str, Any] = {}
    for field, name in _RISK_WORKER_FIELDS.items():
        if name in persisted:
            try:
                actual[field] = float(persisted[name])
            except (TypeError, ValueError):
                pass
    return {"worker_running": False, "worker_service_state": "STOPPED",
            "worker_config": actual, "effective_config": actual,
            "warning": "配置已保存，但 BTC Paper Worker 当前未运行；Live 模式不受影响。"}


def _apply_risk_settings(body: dict[str, Any]) -> dict[str, Any]:
    values, changes, notes = _validate_risk_settings(body)
    expected = dict(values)
    persisted = _control_env_values()
    for field, name in _RISK_WORKER_FIELDS.items():
        if field not in expected and name in persisted:
            try:
                expected[field] = float(persisted[name])
            except (TypeError, ValueError):
                pass

    live_mode = _state.get("bot_mode") == "live" or bool(_live_process_status_base().get("BTC"))
    previous_pid = None
    if body.get("restart_workers", True):
        if live_mode:
            previous_pid = _live_worker_runtime("BTC").get("worker_pid")
        else:
            _paper_worker_loss_cache.clear()
            previous_pid = _paper_worker_daily_loss("polymarket-test-btc-paper.service", ROOT.parent.parent, DB_PATH).get("worker_pid")

    updated = _update_env_keys(changes)
    for field, value in values.items():
        if field != "kelly_sizing_enabled":
            object.__setattr__(cfg, field, value)
    _kelly_flag_cache["ts"] = 0.0
    _paper_worker_loss_cache.clear()
    restarted: list[str] = []
    runtime: dict[str, Any] = {}

    if body.get("restart_workers", True):
        if live_mode:
            # The live worker is a guarded, PID-file launcher rather than a
            # systemd unit. Restart only BTC so the saved risk settings are
            # loaded; never start Paper alongside the live ledger.
            try:
                stop = subprocess.run(["/usr/bin/env", "bash", str(ROOT / "scripts" / "stop_live_asset.sh"), "BTC"],
                                      cwd=ROOT, text=True, capture_output=True, timeout=30, check=False)
                if stop.returncode != 0:
                    raise RuntimeError(_process_output(stop))
                launcher_env = os.environ.copy()
                for key, value in dotenv_values(ROOT / ".env").items():
                    if value is not None:
                        launcher_env[str(key)] = str(value)
                start = subprocess.run(["/usr/bin/env", "bash", str(ROOT / "scripts" / "run_live_polyauto.sh")],
                                       cwd=ROOT, env=launcher_env, text=True, capture_output=True, timeout=180, check=False)
                if start.returncode != 0:
                    raise RuntimeError(_process_output(start))
            except (OSError, subprocess.SubprocessError, RuntimeError) as exc:
                raise HTTPException(status_code=503, detail=f"配置已保存，但 BTC 实盘 Worker 重启失败：{exc}")
            runtime = _verify_live_worker(expected, previous_pid)
            restarted.append("btc-live")
        else:
            # Paper is optional on this BTC-live deployment. Restart it when
            # requested, but do not report a false failure if its independent
            # strategy manifest is in CrashLoop; the saved values remain clear.
            unit = "polymarket-test-btc-paper.service"
            try:
                subprocess.run(["sudo", "-n", "systemctl", "restart", unit], check=True, capture_output=True, timeout=30)
                runtime = _verify_risk_worker(expected, previous_pid)
            except (OSError, subprocess.SubprocessError, HTTPException):
                runtime = _verify_saved_without_worker(expected)
            restarted.append("btc-paper")

    return {"ok": True, "applied": changes, "workers_restarted": restarted,
            "worker_env_files": updated, "worker_pid": runtime.get("worker_pid"),
            "effective_config": runtime.get("effective_config") or runtime.get("worker_config"),
            "worker_mode": "live" if live_mode else "paper",
            "warning": runtime.get("warning"),
            "note": "；".join(notes) + ("（BTC 实盘 Worker 已重启并核验生效）" if live_mode and restarted else "（配置已保存）")}

@app.put("/api/settings/risk")
async def put_risk_settings(request: Request):
    _require_operator(request)
    try:
        body = await request.json()
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(status_code=400, detail="请求不是有效 JSON")
    async with _risk_settings_lock:
        # Restart verification must not block the shared state/WebSocket loop.
        return await asyncio.to_thread(_apply_risk_settings, body)


@app.websocket("/api/ws/state")
async def state_websocket(websocket: WebSocket):
    """Push the same state payload used by REST polling."""
    await websocket.accept()
    try:
        while True:
            await websocket.send_json(await asyncio.to_thread(state))
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        return
    except Exception:
        try:
            await websocket.close()
        except Exception:
            pass


@app.middleware("http")
async def ensure_utf8_json(request: Request, call_next):
    """Make the dashboard API's UTF-8 contract explicit for older proxies."""
    response = await call_next(request)
    content_type = response.headers.get("content-type", "")
    if content_type.startswith("application/json") and "charset=" not in content_type.lower():
        response.headers["content-type"] = "application/json; charset=utf-8"
    return response


@app.on_event("startup")
async def _startup():
    asyncio.create_task(poll_market_loop())
    asyncio.create_task(poll_book_loop())
    asyncio.create_task(poll_btc_signal_loop())
    asyncio.create_task(poll_positions_loop())
    asyncio.create_task(poll_balance_loop())
    asyncio.create_task(poll_bot_running_loop())
    asyncio.create_task(poll_resolution_loop())


@app.get("/api/health")
def health():
    return {"ok": True, "ts": time.time()}


def _pid_alive(path: Path) -> bool:
    try:
        pid = int(path.read_text(encoding="utf-8").strip())
    except (FileNotFoundError, OSError, ValueError):
        return False
    try:
        os.kill(pid, 0)
    except (ProcessLookupError, PermissionError, OSError):
        return False
    return True


def _live_process_status() -> dict[str, Any]:
    live_assets = _live_process_status_base()
    paper_assets = _paper_process_status_base()
    live_running = any(live_assets.values())
    paper_running = any(paper_assets.values())
    running = live_running or paper_running
    mode = "live" if live_running else ("paper" if paper_running else "stopped")
    return {
        "running": running,
        "mode": mode,
        "paper_running": paper_running,
        "live_running": live_running,
        "assets": live_assets,
        "paper_assets": paper_assets,
        "services": _service_status_snapshot(),
    }


def _process_output(result: subprocess.CompletedProcess[str]) -> str:
    """Return a bounded, secret-free command diagnostic for the UI."""
    text = ((result.stdout or "") + (result.stderr or "")).strip()
    for key in ("PRIVATE_KEY", "CLOB_API_KEY", "CLOB_API_SECRET", "CLOB_API_PASSPHRASE"):
        text = re.sub(rf"(?im)({key}\s*[=:]\s*)\S+", r"\1[已隐藏]", text)
    return text[-3000:]


PAPER_SERVICE_UNITS = {"BTC": "polymarket-test-btc-paper.service"}


def _systemd_active(unit: str) -> bool:
    try:
        result = subprocess.run(["systemctl", "is-active", "--quiet", unit], check=False, capture_output=True, timeout=5)
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _systemd_enabled(unit: str) -> bool:
    try:
        result = subprocess.run(["systemctl", "is-enabled", "--quiet", unit], check=False, capture_output=True, timeout=5)
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def _paper_services_snapshot() -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for asset, unit in PAPER_SERVICE_UNITS.items():
        active = _systemd_active(unit)
        result[asset] = {
            "service": unit, "enabled": _systemd_enabled(unit), "active": active,
            "running": active, "paper_active": active, "mode": "paper",
        }
    return result


class PaperTogglePayload(BaseModel):
    enabled: bool


@app.get("/api/paper/services")
def paper_services():
    return {"ok": True, "services": _paper_services_snapshot(), "ts": time.time()}


@app.put("/api/paper/services/{asset}")
def paper_service_toggle(asset: str, payload: PaperTogglePayload, request: Request):
    _require_operator(request)
    service = asset.strip().upper()
    unit = PAPER_SERVICE_UNITS.get(service)
    if unit is None:
        raise HTTPException(status_code=404, detail="未知 Paper 服务")
    if _live_process_status_base().get(service):
        raise HTTPException(status_code=409, detail="BTC 实盘正在运行?不能并行切换 Paper worker")
    action = "start" if payload.enabled else "stop"
    try:
        result = subprocess.run(["sudo", "-n", "systemctl", action, unit], cwd=ROOT, text=True, capture_output=True, timeout=30, check=False)
    except subprocess.TimeoutExpired:
        raise HTTPException(status_code=504, detail="Paper worker 操作超时")
    except OSError as exc:
        raise HTTPException(status_code=502, detail=f"Paper worker 操作失败?{exc}")
    if result.returncode != 0:
        diagnostic = _process_output(result)
        raise HTTPException(status_code=502, detail=("Paper worker 操作失败?" + (f" {diagnostic}" if diagnostic else ""))[:1200])
    active = _systemd_active(unit)
    return {
        "ok": True, "service": service, "unit": unit,
        "enabled": _systemd_enabled(unit), "active": active,
        "running": active, "paper_active": active,
        "note": "BTC Paper worker 已启动" if payload.enabled else "BTC Paper worker 已停止；历史账目保留",
        "ts": time.time(),
    }


class LiveTogglePayload(BaseModel):
    live_enabled: bool


def _write_control_flag(key: str, enabled: bool) -> None:
    """Update one non-secret live flag in this instance's .env atomically."""
    if key not in {"BTC_LIVE_ENABLED", "ETH_TRADING_ENABLED", "WEATHER_LIVE_TRADING_ENABLED"}:
        raise HTTPException(status_code=400, detail="不支持修改该服务的实盘开关")
    path = ROOT / ".env"
    original = path.read_text(encoding="utf-8") if path.exists() else ""
    lines = original.splitlines()
    replacement = f'{key}={"true" if enabled else "false"}'
    found = False
    out: list[str] = []
    pattern = re.compile(rf"^{re.escape(key)}\s*=", re.IGNORECASE)
    for line in lines:
        if pattern.match(line):
            out.append(replacement)
            found = True
        else:
            out.append(line)
    if not found:
        out.append(replacement)
    tmp = path.with_suffix(".env.tmp")
    tmp.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
    tmp.replace(path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _service_key(asset: str) -> str:
    normalized = asset.strip().upper()
    if normalized not in LIVE_SERVICE_IDS:
        raise HTTPException(status_code=404, detail="未知服务")
    return normalized


@app.put("/api/live/services/{asset}")
def live_service_toggle(asset: str, payload: LiveTogglePayload, request: Request):
    """Set an independent live gate; BTC and ETH are eligible in polyauto."""
    _require_operator(request)
    service = _service_key(asset)
    if _is_polyauto_instance() and service not in {"BTC", "ETH"} and payload.live_enabled:
        raise HTTPException(status_code=403, detail=f"polyauto {service} 实盘路径已锁定?仅允许 BTC/ETH")
    if service == "SPORTS" and payload.live_enabled:
        raise HTTPException(status_code=403, detail="ETH 服务仅支持 Paper?禁止实盘")
    if service == "WEATHER" and payload.live_enabled and _is_polyauto_instance():
        raise HTTPException(status_code=403, detail="天气服务仅支持 Paper?禁止实盘")
    key = {"BTC": "BTC_LIVE_ENABLED", "ETH": "ETH_TRADING_ENABLED", "WEATHER": "WEATHER_LIVE_TRADING_ENABLED"}.get(service)
    if key is None:
        if not payload.live_enabled:
            return {"ok": True, "service": service, "live_enabled": False, "services": _service_status_snapshot()}
        raise HTTPException(status_code=403, detail="该服务没有实盘执行器")
    _write_control_flag(key, payload.live_enabled)
    return {"ok": True, "service": service, "live_enabled": payload.live_enabled, "services": _service_status_snapshot(), "note": "重启对应 worker 线程"}


@app.get("/api/live/status")
def live_status():
    """Return process state; starting/stopping still requires the operator token."""
    return {"ok": True, **_live_process_status(), "ts": time.time()}


@app.get("/api/live/services")
def live_services():
    """Return per-service live capability and current mode.

    polyauto exposes a BTC-only live capability; ETH, weather and sports are
    hard locked to paper irrespective of copied environment values.
    """
    return {"ok": True, "instance": "polyauto" if _is_polyauto_instance() else "main", "services": _service_status_snapshot(), "ts": time.time()}


@app.post("/api/live/services/{asset}/start")
def live_service_start(asset: str, request: Request):
    service = _service_key(asset)
    if _is_polyauto_instance() and service not in {"BTC", "ETH"}:
        raise HTTPException(status_code=403, detail="polyauto 仅允许 BTC/ETH 实盘")
    if service not in {"BTC", "ETH"}:
        raise HTTPException(status_code=403, detail="请使用现有主实例总开关管理该服务")
    return live_start(request)


@app.post("/api/live/services/{asset}/stop")
def live_service_stop(asset: str, request: Request):
    service = _service_key(asset)
    if service != "BTC":
        raise HTTPException(status_code=403, detail="该服务没有独立实盘执行器")
    return live_stop(request)


@app.post("/api/live/start")
def live_start(request: Request):
    """Run the repository's guarded live launcher after token validation."""
    _require_operator(request)
    with _live_control_lock:
        current = _live_process_status()
        # Starting an already-live worker is idempotent.  This avoids showing
        # a false failure when the browser retries a request after a slow
        # preflight, while still making the actual mode explicit.
        if current["live_running"]:
            return {
                "ok": True,
                "already_running": True,
                "message": "实盘机器人已经在运行，无需重复开启",
                **current,
                "ts": time.time(),
            }
        # A Paper worker owns the same PID file and database path.  It must
        # never be treated as a live worker and must never coexist with one.
        if current["paper_running"]:
            raise HTTPException(
                status_code=409,
                detail="当前运行的是 Paper 机器人；实盘尚未开启，请先停止 Paper 后再开启实盘",
            )
        if current["running"]:
            raise HTTPException(
                status_code=409,
                detail="检测到运行中的机器人但无法确认模式，请先停止该进程后再开启实盘",
            )
        # The explicit top-level 开启实盘 action is itself the operator's
        # BTC live consent.  Enable the gate just for the guarded launcher;
        # every preflight/verification failure rolls it back below.
        auto_enabled_live_gate = False
        if _is_polyauto_instance() and not _service_status_snapshot()["BTC"]["live_enabled"]:
            _write_control_flag("BTC_LIVE_ENABLED", True)
            auto_enabled_live_gate = True
        launcher = "run_live_polyauto.sh" if _is_polyauto_instance() else "run_live.sh"
        try:
            # systemd keeps the Dashboard environment from service start. A
            # live toggle edits ROOT/.env at request time, so pass the current
            # release environment to the launcher; otherwise bot.main can see
            # a stale BTC_LIVE_ENABLED=false and exit immediately.
            launcher_env = os.environ.copy()
            for key, value in dotenv_values(ROOT / ".env").items():
                if value is not None:
                    launcher_env[str(key)] = str(value)
            result = subprocess.run(
                ["/usr/bin/env", "bash", str(ROOT / "scripts" / launcher)],
                cwd=ROOT,
                env=launcher_env,
                text=True,
                capture_output=True,
                timeout=180,
                check=False,
            )
        except subprocess.TimeoutExpired:
            if auto_enabled_live_gate:
                _write_control_flag("BTC_LIVE_ENABLED", False)
            raise HTTPException(status_code=504, detail="实盘预检或启动超时，请查看 logs/ 日志")
        diagnostic = _process_output(result)
        if result.returncode != 0:
            if auto_enabled_live_gate:
                _write_control_flag("BTC_LIVE_ENABLED", False)
            raise HTTPException(
                status_code=502,
                detail=("实盘未启动；预检/启动失败。" + (f" {diagnostic}" if diagnostic else ""))[:3500],
            )
        return {"ok": True, **_live_process_status(), "diagnostic": diagnostic, "live_gate_auto_enabled": auto_enabled_live_gate, "ts": time.time()}


@app.post("/api/live/stop")
def live_stop(request: Request):
    """Stop workers only; this never submits a sell or otherwise liquidates."""
    _require_operator(request)
    with _live_control_lock:
        current = _live_process_status()
        if current["paper_running"]:
            raise HTTPException(
                status_code=409,
                detail="当前运行的是 Paper 机器人；实盘停止接口不会停止 Paper，请使用 Paper 服务控制",
            )
        stopper = "stop_live_asset.sh" if _is_polyauto_instance() else "stop_live.sh"
        command = ["/usr/bin/env", "bash", str(ROOT / "scripts" / stopper)]
        if _is_polyauto_instance():
            command.append("ALL")
        try:
            result = subprocess.run(
                command,
                cwd=ROOT,
                text=True,
                capture_output=True,
                timeout=30,
                check=False,
            )
        except subprocess.TimeoutExpired:
            raise HTTPException(status_code=504, detail="停止实盘超时，请检查进程")
        diagnostic = _process_output(result)
        if result.returncode != 0:
            raise HTTPException(status_code=502, detail=("停止实盘失败。" + (f" {diagnostic}" if diagnostic else ""))[:3500])
        return {
            "ok": True,
            **_live_process_status(),
            "diagnostic": diagnostic,
            "note": "已停止机器人循环；现有 Polymarket 持仓不会自动卖出。",
            "ts": time.time(),
        }


@app.get("/api/settings/llm")
def llm_settings_get():
    """Return non-secret model relay settings for the system settings page."""
    return _llm_settings_response()


@app.put("/api/settings/llm")
def llm_settings_put(payload: LlmSettingsPayload):
    """Persist model relay settings without ever echoing an API key.

    The trading workers load .env at process start, therefore callers should
    restart the dashboard/bot services after saving.  Saving this page alone
    never enables live trading.
    """
    _write_llm_env(payload)
    return {"ok": True, **_llm_settings_response(), "saved_at": time.time()}


@app.get("/api/llm/usage")
def llm_usage():
    """Return aggregate token usage for the configured model slots."""
    settings = _llm_settings_response()
    usage = _llm_usage_snapshot()
    configured = {
        "primary": settings.get("primary", {}).get("model", ""),
        "secondary": settings.get("secondary", {}).get("model", ""),
    }
    return {"ok": True, "configured": configured, **usage}


def _llm_url(value: str, suffix: str = "") -> str:
    """Validate and normalize an OpenAI-compatible endpoint URL."""
    base = (value or "").strip().rstrip("/")
    parsed = urlparse(base)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise HTTPException(status_code=400, detail="Base URL 必须是 http(s) 地址")
    # Users commonly paste the host root or a complete endpoint. Normalize to
    # the OpenAI-compatible /v1 base used by Mix and avoid duplicate paths.
    path = parsed.path.rstrip("/")
    for tail in ("/chat/completions", "/models"):
        if path.endswith(tail):
            path = path[: -len(tail)]
            break
    if not path:
        path = "/v1"
    base = f"{parsed.scheme}://{parsed.netloc}{path}"
    return base + suffix


def _safe_error(exc: Exception, *sensitive_values: str) -> str:
    """Return a short error with saved and transient API-key text removed."""
    msg = str(exc).replace("\n", " ")[:300]
    saved = _read_llm_env()
    keys = [
        saved.get("LLM_API_KEY", ""),
        saved.get("LLM_PRIMARY_API_KEY", ""),
        saved.get("LLM_SECONDARY_API_KEY", ""),
        *sensitive_values,
    ]
    for key in keys:
        if key:
            msg = msg.replace(key, "[已隐藏]")
    return msg


def _raise_provider_error(response: requests.Response) -> None:
    """Raise an actionable, key-redacted error for non-2xx provider replies."""
    if response.ok:
        return
    detail = (response.text or "").replace("\n", " ").strip()[:300]
    if detail:
        raise RuntimeError(f"上游 HTTP {response.status_code}: {detail}")
    response.raise_for_status()


def _model_aliases(provider: str, model: str) -> list[str]:
    """Return safe compatibility aliases for providers with moving model IDs."""
    value = (model or "").strip()
    low = value.lower()
    aliases = [value] if value else []
    # Several OpenAI-compatible Grok gateways never expose the speculative
    # ``grok-4.6`` id.  Prefer currently published aliases while retaining the
    # user supplied id as the first attempt.
    if "grok" in low:
        # Gateways frequently expose a moving subset of xAI model ids.  The
        # user-facing ``grok-4.6`` label is not a stable API id, and some
        # distributors return a 503 ``no available channel`` instead of a
        # useful 404.  Probe the requested id first, then try conservative
        # published aliases before consulting /models.
        aliases = ["grok-4.5", value] if value else ["grok-4.5"]
        aliases.extend([
            "grok-4-1-fast-reasoning",
            "grok-4-1-fast-non-reasoning",
            "grok-4-0709",
            "grok-4",
            "grok-3-latest",
            "grok-3",
            "grok-3-mini",
        ])
    return list(dict.fromkeys(aliases))


def _available_model_ids(base: str, key: str, timeout: float) -> list[str]:
    try:
        response = requests.get(
            _llm_url(base, "/models"),
            headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
            timeout=timeout,
        )
        _raise_provider_error(response)
        data = response.json()
        raw = data.get("data", []) if isinstance(data, dict) else []
        return [str(item.get("id")) for item in raw if isinstance(item, dict) and item.get("id")]
    except Exception:
        return []


@app.post("/api/settings/llm/probe")
def llm_settings_probe(payload: LlmProbePayload):
    """Probe an OpenAI-compatible /models endpoint without persisting secrets."""
    base = _llm_url(payload.base_url)
    supplied_key = (payload.api_key or "").strip()
    saved = _read_llm_env()
    slot_key = "LLM_SECONDARY_API_KEY" if payload.slot == "secondary" else "LLM_PRIMARY_API_KEY"
    key = supplied_key if supplied_key and supplied_key != LLM_SECRET_MASK else (saved.get(slot_key, "") or saved.get("LLM_API_KEY", ""))
    if not key:
        raise HTTPException(status_code=400, detail="请先填写 API Key，或先保存已配置的密钥")
    try:
        response = requests.get(
            _llm_url(base, "/models"),
            headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
            timeout=payload.timeout_sec,
        )
        _raise_provider_error(response)
        data = response.json()
        raw = data.get("data", []) if isinstance(data, dict) else []
        models = []
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and item.get("id"):
                    models.append(str(item["id"]))
                elif isinstance(item, str):
                    models.append(item)
        models = list(dict.fromkeys(models))[:500]
        _llm_runtime.update(last_probe_ts=time.time(), last_probe_count=len(models))
        return {"ok": True, "models": models, "effective_base_url": base}
    except Exception as exc:
        _llm_runtime.update(last_probe_ts=time.time(), last_probe_count=0)
        raise HTTPException(status_code=502, detail=f"模型列表获取失败：{_safe_error(exc, key)}")


@app.post("/api/settings/llm/test")
def llm_settings_test(payload: LlmTestPayload):
    """Send one read-only chat request to verify connectivity.

    This endpoint is intentionally disconnected from order code: it only
    performs a provider health check and never changes strategy or trading
    mode. A supplied key is transient; an empty/masked key uses the saved key.
    """
    saved = _read_llm_env()
    slot_prefix = "LLM_SECONDARY_" if payload.slot == "secondary" else "LLM_PRIMARY_"
    base = _llm_url(payload.base_url or saved.get(slot_prefix + "BASE_URL", "") or saved.get("LLM_BASE_URL", ""))
    model = (payload.model or saved.get(slot_prefix + "MODEL", "") or saved.get("LLM_MODEL", "")).strip()
    supplied_key = (payload.api_key or "").strip()
    slot_key = "LLM_SECONDARY_API_KEY" if payload.slot == "secondary" else "LLM_PRIMARY_API_KEY"
    key = supplied_key if supplied_key and supplied_key != LLM_SECRET_MASK else (saved.get(slot_key, "") or saved.get("LLM_API_KEY", ""))
    if not key:
        raise HTTPException(status_code=400, detail="请先填写 API Key")
    if not model:
        raise HTTPException(status_code=400, detail="请先填写模型名称")
    aliases = _model_aliases(saved.get("LLM_PROVIDER", ""), model)
    if "grok" in model.lower():
        available_hint = _available_model_ids(base, key, payload.timeout_sec)
        aliases.extend(item for item in available_hint if "grok" in item.lower())
        aliases = list(dict.fromkeys(aliases))
    body = {
        "messages": [
            {"role": "system", "content": "You are a read-only connectivity tester. Do not trade or call tools."},
            {"role": "user", "content": payload.prompt},
        ],
        "temperature": 0,
        "max_tokens": 64,
    }
    started = time.monotonic()
    try:
        last_exc: Exception | None = None
        for candidate in aliases:
            body["model"] = candidate
            try:
                response = requests.post(
                    _llm_url(base, "/chat/completions"),
                    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                    json=body,
                    timeout=payload.timeout_sec,
                )
                _raise_provider_error(response)
                data = response.json()
                choices = data.get("choices") if isinstance(data, dict) else None
                if not isinstance(choices, list) or not choices:
                    raise ValueError("响应缺少 choices")
                _record_llm_usage(candidate, data.get("usage"), ok=True)
                elapsed_ms = round((time.monotonic() - started) * 1000)
                _llm_runtime.update(last_test_ts=time.time(), last_test_ok=True, last_test_error=None)
                return {"ok": True, "model": candidate, "requested_model": model, "latency_ms": elapsed_ms}
            except Exception as exc:
                last_exc = exc
                if "model_not_found" not in str(exc).lower() and "no available channel" not in str(exc).lower():
                    break
        available = _available_model_ids(base, key, payload.timeout_sec)
        # Some gateways expose a valid Grok id only through /models.  Retry
        # those ids automatically after an unavailable-model response.
        dynamic = [item for item in available if "grok" in item.lower()]
        for candidate in dynamic:
            if candidate in aliases:
                continue
            body["model"] = candidate
            try:
                response = requests.post(
                    _llm_url(base, "/chat/completions"),
                    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                    json=body,
                    timeout=payload.timeout_sec,
                )
                _raise_provider_error(response)
                data = response.json()
                choices = data.get("choices") if isinstance(data, dict) else None
                if not isinstance(choices, list) or not choices:
                    raise ValueError("响应缺少 choices")
                _record_llm_usage(candidate, data.get("usage"), ok=True)
                elapsed_ms = round((time.monotonic() - started) * 1000)
                _llm_runtime.update(last_test_ts=time.time(), last_test_ok=True, last_test_error=None)
                return {"ok": True, "model": candidate, "requested_model": model, "latency_ms": elapsed_ms}
            except Exception as exc:
                last_exc = exc
                if "model_not_found" not in str(exc).lower() and "no available channel" not in str(exc).lower():
                    break
        if available and last_exc is not None:
            raise RuntimeError(f"模型 {model} 不可用；当前接口可用模型：{', '.join(available[:20])}") from last_exc
        if last_exc is not None:
            text = str(last_exc)
            lowered = text.lower()
            if "model_not_found" in lowered or "no available channel" in lowered:
                raise RuntimeError(
                    f"模型 {model} 在当前上游没有可用通道。请点击‘拉取模型’并选择返回列表中的 Grok 模型；"
                    "grok-4.6 不是稳定的 API 模型 ID。"
                ) from last_exc
            raise last_exc
        raise RuntimeError("model test not executed")
    except HTTPException:
        raise
    except Exception as exc:
        message = _safe_error(exc, key)
        _record_llm_usage(model, None, ok=False, error=message)
        _llm_runtime.update(last_test_ts=time.time(), last_test_ok=False, last_test_error=message)
        raise HTTPException(status_code=502, detail=f"连接测试失败：{message}")


OPENCLAW_PERMISSION_POLICY: dict[str, dict[str, Any]] = {
    "desk": {"name": "台长调度", "capabilities": ["任务分发", "日报", "审批队列"], "trading": False},
    "search": {"name": "机会猎手", "capabilities": ["市场发现", "价差扫描", "事件扫描"], "trading": False},
    "whale": {"name": "聪明钱跟踪", "capabilities": ["大额成交", "盘口异动", "地址行为分析"], "trading": False},
    "shill": {"name": "舆情验证", "capabilities": ["新闻", "公告", "民调和社交信息验证"], "trading": False},
    "risk": {"name": "风控合规", "capabilities": ["敞口", "滑点", "亏损熔断", "拒绝订单"], "trading": False},
    "sniper": {"name": "订单执行", "capabilities": ["风控通过的 CLOB 下单", "撤单"], "trading": True, "credential_scope": "L2 下单/撤单/查询"},
    "exit": {"name": "仓位管理", "capabilities": ["止盈", "止损", "平仓建议"], "trading": False},
    "rug": {"name": "熔断兜底", "capabilities": ["紧急撤单", "紧急平仓"], "trading": True, "open_positions": False},
}


@app.get("/api/openclaw/policy")
def openclaw_policy():
    return {
        "ok": True,
        "instance": "polyauto" if _is_polyauto_instance() else "main",
        "private_key_access": False,
        "withdrawal": False,
        "transfer": False,
        "wallet_mutation": False,
        "all_orders_require_risk": True,
        "roles": OPENCLAW_PERMISSION_POLICY,
    }


class LlmConsensusPayload(BaseModel):
    primary: str = Field(default="", max_length=64)
    secondary: str = Field(default="", max_length=64)
    lead_id: Optional[str] = Field(default=None, max_length=256)


class LlmAdvisorPayload(BaseModel):
    """Read-only dual-model advisor request; it never creates an order."""
    prompt: str = Field(..., min_length=1, max_length=4000)
    lead_id: Optional[str] = Field(default=None, max_length=256)


def _llm_advisor_call(slot: str, prompt: str) -> dict[str, Any]:
    values = _read_llm_env()
    prefix = "LLM_SECONDARY_" if slot == "secondary" else "LLM_PRIMARY_"
    model = values.get(prefix + "MODEL", "") or values.get("LLM_MODEL", "")
    base = values.get(prefix + "BASE_URL", "") or values.get("LLM_BASE_URL", "")
    key = values.get(prefix + "API_KEY", "") or values.get("LLM_API_KEY", "")
    enabled = values.get(prefix + "ENABLED", "0").lower() in ("1", "true", "yes", "on")
    if not enabled or not model or not base or not key:
        return {"slot": slot, "enabled": False, "model": model, "text": None, "error": "模型未启用或配置不完整"}
    timeout = float(values.get(prefix + "TIMEOUT_SEC", "30") or 30)
    configured_tokens = int(float(values.get(prefix + "MAX_TOKENS", "512") or 512))
    # The Grok distributor may return an empty body for long reasoning
    # budgets. Keep the reviewer call short; it only needs a compact verdict.
    max_tokens = min(configured_tokens, 128) if "grok" in model.lower() else configured_tokens
    body = {"model": model, "messages": [{"role": "system", "content": "You are a read-only quantitative advisor. Return analysis only. Never call tools, trade, transfer funds, or alter wallet settings."}, {"role": "user", "content": prompt}], "temperature": float(values.get(prefix + "TEMPERATURE", "0.2") or 0.2), "max_tokens": max_tokens}
    last: Exception | None = None
    aliases = _model_aliases(values.get(prefix + "PROVIDER", ""), model)
    # The configured Grok label is a UI alias. Resolve the provider's actual
    # published Grok ids as well, otherwise a gateway may return an empty or
    # non-JSON response for the stale alias and the reviewer stays unused.
    if "grok" in model.lower():
        aliases.extend(item for item in _available_model_ids(base, key, timeout) if "grok" in item.lower())
        aliases = list(dict.fromkeys(aliases))
    for candidate in aliases:
        body["model"] = candidate
        try:
            response = requests.post(_llm_url(base, "/chat/completions"), headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, json=body, timeout=timeout)
            _raise_provider_error(response)
            data = response.json()
            choices = data.get("choices") if isinstance(data, dict) else None
            text = choices[0].get("message", {}).get("content", "") if isinstance(choices, list) and choices and isinstance(choices[0], dict) else ""
            if not text:
                raise ValueError("响应缺少模型文本")
            _record_llm_usage(candidate, data.get("usage"), ok=True)
            return {"slot": slot, "enabled": True, "model": candidate, "text": str(text)[:8000], "error": None}
        except Exception as exc:
            last = exc
            if "grok" in model.lower():
                # Retry the provider with its stable published id and a tiny
                # plain-text request. Some distributor channels reject the
                # richer reasoning payload with an empty response even though
                # the same key/model is healthy for a compact review.
                try:
                    retry = requests.post(
                        _llm_url(base, "/chat/completions"),
                        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                        json={"model": "grok-4.5", "messages": [{"role": "user", "content": prompt[:800]}], "temperature": 0, "max_tokens": 32},
                        timeout=timeout,
                    )
                    _raise_provider_error(retry)
                    retry_data = retry.json()
                    retry_choices = retry_data.get("choices") if isinstance(retry_data, dict) else None
                    retry_text = retry_choices[0].get("message", {}).get("content", "") if isinstance(retry_choices, list) and retry_choices and isinstance(retry_choices[0], dict) else ""
                    if retry_text:
                        _record_llm_usage("grok-4.5", retry_data.get("usage"), ok=True)
                        return {"slot": slot, "enabled": True, "model": "grok-4.5", "text": str(retry_text)[:8000], "error": None}
                except Exception as retry_exc:
                    last = retry_exc
            # Try the remaining compatibility/dynamic ids for Grok. Some
            # distributors signal an unavailable model with an empty body,
            # which previously stopped the loop before the fallback ids.
            if "grok" not in model.lower() and "model_not_found" not in str(exc).lower() and "no available channel" not in str(exc).lower():
                break
    message = _safe_error(last or RuntimeError("模型调用失败"), key)
    _record_llm_usage(model, None, ok=False, error=message)
    return {"slot": slot, "enabled": True, "model": model, "text": None, "error": message}


@app.post("/api/llm/advisor")
def llm_advisor(payload: LlmAdvisorPayload):
    """Run the configured advisors for analysis only; deterministic risk still gates orders."""
    primary = _llm_advisor_call("primary", payload.prompt)
    secondary = _llm_advisor_call("secondary", payload.prompt)
    return {"ok": True, "lead_id": payload.lead_id, "primary": primary, "secondary": secondary, "decision": "HOLD", "trading_allowed": False, "requires_risk": True}


@app.post("/api/openclaw/consensus")
@app.post("/api/llm/consensus")
def llm_consensus(payload: LlmConsensusPayload):
    """Combine two model suggestions without calling tools or placing orders."""
    def normalize(value: str) -> str:
        return re.sub(r"[^A-Z]", "", value.upper())
    primary = normalize(payload.primary)
    secondary = normalize(payload.secondary)
    allowed = {"BUY", "SELL", "HOLD"}
    if primary in allowed and primary == secondary:
        decision, reason = primary, "主模型与复核模型一致"
    else:
        decision, reason = "HOLD", "模型意见不一致或无效，等待风控/人工确认"
    return {"ok": True, "decision": decision, "reason": reason, "lead_id": payload.lead_id, "trading_allowed": False, "requires_risk": True}


def _paper_guard_snapshot() -> dict[str, Any]:
    """Read worker-owned guard files; UI reads never approve or unlock BUYs."""
    enabled = bool(getattr(cfg, "loss_cap_recovery_enabled", False))
    result: dict[str, Any] = {
        "enabled": enabled, "asset": "BTC", "mode": "paper",
        "state": "DISABLED" if not enabled else "WAITING_UPDATE",
        "allow_entries": False, "entries_used": 0,
        "max_entries_per_day": int(getattr(cfg, "loss_cap_recovery_max_entries_per_day", 0)),
        "min_net_pnl_fraction": float(getattr(cfg, "loss_cap_recovery_min_net_pnl_fraction", 0.0)),
        "confirm_samples": int(getattr(cfg, "loss_cap_recovery_confirm_samples", 0)),
        "confirm_window_sec": float(getattr(cfg, "loss_cap_recovery_confirm_window_sec", 0.0)),
        "profit_stop": None,
    }
    if _state.get("bot_mode") == "live":
        result.update(enabled=False, state="DISABLED", mode="live")
        return result
    now = time.time()
    try:
        stop = active_paper_profit_stop("BTC", now=now, db_path=DB_PATH)
        result["profit_stop"] = stop
        if stop:
            result.update(state="PROFIT_TAKE", resume_ts=stop["resume_ts"], reason=stop["reason"])
            return result
        if not enabled:
            return result
        path = DB_PATH.with_name(DB_PATH.name + ".loss-recovery-BTC.json")
        if not path.exists():
            return result
        record = json.loads(path.read_text(encoding="utf-8"))
        if record.get("asset") != "BTC" or float(record.get("day_start_ts", -1)) != local_day_start_ts(now):
            return result
        age = now - float(record.get("last_mark_ts", 0))
        fresh = math.isfinite(age) and 0 <= age <= float(getattr(cfg, "loss_cap_recovery_mark_max_age_sec", 5.0))
        running = bool(_live_process_status_base().get("BTC"))
        used = int(record.get("entries_used", 0))
        result.update(
            state=record["mode"] if fresh and running else "WAITING_UPDATE",
            last_worker_state=record.get("mode"), entries_used=used,
            net_pnl_usd=record.get("last_net_pnl_usd"), last_mark_ts=record.get("last_mark_ts"),
            samples=len(record.get("samples") or []), fresh=fresh, worker_running=running,
        )
        result["allow_entries"] = (
            result["state"] == "RECOVERY_ACTIVE" and 0 <= used < result["max_entries_per_day"]
        )
    except Exception:
        # A malformed guard file must not turn /api/state into an HTTP 500.
        result.update(state="UNAVAILABLE", allow_entries=False)
    return result


def _risk_state(pnl: dict) -> str:
    """Project the worker gate with its lane and bankroll, never wallet/Paper mix."""
    live = _state.get("bot_mode") == "live"
    if live:
        balance = _state.get("balance_pusd")
        equity = (float(balance) if balance is not None else 0.0) + float(_state.get("value_usd") or 0.0)
    else:
        equity = float(cfg.paper_equity_usd)
        guard = _paper_guard_snapshot()
        if guard["state"] == "PROFIT_TAKE":
            return "PROFIT_TAKE"
        if guard["state"] == "UNAVAILABLE":
            return "GUARD_UNAVAILABLE"
    profit_target = daily_profit_target_usd(cfg, not live)
    if profit_target is not None and pnl["realized_usd"] >= profit_target:
        return "PROFIT_TAKE"
    if cfg.max_daily_loss_fraction > 0 and pnl["realized_usd"] <= -(equity * cfg.max_daily_loss_fraction):
        if not live and guard["allow_entries"]:
            return "RECOVERY_ACTIVE"
        return "LOSS_CAP"
    streak = consecutive_losses(not live)
    if cfg.consecutive_loss_kill > 0 and streak >= cfg.consecutive_loss_kill:
        return f"LOSS_STREAK({streak})"
    return "OK"

_live_account_cache: dict[str, Any] = {"ts": 0.0, "account": None}
_cumulative_cache: dict[str, Any] = {"ts": 0.0, "value": None}


def _cumulative_performance() -> dict[str, Any]:
    """Return all-recorded settled performance, separate from today's risk PnL.

    ``accounting_snapshot`` intentionally uses the current Beijing day for risk
    gating.  The console's cumulative cards need a different, explicit
    lifetime scope; keeping this calculation separate prevents a quiet day
    from looking like an empty ledger.
    """
    now = time.time()
    cached = _cumulative_cache.get("value")
    if cached is not None and now - float(_cumulative_cache.get("ts", 0.0)) < 5.0:
        return cached
    result: dict[str, Any] = {}
    for lane, dry_run in (("paper", True), ("live", False)):
        # Build the FIFO ledger once per lane. Calling realized_pnl_by_day
        # five times rescanned the 300MB database and made the first dashboard
        # frame appear blank for many seconds.
        _, events, _ = _fifo_ledger(dry_run)
        realized = sum(float(event.get("pnl") or 0.0) for event in events)
        wins = sum(1 for event in events if float(event.get("pnl") or 0.0) >= 0)
        losses = sum(1 for event in events if float(event.get("pnl") or 0.0) < 0)
        by_asset: dict[str, dict[str, Any]] = {asset: {"realized_usd": 0.0, "wins": 0, "losses": 0} for asset in ("BTC",)}
        for event in events:
            asset = str(event.get("asset") or "").upper()
            if asset not in by_asset:
                continue
            pnl = float(event.get("pnl") or 0.0)
            by_asset[asset]["realized_usd"] += pnl
            by_asset[asset]["wins" if pnl >= 0 else "losses"] += 1
        result[lane] = {
            "realized_usd": realized,
            "wins": wins,
            "losses": losses,
            "by_asset": by_asset,
        }
    _cumulative_cache.update(ts=now, value=result)
    return result


def _mode_split_snapshot(pnl: dict, paper_account: Optional[dict] = None) -> dict[str, Any]:
    """Separate ledgers with one FIFO basis for holdings and performance."""
    paper = paper_account if paper_account is not None else _paper_account_snapshot()
    # The live ledger is read-only while this dashboard is in Paper mode, but
    # rebuilding its FIFO book on every websocket frame scanned the full order
    # history. Refresh it at most every two seconds; Paper accounting remains
    # on its one-second worker-aligned cache above.
    now = time.time()
    live = _live_account_cache.get("account")
    if live is None or now - float(_live_account_cache.get("ts", 0.0)) >= 2.0:
        live = accounting_snapshot(False, now=now)
        _live_account_cache.update(ts=now, account=live)
    balance = float(_state.get("balance_pusd") or 0.0)
    value = float(_state.get("value_usd") or 0.0)
    result = {}
    cumulative = _cumulative_performance()
    for lane, account in (("paper", paper), ("live", live)):
        summary = account["pnl"]
        by_asset = {
            asset: {"realized_usd": 0.0, "wins": 0, "losses": 0, "pending": 0, "open_value_usd": 0.0}
            for asset in ("BTC",)
        }
        by_asset.update(account["by_asset"])
        result[lane] = {
            "capital_base_usd": float(cfg.paper_equity_usd) if lane == "paper" else max(balance + value, 1.0),
            **summary,
            "open_value_usd": account["open_value_usd"] if lane == "paper" else value,
            "valuation": "entry_cost" if lane == "paper" else "market",
            "by_asset": by_asset,
            "cumulative_realized_usd": cumulative[lane]["realized_usd"],
            "cumulative_wins": cumulative[lane]["wins"],
            "cumulative_losses": cumulative[lane]["losses"],
            "cumulative_by_asset": cumulative[lane]["by_asset"],
        }
    return result

_paper_open_cache: dict[str, Any] = {"ts": 0.0, "day": 0.0, "account": None}


def _paper_account_snapshot() -> dict:
    """Share one brief snapshot between Paper count, detail and exposure."""
    now = time.time()
    day = local_day_start_ts(now)
    account = _paper_open_cache.get("account")
    if account is None or now - float(_paper_open_cache["ts"]) >= 1.0 or _paper_open_cache["day"] != day:
        account = accounting_snapshot(True, now=now)
        _paper_open_cache.update(ts=now, day=day, account=account)
    return account


def _paper_positions_snapshot() -> list[dict]:
    return _paper_account_snapshot()["positions"]


def _paper_open_stats(positions: Optional[list[dict]] = None) -> tuple[int, float]:
    """Outstanding shares after FIFO exits; valuation is remaining entry cost."""
    rows = positions if positions is not None else _paper_positions_snapshot()
    return len(rows), round(sum(float(p["notional_usd"]) for p in rows), 4)


def _risk_snapshot(pnl: dict, paper_positions: Optional[list[dict]] = None) -> dict[str, Any]:
    live_positions = _filter_active_positions(_state.get("positions") or [])
    position_value = 0.0
    for item in live_positions:
        try:
            position_value += float(item.get("size") or 0) * float(item.get("curPrice") or 0)
        except (TypeError, ValueError):
            continue
    if _state.get("bot_mode") == "live":
        positions = live_positions
    else:
        paper_count, paper_value = _paper_open_stats(paper_positions)
        positions = [None] * paper_count
        position_value = paper_value
    # Orders are read from SQLite rather than `_state`: the dashboard keeps
    # recent orders as a response-only query, so relying on `_state.orders`
    # silently reported zero open orders.
    open_order_notional = 0.0
    try:
        with closing(db()) as c:
            row = c.execute(
                "SELECT COUNT(*), COALESCE(SUM(COALESCE(size, 0) * COALESCE(price, 0)), 0) FROM orders WHERE LOWER(COALESCE(status, '')) "
                "IN ('submitted','open','partial','partially_filled','pending') AND dry_run=?",
                (0 if _state.get("bot_mode") == "live" else 1,),
            ).fetchone()
        open_orders = int(row[0] or 0) if row else 0
        open_order_notional = float(row[1] or 0.0) if row else 0.0
    except Exception:
        open_orders = 0
    balance = _state.get("balance_pusd")
    equity = ((float(balance) if balance is not None else 0.0) + position_value
              if _state.get("bot_mode") == "live"
              else float(getattr(cfg, "paper_equity_usd", 0.0)))
    exposure_ratio = position_value / equity if equity > 0 else None
    risk_state = _risk_state(pnl)
    return {
        "state": risk_state,
        "position_count": len(positions),
        "position_value_usd": round(position_value, 4),
        "valuation": "market" if _state.get("bot_mode") == "live" else "entry_cost",
        "capital_base_usd": equity,
        "open_orders": open_orders,
        "open_order_notional_usd": round(open_order_notional, 4),
        "exposure_ratio": round(exposure_ratio, 6) if exposure_ratio is not None else None,
        "circuit_reason": None if risk_state == "OK" else risk_state,
        "daily_realized_usd": pnl.get("realized_usd"),
        "max_daily_realized_profit_fraction": float(getattr(cfg, "max_daily_realized_profit_fraction", 0.0) or 0.0),
        "daily_profit_target_usd": daily_profit_target_usd(cfg, _state.get("bot_mode") != "live"),
        "loss_recovery": _paper_guard_snapshot(),
        "daily_profit_rate": (
            float(pnl.get("realized_usd") or 0.0) / equity if equity > 0 else None
        ),
        "max_daily_loss_fraction": cfg.max_daily_loss_fraction,
        # Paper lanes are isolated by asset; expose both the per-asset gate
        # and the aggregate display capacity so 5/12 is not misread as 5/3.
        "max_open_positions": cfg.max_open_positions * (4 if _state.get("bot_mode") != "live" else 2),
        "max_open_positions_per_asset": cfg.max_open_positions,
        "position_scope": "per_asset",
        "updated_at": time.time(),
    }


def _stop_loss_snapshot() -> dict[str, Any]:
    """Expose the deterministic maybe_reversal_exit guard and last event."""
    mode = "live" if _state.get("bot_mode") == "live" else "paper"
    enabled = bool(getattr(cfg, "reversal_exit_enabled", False) or getattr(cfg, "early_reversal_exit_enabled", False))
    threshold = float(getattr(cfg, "reversal_held_bid_threshold", 0.0) or 0.0)
    drawdown = float(getattr(cfg, "reversal_held_bid_drawdown", 0.0) or 0.0)
    trigger = f"持仓盘口 <= {threshold:.2f}" if threshold > 0 else f"持仓盘口回撤 >= {drawdown * 100:.1f}%"
    # Disabled early-exit settings must not override the active 90s guard.
    normal_enabled = bool(getattr(cfg, "reversal_exit_enabled", False))
    early_enabled = bool(getattr(cfg, "early_reversal_exit_enabled", False))
    window = max(float(getattr(cfg, "reversal_exit_window_sec", 0.0)) if normal_enabled else 0.0,
                 float(getattr(cfg, "early_reversal_exit_window_sec", 0.0)) if early_enabled else 0.0)
    confirmations = max(int(getattr(cfg, "reversal_confirm_checks", 0)) if normal_enabled else 0,
                        int(getattr(cfg, "early_reversal_confirm_checks", 0)) if early_enabled else 0)
    result: dict[str, Any] = {}
    workers = _live_process_status_base()
    open_paper = remaining_positions(True) if mode == "paper" else []
    for asset in ("BTC",):
        item: dict[str, Any] = {"enabled": enabled, "mode": mode, "status": ("已启用·等待触发" if enabled else "未启用"), "trigger": trigger, "window_sec": window, "confirmations": confirmations, "last_exit": None}
        if mode == "paper" and normal_enabled:
            item.update(coverage="configured_window", window_sec=window)
        try:
            dry = 0 if mode == "live" else 1
            with db() as c:
                row = c.execute("SELECT ts,status,side,error,price,filled_size FROM orders WHERE UPPER(COALESCE(asset,''))=? AND dry_run=? AND side LIKE 'SELL_%' ORDER BY id DESC LIMIT 1", (asset, dry)).fetchone()
            if row:
                status = str(row[1] or "")
                item["last_exit"] = {"ts": row[0], "status": status, "side": row[2], "reason": row[3], "price": row[4], "filled_size": row[5]}
                if enabled:
                    effective = status in ("exit_filled", "exit_matched", "exit_partial", "exit_dry_run")
                    item["status"] = (("已启用·有模拟退出" if dry else "已启用·有实盘退出") if effective else "已启用·最近退出待核查")
            if mode == "paper" and enabled:
                pending_conditions = {p["condition_id"] for p in open_paper if p.get("asset") == asset}
                if pending_conditions:
                    with db() as c:
                        decision = c.execute(
                            "SELECT ts,condition_id,action,reason FROM decisions WHERE asset=? AND dry_run=1 "
                            "AND action IN ('SKIP_EXIT_BOOK','SKIP_EXIT_SIZE') AND ts>? ORDER BY id DESC LIMIT 1",
                            (asset, time.time() - 30),
                        ).fetchone()
                    if decision and decision[1] in pending_conditions:
                        item["status"] = "已启用·等待买盘" if decision[2] == "SKIP_EXIT_BOOK" else "已启用·等待成交深度"
                        item["execution_wait"] = {"ts": decision[0], "action": decision[2], "reason": decision[3]}
        except Exception:
            pass
        item["running"] = bool(workers.get(asset))
        if enabled and not item["running"]:
            item["status"] = "保护进程未运行"
        result[asset] = item
    return result


def _filter_active_positions(positions: list[dict]) -> list[dict]:
    """Return positions that still require trading attention.

    The Data API keeps settled winning positions in the same collection and
    marks them ``redeemable`` (or ``mergeable``).  They are no longer open
    trading positions and must not keep the risk gate or dashboard showing a
    stale holding forever.
    """
    out: list[dict] = []
    for p in positions:
        cp = p.get("curPrice")
        sz = p.get("size")
        if cp is None or sz is None:
            continue
        try:
            if float(cp) < 0.0 or float(sz) <= 0.0:
                continue
        except Exception:
            continue
        if bool(p.get("redeemable")):
            continue
        out.append(p)
    return out


def _filter_settled_positions(positions: list[dict]) -> list[dict]:
    """Keep resolved positions visible in a separate settlement section."""
    out: list[dict] = []
    for position in positions:
        if not isinstance(position, dict):
            continue
        if bool(position.get("redeemable")) and float(position.get("size") or 0) > 0:
            out.append(position)
    return out


def _compact_sports_meta(meta: dict[str, Any]) -> dict[str, Any]:
    """Keep the 500ms dashboard poll small; detailed sports data is not needed by the card."""
    if not isinstance(meta, dict):
        return {}
    compact = {key: meta.get(key) for key in ("enabled", "mode", "status", "paper_only", "live_orders", "running", "heartbeat_ts", "market_count", "decision_count", "order_count", "orders_new", "settled_new", "error") if key in meta}
    if isinstance(meta.get("recent_decisions"), list):
        compact["recent_decisions"] = meta["recent_decisions"][-10:]
    markets = meta.get("markets")
    decisions = meta.get("decisions")
    orders = meta.get("orders")
    if isinstance(markets, list):
        compact["market_count"] = len(markets)
    if isinstance(decisions, list):
        compact["decision_count"] = len(decisions)
        compact["recent_decisions"] = decisions[-10:]
    if isinstance(orders, list):
        compact["order_count"] = len(orders)
        compact["recent_orders"] = orders[-10:]
    return compact


def _feed_snapshot() -> dict[str, Any]:
    weather = _state.get("weather_meta") or {}
    sports = _state.get("sports_meta") or {}
    return {
        "kalshi_weather": dict(weather.get("feed") or {}),
        "odds": dict(sports.get("feed") or {}),
    }


@app.get("/api/polymarket/profile")
def polymarket_profile():
    return _portfolio_snapshot()


@app.get("/api/polymarket/activity")
def polymarket_activity(offset: int = Query(0, ge=0, le=500), limit: int = Query(50, ge=1, le=200), kind: str = Query("", max_length=16)):
    try:
        return _polymarket_activity_rows(limit=limit, offset=offset, kind=kind)
    except requests.RequestException as exc:
        raise HTTPException(status_code=503, detail="Polymarket activity temporarily unavailable") from exc


@app.get("/api/polymarket/ledger")
def polymarket_ledger():
    return _funding_snapshot()


@app.get("/api/orders")
def orders_page(offset: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=200),
                lane: Literal["all", "paper", "live"] = "all",
                asset: str = ""):
    """Full order ledger with mode filtering and server-side pagination."""
    if not DB_PATH.exists():
        return {"rows": [], "total": 0, "offset": offset, "limit": limit, "lane": lane, "asset": asset.upper() or None}
    asset_name = asset.strip().upper() or "BTC"
    if asset_name and asset_name not in ("BTC",):
        raise HTTPException(status_code=422, detail="Unsupported asset")
    with closing(db()) as c:
        c.execute("BEGIN")
        where = []
        params: list[Any] = []
        if lane != "all":
            where.append("dry_run=?")
            params.append(1 if lane == "paper" else 0)
        if asset_name:
            where.append("UPPER(COALESCE(asset,''))=?")
            params.append(asset_name)
        clause = (" WHERE " + " AND ".join(where)) if where else ""
        total = int(c.execute("SELECT COUNT(*) FROM orders" + clause, params).fetchone()[0] or 0)
        rows_sql = """SELECT o.id,o.ts,o.market_slug,o.condition_id,o.token_id,o.asset,o.side,
                    o.size,o.price,o.order_id,o.status,o.filled_size,o.error,o.dry_run,
                    r.winning_token, r.resolved_ts
                    FROM orders o LEFT JOIN resolutions r ON r.condition_id=o.condition_id""" + clause.replace("dry_run", "o.dry_run").replace("asset", "o.asset") + " ORDER BY o.id DESC LIMIT ? OFFSET ?"
        rows = [dict(row) for row in c.execute(rows_sql, [*params, limit, offset]).fetchall()]
    return {"rows": rows, "total": total, "offset": offset, "limit": limit, "lane": lane, "asset": asset_name or None}


@app.get("/api/state")
def state():
    m = _state.get("market")
    eth_m = _state.get("eth_market")
    now = time.time()
    paper_account = _paper_account_snapshot()
    holdings = _account_positions_snapshot()
    active_positions = holdings["positions"]
    settled_positions = holdings["settled_positions"]
    pending_settlement_count = holdings.get("pending_count")
    redeemable_count = holdings.get("redeemable_count")
    portfolio = _portfolio_snapshot(holdings)
    external = portfolio.get("live_summary") if isinstance(portfolio, dict) else None
    if _state.get("bot_mode") == "live":
        pnl = realized_pnl_today()
        if isinstance(external, dict) and external.get("available"):
            # External account state wins after manual settlement/redemption.
            pnl = {**pnl,
                "realized_usd": external.get("today_realized_usd") if external.get("today_realized_usd") is not None else pnl.get("realized_usd"),
                "wins": int(external.get("today_wins") or 0),
                "losses": int(external.get("today_losses") or 0),
                "pending": pending_settlement_count}
    else:
        pnl = paper_account["pnl"]
    paper_positions = paper_account["positions"]
    use_decision_log_fallback = "rtds" not in cfg.price_signal_source.strip().lower()
    btc_signal = _state.get("btc_signal") or (
        _fallback_signal_from_decisions("BTC") if use_decision_log_fallback else None
    )
    eth_signal = _state.get("eth_signal") or (
        _fallback_signal_from_decisions("ETH") if use_decision_log_fallback else None
    )
    mode_split = _mode_split_snapshot(pnl, paper_account)
    mode_split["live"].update({
        "pending": pending_settlement_count, "redeemable_count": redeemable_count,
        "open_value_usd": holdings.get("total_value_usd"),
        "pending_value_usd": holdings.get("pending_value_usd"),
        "redeemable_value_usd": holdings.get("redeemable_value_usd"),
    })
    # The account lane is chain-authoritative whenever the live gate is enabled,
    # even if the worker is currently stopped. This keeps the dashboard aligned
    # with Polymarket after a manual trade or redemption.
    chain_live_enabled = bool(_service_status_snapshot().get("BTC", {}).get("live_enabled"))
    if (chain_live_enabled or _state.get("bot_mode") == "live") and isinstance(external, dict) and external.get("available"):
        live_lane = dict(mode_split.get("live") or {})
        today_realized = external.get("today_realized_usd")
        live_realized = external.get("realized_usd")
        live_wins = int(external.get("wins") or 0)
        live_losses = int(external.get("losses") or 0)
        today_wins = int(external.get("today_wins") or 0)
        today_losses = int(external.get("today_losses") or 0)
        live_lane.update({
            # Top-level lane values are today's values; cumulative_* are the
            # account-wide values from Polymarket v2 user-pnl/activity.
            "realized_usd": today_realized if today_realized is not None else live_lane.get("realized_usd"),
            "wins": today_wins,
            "losses": today_losses,
            "cumulative_realized_usd": live_realized if live_realized is not None else live_lane.get("cumulative_realized_usd"),
            "cumulative_wins": live_wins,
            "cumulative_losses": live_losses,
            "pending": pending_settlement_count,
            "external_source": external.get("source"),
            "rolling_24h_usd": external.get("rolling_24h_usd"),
            "rolling_24h_base_ts": external.get("rolling_24h_base_ts"),
            "rolling_24h_updated_ts": external.get("rolling_24h_updated_ts"),
        })
        live_lane["cumulative_by_asset"] = {"BTC": {
            "realized_usd": live_realized if live_realized is not None else 0.0,
            "wins": live_wins,
            "losses": live_losses,
            "pending": pending_settlement_count,
            "open_value_usd": float(holdings.get("total_value_usd") or 0.0),
        }}
        live_lane["capital_base_usd"] = portfolio.get("portfolio_value_usd") or live_lane.get("capital_base_usd")
        live_lane["by_asset"] = {"BTC": {
            "realized_usd": live_lane.get("realized_usd"),
            "wins": live_lane.get("wins", 0),
            "losses": live_lane.get("losses", 0),
            "pending": live_lane.get("pending", 0),
            "open_value_usd": float(holdings.get("total_value_usd") or 0.0),
        }}
        mode_split["live"] = live_lane
    return {
        "now": now,
        "bot_running": _state["bot_running"],
        "production_runtime": (_live_worker_runtime("BTC") if _state.get("bot_mode") == "live" else _paper_worker_daily_loss("polymarket-test-btc-paper.service", ROOT.parent.parent, DB_PATH)),
        "bot_mode": _state.get("bot_mode", "stopped"),
        "bot_assets": {"BTC": bool(_state.get("bot_assets", {}).get("BTC"))},
        "instance": "polyauto" if _is_polyauto_instance() else "main",
        "service_modes": _service_status_snapshot(),
        "paper_services": _paper_services_snapshot(),
        "risk_state": _risk_state(pnl),
        "risk_snapshot": _risk_snapshot(pnl, paper_positions),
        "stop_loss": _stop_loss_snapshot(),
        "wallet": {
            "eoa": cfg.wallet_address,
            "deposit": _deposit_wallet_address(),
            "funder": cfg.funder_address,
            "balance_pusd": _state.get("balance_pusd"),
            "pending_deposit_usd": _state.get("balance_usdce"),
            "fund_activation": portfolio.get("fund_activation"),
            "value_usd": holdings.get("total_value_usd"),
            "value_source": holdings.get("source"),
            "position_value_usd": holdings.get("active_value_usd"),
            "pending_value_usd": holdings.get("pending_value_usd"),
            "redeemable_value_usd": holdings.get("redeemable_value_usd"),
            "pending_count": pending_settlement_count,
            "redeemable_count": redeemable_count,
            "snapshot_updated_at": holdings.get("updated_at"),
            "snapshot_stale": bool(holdings.get("stale")),
            "binding": _wallet_status(),
            "polymarket_profile": portfolio,
        },
        "polymarket_profile": portfolio,
        "market": (
            None
            if not m
            else {
                **m,
                "t_remaining": m["end_ts"] - now,
            }
        ),
        "eth_market": (
            None
            if not eth_m
            else {
                **eth_m,
                "t_remaining": eth_m["end_ts"] - now,
            }
        ),
        "book_up": _state.get("book_up"),
        "book_down": _state.get("book_down"),
        "eth_book_up": _state.get("eth_book_up"),
        "eth_book_down": _state.get("eth_book_down"),
        "btc_signal": btc_signal,
        "eth_signal": eth_signal,
        "btc_price_history": list(_state.get("btc_price_history") or []),
        "eth_price_history": list(_state.get("eth_price_history") or []),
        "weather": list(_state.get("weather") or []),
        "sports": list(_state.get("sports") or []),
        # The compact `sports` list feeds the card; this metadata keeps the
        # full paper audit (markets, decisions and simulated orders) available
        # to operators without coupling it to the CLOB order tables.
        "sports_meta": _compact_sports_meta(_state.get("sports_meta") or {}),
        "feeds": _feed_snapshot(),
        "agent_status": _agent_status_snapshot(),
        "openclaw_bridge": _openclaw_bridge_snapshot(),
        "llm": {
            "settings": {
                "primary_model": _llm_settings_response().get("primary", {}).get("model", ""),
                "secondary_model": _llm_settings_response().get("secondary", {}).get("model", ""),
            },
            "usage": _llm_usage_snapshot(),
        },
        "positions": active_positions,
        "paper_positions": paper_positions,
        "settled_positions": settled_positions,
        "portfolio_positions": holdings,
        "pending_settlement_count": pending_settlement_count,
        "redeemable_count": redeemable_count,
        "chain_holdings": {
            "pending_count": pending_settlement_count,
            "redeemable_count": redeemable_count,
            "pending_value_usd": holdings.get("pending_value_usd"),
            "redeemable_value_usd": holdings.get("redeemable_value_usd"),
            "total_value_usd": holdings.get("total_value_usd"),
            "available": bool(holdings.get("available")),
            "stale": bool(holdings.get("stale")),
            "updated_at": holdings.get("updated_at"),
            "source": holdings.get("source"),
        },
        "pnl": pnl,
        "mode_split": mode_split,
        "today_counts": _today_counts(),
        "orders_total": _orders_total(),
        "config": {
            "min_entry_price": cfg.min_entry_price,
            "max_entry_price": cfg.max_entry_price,
            "up_min_entry_price": cfg.up_min_entry_price,
            "up_max_entry_price": cfg.up_max_entry_price,
            "min_net_edge": cfg.min_net_edge,
            "high_price_edge_threshold": cfg.high_price_edge_threshold,
            "high_price_min_net_edge": cfg.high_price_min_net_edge,
            "high_price_btc_delta_usd": cfg.high_price_btc_delta_usd,
            "btc_delta_filter_enabled": cfg.btc_delta_filter_enabled,
            "btc_delta_threshold_usd": cfg.btc_delta_threshold_usd,
            "btc_up_min_delta_usd": cfg.btc_up_min_delta_usd,
            "btc_up_max_delta_usd": cfg.btc_up_max_delta_usd,
            "btc_down_min_delta_usd": cfg.btc_down_min_delta_usd,
            "btc_down_max_delta_usd": cfg.btc_down_max_delta_usd,
            "btc_price_symbol": cfg.btc_price_symbol,
            "price_signal_source": cfg.price_signal_source,
            "rtds_ws_url": cfg.rtds_ws_url,
            "rtds_topic": cfg.rtds_topic,
            "rtds_max_age_sec": cfg.rtds_max_age_sec,
            "rtds_stale_max_age_sec": cfg.rtds_stale_max_age_sec,
            "chainlink_btc_twap_30s_feed_id": cfg.chainlink_btc_twap_30s_feed_id,
            "chainlink_eth_twap_30s_feed_id": cfg.chainlink_eth_twap_30s_feed_id,
            "price_source_guard_enabled": cfg.price_source_guard_enabled,
            "allow_binance_proxy_chainlink_entries": cfg.allow_binance_proxy_chainlink_entries,
            "eth_market_enabled": cfg.eth_market_enabled,
            "eth_trading_enabled": cfg.eth_trading_enabled,
            "instance_name": getattr(cfg, "instance_name", "main"),
            "btc_live_enabled": _service_status_snapshot()["BTC"]["live_enabled"],
            "eth_live_allowed": bool(getattr(cfg, "eth_live_allowed", True)),
            "weather_live_allowed": bool(getattr(cfg, "weather_live_allowed", True)),
            "sports_live_allowed": False,
            "eth_series_slug": cfg.eth_series_slug,
            "eth_price_symbol": cfg.eth_price_symbol,
            "eth_delta_filter_enabled": cfg.eth_delta_filter_enabled,
            "eth_delta_threshold_usd": cfg.eth_delta_threshold_usd,
            "eth_up_min_delta_usd": cfg.eth_up_min_delta_usd,
            "eth_up_max_delta_usd": cfg.eth_up_max_delta_usd,
            "eth_down_min_delta_usd": cfg.eth_down_min_delta_usd,
            "eth_down_max_delta_usd": cfg.eth_down_max_delta_usd,
            "eth_high_price_delta_usd": cfg.eth_high_price_delta_usd,
            "eth_early_strong_delta_up_min_delta_usd": cfg.eth_early_strong_delta_up_min_delta_usd,
            "eth_early_strong_delta_down_max_delta_usd": cfg.eth_early_strong_delta_down_max_delta_usd,
            "eth_strong_delta_up_min_delta_usd": cfg.eth_strong_delta_up_min_delta_usd,
            "eth_strong_delta_down_max_delta_usd": cfg.eth_strong_delta_down_max_delta_usd,
            "eth_late_edge_up_min_delta_usd": cfg.eth_late_edge_up_min_delta_usd,
            "eth_late_edge_down_max_delta_usd": cfg.eth_late_edge_down_max_delta_usd,
            "eth_late_edge_confirm_checks": cfg.eth_late_edge_confirm_checks,
            "eth_early_strong_delta_risk_fraction": cfg.eth_early_strong_delta_risk_fraction,
            "eth_strong_delta_risk_fraction": cfg.eth_strong_delta_risk_fraction,
            "eth_order_risk_fraction": cfg.eth_order_risk_fraction,
            "eth_late_edge_risk_fraction": cfg.eth_late_edge_risk_fraction,
            "seconds_before_close": cfg.seconds_before_close,
            "min_t_remaining_sec": cfg.min_t_remaining_sec,
            "mid_entry_enabled": cfg.mid_entry_enabled,
            "mid_entry_window_sec": cfg.mid_entry_window_sec,
            "mid_entry_min_t_remaining_sec": cfg.mid_entry_min_t_remaining_sec,
            "mid_entry_min_price": cfg.mid_entry_min_price,
            "mid_entry_max_price": cfg.mid_entry_max_price,
            "mid_entry_confirm_checks": cfg.mid_entry_confirm_checks,
            "mid_entry_risk_fraction": cfg.mid_entry_risk_fraction,
            "mid_btc_up_min_delta_usd": cfg.mid_btc_up_min_delta_usd,
            "mid_btc_down_max_delta_usd": cfg.mid_btc_down_max_delta_usd,
            "strong_delta_entry_enabled": cfg.strong_delta_entry_enabled,
            "strong_delta_entry_window_sec": cfg.strong_delta_entry_window_sec,
            "strong_delta_entry_min_t_remaining_sec": cfg.strong_delta_entry_min_t_remaining_sec,
            "strong_delta_entry_min_price": cfg.strong_delta_entry_min_price,
            "strong_delta_entry_max_price": cfg.strong_delta_entry_max_price,
            "strong_delta_entry_up_min_delta_usd": cfg.strong_delta_entry_up_min_delta_usd,
            "strong_delta_entry_down_max_delta_usd": cfg.strong_delta_entry_down_max_delta_usd,
            "strong_delta_entry_confirm_checks": cfg.strong_delta_entry_confirm_checks,
            "strong_delta_entry_risk_fraction": cfg.strong_delta_entry_risk_fraction,
            "early_strong_delta_entry_enabled": cfg.early_strong_delta_entry_enabled,
            "early_strong_delta_entry_window_sec": cfg.early_strong_delta_entry_window_sec,
            "early_strong_delta_entry_min_t_remaining_sec": cfg.early_strong_delta_entry_min_t_remaining_sec,
            "early_strong_delta_entry_min_price": cfg.early_strong_delta_entry_min_price,
            "early_strong_delta_entry_max_price": cfg.early_strong_delta_entry_max_price,
            "early_strong_delta_entry_up_min_delta_usd": cfg.early_strong_delta_entry_up_min_delta_usd,
            "early_strong_delta_entry_down_max_delta_usd": cfg.early_strong_delta_entry_down_max_delta_usd,
            "early_strong_delta_entry_confirm_checks": cfg.early_strong_delta_entry_confirm_checks,
            "early_strong_delta_entry_risk_fraction": cfg.early_strong_delta_entry_risk_fraction,
            "early_strong_delta_entry_hedge_enabled": cfg.early_strong_delta_entry_hedge_enabled,
            "early_strong_delta_entry_hedge_max_price": cfg.early_strong_delta_entry_hedge_max_price,
            "normal_scale_in_enabled": cfg.normal_scale_in_enabled,
            "late_edge_entry_enabled": cfg.late_edge_entry_enabled,
            "late_edge_entry_window_sec": cfg.late_edge_entry_window_sec,
            "late_edge_entry_min_t_remaining_sec": cfg.late_edge_entry_min_t_remaining_sec,
            "late_edge_entry_min_price": cfg.late_edge_entry_min_price,
            "late_edge_entry_max_price": cfg.late_edge_entry_max_price,
            "late_edge_entry_delta_filter_enabled": cfg.late_edge_entry_delta_filter_enabled,
            "late_edge_entry_up_min_delta_usd": cfg.late_edge_entry_up_min_delta_usd,
            "late_edge_entry_down_max_delta_usd": cfg.late_edge_entry_down_max_delta_usd,
            "late_edge_entry_confirm_checks": cfg.late_edge_entry_confirm_checks,
            "late_edge_entry_mid_confirm_checks": cfg.late_edge_entry_mid_confirm_checks,
            "late_edge_entry_late_confirm_checks": cfg.late_edge_entry_late_confirm_checks,
            "late_edge_entry_risk_fraction": cfg.late_edge_entry_risk_fraction,
            "eth_late_edge_delta_filter_enabled": cfg.eth_late_edge_delta_filter_enabled,
            "stable_delta_entry_enabled": cfg.stable_delta_entry_enabled,
            "stable_delta_entry_window_sec": cfg.stable_delta_entry_window_sec,
            "stable_delta_entry_min_t_remaining_sec": cfg.stable_delta_entry_min_t_remaining_sec,
            "stable_delta_entry_min_price": cfg.stable_delta_entry_min_price,
            "stable_delta_entry_max_price": cfg.stable_delta_entry_max_price,
            "stable_delta_entry_min_abs_delta_usd": cfg.stable_delta_entry_min_abs_delta_usd,
            "stable_delta_entry_max_abs_delta_usd": cfg.stable_delta_entry_max_abs_delta_usd,
            "stable_delta_entry_max_delta_move_usd": cfg.stable_delta_entry_max_delta_move_usd,
            "stable_delta_entry_confirm_checks": cfg.stable_delta_entry_confirm_checks,
            "stable_delta_entry_risk_fraction": cfg.stable_delta_entry_risk_fraction,
            "entry_momentum_filter_enabled": cfg.entry_momentum_filter_enabled,
            "entry_momentum_min_price": cfg.entry_momentum_min_price,
            "entry_momentum_max_price": cfg.entry_momentum_max_price,
            "entry_momentum_max_ask_move": cfg.entry_momentum_max_ask_move,
            "eth_stable_delta_min_abs_usd": cfg.eth_stable_delta_min_abs_usd,
            "eth_stable_delta_max_abs_usd": cfg.eth_stable_delta_max_abs_usd,
            "eth_stable_delta_max_move_usd": cfg.eth_stable_delta_max_move_usd,
            "eth_stable_delta_trade_enabled": cfg.eth_stable_delta_trade_enabled,
            "early_entry_enabled": cfg.early_entry_enabled,
            "early_entry_seconds_before_close": cfg.early_entry_seconds_before_close,
            "early_entry_min_price": cfg.early_entry_min_price,
            "early_entry_max_price": cfg.early_entry_max_price,
            "tail_entry_enabled": cfg.tail_entry_enabled,
            "tail_entry_window_sec": cfg.tail_entry_window_sec,
            "tail_entry_min_t_remaining_sec": cfg.tail_entry_min_t_remaining_sec,
            "tail_entry_min_price": cfg.tail_entry_min_price,
            "tail_entry_max_price": cfg.tail_entry_max_price,
            "tail_entry_confirm_checks": cfg.tail_entry_confirm_checks,
            "tail_entry_risk_fraction": cfg.tail_entry_risk_fraction,
            "strong_normal_reverse_enabled": cfg.strong_normal_reverse_enabled,
            "strong_normal_reverse_held_bid_threshold": cfg.strong_normal_reverse_held_bid_threshold,
            "strong_normal_reverse_min_price": cfg.strong_normal_reverse_min_price,
            "strong_normal_reverse_max_price": cfg.strong_normal_reverse_max_price,
            "strong_normal_reverse_confirm_checks": cfg.strong_normal_reverse_confirm_checks,
            "strong_normal_reverse_risk_fraction": cfg.strong_normal_reverse_risk_fraction,
            "scale_in_after_early_enabled": cfg.scale_in_after_early_enabled,
            "max_buys_per_market": cfg.max_buys_per_market,
            "one_side_per_market": cfg.one_side_per_market,
            "trend_overheat_filter_enabled": cfg.trend_overheat_filter_enabled,
            "trend_overheat_min_streak": cfg.trend_overheat_min_streak,
            "trend_overheat_price_floor": cfg.trend_overheat_price_floor,
            "order_risk_fraction": cfg.order_risk_fraction,
            "order_fixed_notional_usd": cfg.order_fixed_notional_usd,
            "order_balance_reserve_usd": cfg.order_balance_reserve_usd,
            "min_order_notional_usd": cfg.min_order_notional_usd,
            "target_min_orders_per_hour": cfg.target_min_orders_per_hour,
            "max_orders_per_hour": cfg.max_orders_per_hour,
            "max_open_positions": cfg.max_open_positions,
            "max_daily_loss_fraction": cfg.max_daily_loss_fraction,
            "max_daily_realized_profit_fraction": getattr(cfg, "max_daily_realized_profit_fraction", 0.0),
            "max_daily_realized_profit_usd": cfg.max_daily_realized_profit_usd,
            "order_retry_cooldown_sec": cfg.order_retry_cooldown_sec,
            "max_buy_retries_per_market": cfg.max_buy_retries_per_market,
            "retry_min_t_remaining_sec": cfg.retry_min_t_remaining_sec,
            "max_retry_price_drift_ticks": cfg.max_retry_price_drift_ticks,
            "fok_price_buffer_ticks": cfg.fok_price_buffer_ticks,
            "market_stale_grace_sec": cfg.market_stale_grace_sec,
            "confirm_checks": cfg.confirm_checks,
            "stagnation_window_sec": cfg.stagnation_window_sec,
            "volatility_window_sec": cfg.volatility_window_sec,
            "max_top_move_ticks": cfg.max_top_move_ticks,
            "early_reversal_exit_enabled": cfg.early_reversal_exit_enabled,
            "early_reversal_exit_window_sec": cfg.early_reversal_exit_window_sec,
            "early_reversal_exit_min_t_remaining_sec": cfg.early_reversal_exit_min_t_remaining_sec,
            "early_reversal_held_bid_threshold": cfg.early_reversal_held_bid_threshold,
            "early_reversal_confirm_checks": cfg.early_reversal_confirm_checks,
            "early_reversal_exit_fraction": cfg.early_reversal_exit_fraction,
            "reversal_exit_enabled": cfg.reversal_exit_enabled,
            "reversal_partial_exit_enabled": cfg.reversal_partial_exit_enabled,
            "reversal_partial_exit_window_sec": cfg.reversal_partial_exit_window_sec,
            "reversal_partial_exit_min_t_remaining_sec": cfg.reversal_partial_exit_min_t_remaining_sec,
            "reversal_partial_held_bid_threshold": cfg.reversal_partial_held_bid_threshold,
            "reversal_partial_held_bid_drawdown": cfg.reversal_partial_held_bid_drawdown,
            "reversal_partial_confirm_checks": cfg.reversal_partial_confirm_checks,
            "reversal_partial_exit_fraction": cfg.reversal_partial_exit_fraction,
            "reversal_exit_window_sec": cfg.reversal_exit_window_sec,
            "reversal_normal_min_t_remaining_sec": cfg.reversal_normal_min_t_remaining_sec,
            "reversal_exit_min_t_remaining_sec": cfg.reversal_exit_min_t_remaining_sec,
            "reversal_opposite_bid_threshold": cfg.reversal_opposite_bid_threshold,
            "reversal_confirm_checks": cfg.reversal_confirm_checks,
            "reversal_held_bid_threshold": cfg.reversal_held_bid_threshold,
            "reversal_held_bid_drawdown": cfg.reversal_held_bid_drawdown,
            "reversal_exit_require_btc_reversal": cfg.reversal_exit_require_btc_reversal,
            "reversal_late_exit_enabled": cfg.reversal_late_exit_enabled,
            "reversal_late_window_sec": cfg.reversal_late_window_sec,
            "reversal_late_held_bid_threshold": cfg.reversal_late_held_bid_threshold,
            "reversal_late_confirm_checks": cfg.reversal_late_confirm_checks,
            "reversal_exit_order_fraction": cfg.reversal_exit_order_fraction,
            "sell_fok_slippage_ticks": cfg.sell_fok_slippage_ticks,
            "sell_exit_max_depth_ticks": cfg.sell_exit_max_depth_ticks,
            "sell_exit_max_depth_levels": cfg.sell_exit_max_depth_levels,
            "sell_exit_fak_fallback_enabled": cfg.sell_exit_fak_fallback_enabled,
            "sell_exit_reconcile_trades": cfg.sell_exit_reconcile_trades,
            "weather_enabled": cfg.weather_enabled,
            "weather_live_trading_enabled": cfg.weather_live_trading_enabled,
            "weather_cities": cfg.weather_cities,
            "weather_scan_interval_sec": cfg.weather_scan_interval_sec,
            "weather_min_edge": cfg.weather_min_edge,
            "weather_min_entry_price": cfg.weather_min_entry_price,
            "weather_max_entry_price": cfg.weather_max_entry_price,
            "sports_enabled": cfg.sports_enabled,
            "sports_market_scan_pages": cfg.sports_market_scan_pages,
            "sports_max_days_ahead": cfg.sports_max_days_ahead,
            "sports_min_edge": cfg.sports_min_edge,
            "sports_min_entry_price": cfg.sports_min_entry_price,
            "sports_max_entry_price": cfg.sports_max_entry_price,
            "sports_max_exposure_usd": cfg.sports_max_exposure_usd,
            "sports_order_size": cfg.sports_order_size,
            "sports_confirm_checks": cfg.sports_confirm_checks,
            "sports_live_trading_enabled": False,
        },
        "decisions": recent_decisions(limit=80),
        "orders": recent_orders(limit=30),
        "errors": _state.get("errors") or {},
    }


@app.get("/api/sports/summary")
def sports_summary():
    """Read the durable worker snapshot even during dashboard cold start."""
    return read_paper_feed_snapshot("SPORTS")


@app.get("/api/pnl/daily")
def pnl_daily(lane: Literal["paper", "live"] = "paper",
              offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=365),
              asset: str = ""):
    from server.pnl_history import daily_rows
    asset_name = asset.strip().upper() or "BTC"
    if asset_name != "BTC":
        raise HTTPException(status_code=422, detail="Unsupported asset")
    try:
        history = daily_rows(DB_PATH, lane == "paper")
    except (OSError, ValueError, sqlite3.Error) as exc:
        raise HTTPException(status_code=503, detail="盈亏历史暂不可用，请稍后重试") from exc
    rows = []
    for row in history:
        bucket = row["by_asset"].get("BTC") or {}
        if bucket:
            rows.append({"day": row["day"], **bucket})
    balance = float(_state.get("balance_pusd") or 0.)
    value = float(_state.get("value_usd") or 0.)
    return {"lane": lane, "asset": asset_name, "rows": rows[offset:offset + limit], "total_days": len(rows),
            "offset": offset, "limit": limit, "trading_timezone": "Asia/Shanghai",
            "capital_base_usd": float(cfg.paper_equity_usd) if lane == "paper" else max(balance + value, 1.)}

@app.get("/api/events")
def events(since_decision: int = Query(0), since_order: int = Query(0)):
    return {
        "decisions": recent_decisions(limit=200, since_id=since_decision),
        "orders": recent_orders(limit=50, since_id=since_order),
    }

