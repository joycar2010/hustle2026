"""mix-l1lite —— Asset360 按需一档盘口采集(全 WS,零 REST 轮询)。

约束背景:平台对 REST 高频调用封 IP(coin 真实发生过),行情一律走 WebSocket。
架构:按需订阅——mix-backend 在 Asset360 打开某币时写 want 键(TTL 900s),本服务每 5s
对账 want 集合,对六所现货+永续各持一条长连接动态增/退订该币的一档频道,
一档价量写 `dcm:l1lite:{venue}:{market}:{CANON}`(EX 120)。闲置 15 分钟自动退订。
加固(realtime-ws-idle-stall 教训全套):静默>90s 强制重连+指数退避 1..30s+逐所隔离。
qty 口径:base 数量(gate futures=张,消费端按 instrument_spec 乘数换算)。
"""
import asyncio
import json
import logging
import os
import time

import redis.asyncio as aioredis
import websockets

logging.basicConfig(level=logging.INFO, format="%(asctime)s l1lite %(levelname)s %(message)s")
log = logging.getLogger("l1lite")

WANT_PREFIX = "dcm:l1lite:want:"
OUT_TTL = 120
SCAN_SEC = 5
SILENT_RECONNECT = 90   # 无任何消息(含pong)超此秒数=半开假死,强制重连

def sym_of(venue, market, canon):
    if venue == "okx":
        return f"{canon}-USDT-SWAP" if market == "perp" else f"{canon}-USDT"
    if venue == "gate":
        return f"{canon}_USDT"
    if venue == "hyperliquid":
        return canon
    return f"{canon}USDT"


class VenueConn:
    """单 venue×market 一条长连接;desired 变化时增/退订。"""

    def __init__(self, venue, market, url, r):
        self.venue, self.market, self.url, self.r = venue, market, url, r
        self.desired: set = set()      # canonical 集合
        self.subscribed: set = set()
        self.dead: set = set()         # HL:订阅即闭连的币(不在该所上市),不再重订
        self.ws = None
        self.last_msg = 0.0
        self.backoff = 1

    # ── 各所订阅/退订/心跳/解析 ─────────────────────────────
    def _sub_msg(self, canons, sub=True):
        v, m = self.venue, self.market
        syms = [sym_of(v, m, c) for c in canons]
        if v == "binance":
            params = [s.lower() + "@bookTicker" for s in syms] + [s.lower() + "@ticker" for s in syms]
            return json.dumps({"method": "SUBSCRIBE" if sub else "UNSUBSCRIBE",
                               "params": params, "id": int(time.time() * 1000) % 10**9})
        if v == "okx":
            args = [{"channel": "tickers", "instId": s} for s in syms]
            if m == "perp":
                args += [{"channel": "open-interest", "instId": s} for s in syms]
            return json.dumps({"op": "subscribe" if sub else "unsubscribe", "args": args})
        if v == "bybit":
            args = [f"orderbook.1.{s}" for s in syms] + [f"tickers.{s}" for s in syms]
            return json.dumps({"op": "subscribe" if sub else "unsubscribe", "args": args})
        if v == "gate":
            ch = ("spot" if m == "spot" else "futures") + ".book_ticker"
            tch = ("spot" if m == "spot" else "futures") + ".tickers"
            msgs = [json.dumps({"time": int(time.time()), "channel": ch,
                                "event": "subscribe" if sub else "unsubscribe", "payload": syms}),
                    json.dumps({"time": int(time.time()), "channel": tch,
                                "event": "subscribe" if sub else "unsubscribe", "payload": syms})]
            return msgs
        if v == "bitget":
            it = "SPOT" if m == "spot" else "USDT-FUTURES"
            args = [{"instType": it, "channel": "books1", "instId": s} for s in syms]
            args += [{"instType": it, "channel": "ticker", "instId": s} for s in syms]
            return json.dumps({"op": "subscribe" if sub else "unsubscribe", "args": args})
        if v == "hyperliquid":
            # HL 一次一条
            msgs = [json.dumps({"method": "subscribe" if sub else "unsubscribe",
                                "subscription": {"type": "l2Book", "coin": s}}) for s in syms]
            msgs += [json.dumps({"method": "subscribe" if sub else "unsubscribe",
                                 "subscription": {"type": "activeAssetCtx", "coin": s}}) for s in syms]
            return msgs
        return None

    def _ping_msg(self):
        v = self.venue
        if v == "okx":
            return "ping"
        if v == "bybit":
            return json.dumps({"op": "ping"})
        if v == "gate":
            ch = ("spot" if self.market == "spot" else "futures") + ".ping"
            return json.dumps({"time": int(time.time()), "channel": ch})
        if v == "bitget":
            return "ping"
        return None    # binance/HL 由协议层 ping 或服务器自发

    def _canon_of(self, s):
        s = str(s or "").upper().replace("-USDT-SWAP", "").replace("-USDT", "") \
            .replace("_USDT", "").replace("USDT", "")
        return s

    def _parse(self, raw):
        """返回 [(canon, bid, bq, ask, aq)];解析失败返回 []。"""
        v = self.venue
        try:
            if raw in ("pong",):
                return []
            d = json.loads(raw)
        except Exception:  # noqa: BLE001
            return []
        out = []
        try:
            if v == "binance":
                if isinstance(d, dict) and d.get("e") == "24hrTicker" and d.get("q") is not None:
                    asyncio.ensure_future(self._publish_vol(self._canon_of(d.get("s")), d.get("q")))
                    return []
                if isinstance(d, dict) and d.get("s") and d.get("b") is not None and d.get("a") is not None:
                    out.append((self._canon_of(d["s"]), d["b"], d.get("B"), d["a"], d.get("A")))
            elif v == "okx":
                if (d.get("arg") or {}).get("channel") == "open-interest":
                    for row in (d.get("data") or []):
                        asyncio.ensure_future(
                            self._publish_oi(self._canon_of(row.get("instId")), row.get("oiCcy")))
                    return []
                for row in (d.get("data") or []):
                    inst = (d.get("arg") or {}).get("instId") or row.get("instId")
                    try:
                        vq = row.get("volCcy24h")
                        last = row.get("last") or row.get("bidPx")
                        if vq:
                            vol_usdt = float(vq) if self.market == "spot" else (float(vq) * float(last) if last else None)
                            if vol_usdt:
                                asyncio.ensure_future(self._publish_vol(self._canon_of(inst), vol_usdt))
                    except Exception:  # noqa: BLE001
                        pass
                    if row.get("bidPx") and row.get("askPx"):
                        out.append((self._canon_of(inst), row["bidPx"], row.get("bidSz"),
                                    row["askPx"], row.get("askSz")))
            elif v == "bybit":
                if str(d.get("topic", "")).startswith("tickers."):
                    _dd = d.get("data") or {}
                    _cn = self._canon_of(d["topic"].split(".")[-1])
                    if _dd.get("openInterest") is not None:
                        asyncio.ensure_future(self._publish_oi(_cn, _dd["openInterest"]))
                    if _dd.get("turnover24h") is not None:
                        asyncio.ensure_future(self._publish_vol(_cn, _dd["turnover24h"]))
                    return []
                if str(d.get("topic", "")).startswith("orderbook.1."):
                    sym = d["topic"].split(".")[-1]
                    data = d.get("data") or {}
                    b = (data.get("b") or [])
                    a = (data.get("a") or [])
                    bid = b[0] if b else None
                    ask = a[0] if a else None
                    if bid or ask:
                        out.append((self._canon_of(sym),
                                    bid[0] if bid else None, bid[1] if bid else None,
                                    ask[0] if ask else None, ask[1] if ask else None))
            elif v == "gate":
                if d.get("channel") == "futures.tickers":
                    rr = d.get("result")
                    for row in (rr if isinstance(rr, list) else [rr] if rr else []):
                        _cn = self._canon_of(row.get("contract"))
                        if row.get("total_size") is not None:
                            asyncio.ensure_future(self._publish_oi(_cn, row["total_size"]))
                        if row.get("volume_24h_settle") is not None:
                            asyncio.ensure_future(self._publish_vol(_cn, row["volume_24h_settle"]))
                    return []
                if d.get("channel") == "spot.tickers":
                    rr = d.get("result")
                    for row in (rr if isinstance(rr, list) else [rr] if rr else []):
                        if row.get("currency_pair") and row.get("quote_volume") is not None:
                            asyncio.ensure_future(self._publish_vol(
                                self._canon_of(row["currency_pair"]), row["quote_volume"]))
                    return []
                res = d.get("result") or {}
                if isinstance(res, dict) and res.get("s") and res.get("b") is not None:
                    out.append((self._canon_of(res["s"]), res["b"], res.get("B"),
                                res.get("a"), res.get("A")))
            elif v == "bitget":
                if (d.get("arg") or {}).get("channel") == "ticker":
                    _cn = self._canon_of((d.get("arg") or {}).get("instId"))
                    for row in (d.get("data") or []):
                        oi = row.get("holdingAmount") or row.get("openInterest")
                        if oi is not None:
                            asyncio.ensure_future(self._publish_oi(_cn, oi))
                        vq = row.get("usdtVolume") or row.get("quoteVolume")
                        if vq is not None:
                            asyncio.ensure_future(self._publish_vol(_cn, vq))
                    return []
                if (d.get("arg") or {}).get("channel") == "books1":
                    inst = d["arg"].get("instId")
                    for row in (d.get("data") or []):
                        bids, asks = row.get("bids") or [], row.get("asks") or []
                        bid = bids[0] if bids else None
                        ask = asks[0] if asks else None
                        if bid or ask:
                            out.append((self._canon_of(inst),
                                        bid[0] if bid else None, bid[1] if bid else None,
                                        ask[0] if ask else None, ask[1] if ask else None))
            elif v == "hyperliquid":
                if d.get("channel") == "activeAssetCtx":
                    data = d.get("data") or {}
                    ctx = data.get("ctx") or {}
                    _cn = self._canon_of(data.get("coin"))
                    if ctx.get("openInterest") is not None:
                        asyncio.ensure_future(self._publish_oi(_cn, ctx["openInterest"]))
                    if ctx.get("dayNtlVlm") is not None:
                        asyncio.ensure_future(self._publish_vol(_cn, ctx["dayNtlVlm"]))
                    return []
                if d.get("channel") == "l2Book":
                    data = d.get("data") or {}
                    lv = data.get("levels") or [[], []]
                    bid = lv[0][0] if lv[0] else None
                    ask = lv[1][0] if len(lv) > 1 and lv[1] else None
                    if bid or ask:
                        out.append((self._canon_of(data.get("coin")),
                                    bid and bid.get("px"), bid and bid.get("sz"),
                                    ask and ask.get("px"), ask and ask.get("sz")))
        except Exception as e:  # noqa: BLE001
            log.debug("%s parse err %s", v, e)
        return out

    MULT = {}   # "{venue}:{CANON}" -> float(reconcile loop 每5s刷,mix-backend每300s发布)

    async def _publish_oi(self, canon, oi_base):
        if not canon or oi_base is None:
            return
        try:
            mult = 1.0
            if self.venue == "gate":   # gate tickers total_size=张
                mult = float(VenueConn.MULT.get(f"gate:{canon}") or 1.0)
            await self.r.setex(f"dcm:l1lite:oi:{self.venue}:{canon}", 300,
                               json.dumps({"oi_base": float(oi_base) * mult, "ts": int(time.time())}))
        except Exception:  # noqa: BLE001
            pass

    async def _publish_vol(self, canon, vol_usdt):
        if not canon or vol_usdt is None:
            return
        try:
            await self.r.setex(f"dcm:l1lite:vol:{self.venue}:{self.market}:{canon}", 300,
                               json.dumps({"vol_usdt": float(vol_usdt), "ts": int(time.time())}))
        except Exception:  # noqa: BLE001
            pass

    async def _publish(self, rows):
        # 部分所(bybit delta)只更单边——读旧值合并,绝不用 None 覆盖
        for canon, bid, bq, ask, aq in rows:
            if not canon:
                continue
            key = f"dcm:l1lite:{self.venue}:{self.market}:{canon}"
            old = {}
            if bid is None or ask is None:
                try:
                    prev = await self.r.get(key)
                    if prev:
                        old = json.loads(prev)
                except Exception:  # noqa: BLE001
                    pass
            mult = 1.0
            if self.market == "perp" and self.venue in ("gate", "okx"):
                mult = float(VenueConn.MULT.get(f"{self.venue}:{canon}") or 1.0)
            payload = {"bid": float(bid) if bid is not None else old.get("bid"),
                       "bq": float(bq) * mult if bq is not None else old.get("bq"),
                       "ask": float(ask) if ask is not None else old.get("ask"),
                       "aq": float(aq) * mult if aq is not None else old.get("aq"),
                       "ts": int(time.time())}
            await self.r.setex(key, OUT_TTL, json.dumps(payload))

    async def _send_delta(self):
        add = self.desired - self.subscribed - self.dead
        rem = self.subscribed - self.desired
        for canons, sub in ((add, True), (rem, False)):
            if not canons or not self.ws:
                continue
            msg = self._sub_msg(canons, sub)
            if msg is None:
                continue
            for mm in (msg if isinstance(msg, list) else [msg]):
                await self.ws.send(mm)
        self.subscribed = set(self.desired)

    async def run(self):
        while True:
            if not self.desired:      # 无需求不建连(省连接)
                self.subscribed = set()
                await asyncio.sleep(SCAN_SEC)
                continue
            _got_data = False
            try:
                async with websockets.connect(self.url, ping_interval=20, ping_timeout=15,
                                              close_timeout=5, max_size=2**20) as ws:
                    self.ws = ws
                    self.subscribed = set()
                    self.last_msg = time.time()
                    log.info("%s/%s connected", self.venue, self.market)
                    while True:
                        await self._send_delta()
                        if not self.desired:
                            break     # 退订完就断开,回到省连接态
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=20)
                            self.last_msg = time.time()
                            if not _got_data:
                                _got_data = True
                                self.backoff = 1   # 收到真实数据才认为连接健康,重置退避
                            rows = self._parse(raw)
                            if rows:
                                await self._publish(rows)
                        except asyncio.TimeoutError:
                            pm = self._ping_msg()
                            if pm:
                                await ws.send(pm)
                            if time.time() - self.last_msg > SILENT_RECONNECT:
                                raise ConnectionError("silent>90s,半开假死重连")
            except Exception as e:  # noqa: BLE001
                # 连上即断(HL订到未上市币会闭连):backoff已只在收到数据后重置,
                # 无数据→退避1→2→..→30s,灭风暴(限频风险);数据缺失面板诚实显"—"
                log.warning("%s/%s reconnect: %s", self.venue, self.market, str(e)[:60])
                await asyncio.sleep(self.backoff)
                self.backoff = min(self.backoff * 2, 30)
            finally:
                self.ws = None


URLS = {
    ("binance", "spot"): "wss://stream.binance.com:9443/ws",
    ("binance", "perp"): "wss://fstream.binance.com/ws",
    ("okx", "spot"): "wss://ws.okx.com:8443/ws/v5/public",
    ("okx", "perp"): "wss://ws.okx.com:8443/ws/v5/public",
    ("bybit", "spot"): "wss://stream.bybit.com/v5/public/spot",
    ("bybit", "perp"): "wss://stream.bybit.com/v5/public/linear",
    ("gate", "spot"): "wss://api.gateio.ws/ws/v4/",
    ("gate", "perp"): "wss://fx-ws.gateio.ws/v4/ws/usdt",
    ("bitget", "spot"): "wss://ws.bitget.com/v2/ws/public",
    ("bitget", "perp"): "wss://ws.bitget.com/v2/ws/public",
    ("hyperliquid", "perp"): "wss://api.hyperliquid.xyz/ws",
}


async def main():
    r = aioredis.from_url(os.environ.get("MIX_REDIS_URL") or os.environ["REDIS_URL"], decode_responses=True)
    conns = {vm: VenueConn(vm[0], vm[1], url, r) for vm, url in URLS.items()}
    tasks = [asyncio.create_task(c.run()) for c in conns.values()]

    async def reconcile():
        while True:
            try:
                want = set()
                async for k in r.scan_iter(match=WANT_PREFIX + "*", count=200):
                    want.add(k[len(WANT_PREFIX):])
                for c in conns.values():
                    c.desired = set(want)
                try:
                    VenueConn.MULT = await r.hgetall("dcm:l1lite:mult") or {}
                except Exception:  # noqa: BLE001
                    pass
                await r.setex("dcm:hb:l1lite", 60,
                              json.dumps({"ts": int(time.time()), "want": sorted(want),
                                          "conns": sum(1 for c in conns.values() if c.ws)}))
            except Exception as e:  # noqa: BLE001
                log.warning("reconcile: %s", e)
            await asyncio.sleep(SCAN_SEC)

    tasks.append(asyncio.create_task(reconcile()))
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
