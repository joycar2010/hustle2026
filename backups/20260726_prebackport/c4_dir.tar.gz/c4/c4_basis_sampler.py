"""C4 期现交割 measure 轨 —— 交割合约年化基差采样器 v2(只读公开数据,零真钱)。

v2 新增成本线(净年化,决策级):
  - 费率:双边现货 taker×2 + 交割合约 taker + 交割结算费。默认表=保守猜测,**逐行标注
    fee_src=default_conservative 绝不静默充真**(testgo V1.1 FeeResolver 教训);可经
    Redis dcm:c4:costcfg JSON 覆写({venue:{spot_taker_bps,fut_taker_bps,settle_bps},
    margin_ratio, min_days, min_net_ann_capital_pct}),覆写后 fee_src=override。
  - 资金占用:现货全额 + 合约保证金 margin_ratio(默认0.2)→ 占用=1+margin_ratio,
    net_ann_capital = net_ann / (1+margin_ratio)(净年化摊到实际占用资本)。
  - 交割合约无资金费(到期硬锚,C4 的经济学立足点)。
  - shadow 候选:net_ann_capital≥阈值 且 剩余天数≥min_days(近月基差会被费吃死)→
    dcm:c4:candidates(ex=3600,仅展示,无任何消费者,不碰 armed 管道)。

每轮:instrument_spec 未到期交割(<MAX_DAYS 滤 2031 五年期异类)→ 各所一次 bulk ticker
(单所失败隔离)→ 现货腿同所 dcm:feed:{v}:spot 优先(>180s 龄弃)回退 binance 现货 REST
(spot_src 如实记)→ 毛/净基差 → PG c4_basis_sample 时序 + Redis dcm:c4:basis:latest
(ex=3600,采样器死=快照自过期=诚实 stale)。
"""
import os
import json
import asyncio
import datetime as dt

import httpx
import asyncpg
import redis.asyncio as aioredis

DSN = os.environ["MIX_MAIN_DSN"]
REDIS_URL = os.environ.get("REDIS_URL", "redis://10.0.1.95:6379/0")
MAX_DAYS = 400          # 滤掉 THIS_FIVE_YEARS(2031)一类非基差标的
SPOT_STALE_SEC = 180    # feed 现货超过此龄视为缺失,回退 binance
SNAP_KEY = "dcm:c4:basis:latest"
CAND_KEY = "dcm:c4:candidates"
COSTCFG_KEY = "dcm:c4:costcfg"
C5_SNAP_KEY = "dcm:c5:basis:latest"
C5_CAND_KEY = "dcm:c5:candidates"
C6_SNAP_KEY = "dcm:c6:spread:latest"
C6_CAND_KEY = "dcm:c6:candidates"
PERP_STALE_SEC = 180
FUNDING_STALE_SEC = 3600  # funding 8h 一结,okx feed 更新慢于 900s 曾致显示"—"

# 保守默认费率(bps)。真实 VIP 档在 B 机账户侧,measure 轨无 key ⇒ 只能保守猜,
# 但绝不静默:fee_src 全程带出;上线执行相位前须用真实费率覆写。
FEE_DEFAULTS = {
    "_default": {"spot_taker_bps": 10.0, "fut_taker_bps": 6.0, "settle_bps": 5.0, "perp_taker_bps": 6.0},
    "gate": {"spot_taker_bps": 20.0, "fut_taker_bps": 6.0, "settle_bps": 5.0, "perp_taker_bps": 6.0},
}
COST_DEFAULTS = {"margin_ratio": 0.2, "min_days": 14.0, "min_net_ann_capital_pct": 3.0,
                 # C5/C6 双腿全保证金:占用=2/LEV(LEV=2→1.0);资本效率是 C5 相对 C4 的核心奖赏
                 "c5_occupancy": 1.0, "c6_occupancy": 1.0}

_DDL = """
CREATE TABLE IF NOT EXISTS c4_basis_sample(
  id BIGSERIAL PRIMARY KEY,
  ts timestamptz NOT NULL DEFAULT now(),
  venue text NOT NULL, instrument_id text NOT NULL, underlying text NOT NULL,
  contract_type text, linear_or_inverse text,
  expiry timestamptz NOT NULL, days_to_exp numeric NOT NULL,
  fut_price numeric NOT NULL, spot_price numeric NOT NULL, spot_src text,
  basis_bps numeric NOT NULL, ann_pct numeric NOT NULL);
CREATE INDEX IF NOT EXISTS idx_c4bs_ul_ts ON c4_basis_sample(underlying, ts DESC);
CREATE INDEX IF NOT EXISTS idx_c4bs_ts ON c4_basis_sample(ts);
ALTER TABLE c4_basis_sample ADD COLUMN IF NOT EXISTS fees_bps numeric;
ALTER TABLE c4_basis_sample ADD COLUMN IF NOT EXISTS net_basis_bps numeric;
ALTER TABLE c4_basis_sample ADD COLUMN IF NOT EXISTS net_ann_pct numeric;
ALTER TABLE c4_basis_sample ADD COLUMN IF NOT EXISTS net_ann_capital_pct numeric;
ALTER TABLE c4_basis_sample ADD COLUMN IF NOT EXISTS fee_src text;
CREATE TABLE IF NOT EXISTS c5_basis_sample(
  id BIGSERIAL PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(),
  venue text NOT NULL, instrument_id text NOT NULL, underlying text NOT NULL,
  expiry timestamptz NOT NULL, days_to_exp numeric NOT NULL,
  fut_price numeric NOT NULL, perp_price numeric NOT NULL,
  basis_bps numeric NOT NULL, capture_ann_pct numeric NOT NULL, direction text,
  funding_daily_pct numeric, funding_ann_pct numeric,
  fees_bps numeric, net_ann_pct numeric, net_ann_capital_pct numeric,
  net_ann_capital_ex_funding_pct numeric, fee_src text);
CREATE INDEX IF NOT EXISTS idx_c5bs_ts ON c5_basis_sample(ts);
CREATE INDEX IF NOT EXISTS idx_c5bs_ul_ts ON c5_basis_sample(underlying, ts DESC);
CREATE TABLE IF NOT EXISTS c6_spread_sample(
  id BIGSERIAL PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(),
  underlying text NOT NULL, expiry timestamptz NOT NULL, days_to_exp numeric NOT NULL,
  cls text, venue_rich text, instrument_rich text, price_rich numeric,
  venue_cheap text, instrument_cheap text, price_cheap numeric,
  spread_bps numeric NOT NULL, gross_ann_pct numeric, fees_bps numeric,
  net_ann_pct numeric, net_ann_capital_pct numeric, fee_src text);
CREATE INDEX IF NOT EXISTS idx_c6sp_ts ON c6_spread_sample(ts);
"""


async def _get(cli, url):
    r = await cli.get(url, timeout=8)
    r.raise_for_status()
    return r.json()


def _mid(bid, ask):
    try:
        b, a = float(bid), float(ask)
        if b > 0 and a > 0:
            return (b + a) / 2
    except (TypeError, ValueError):
        pass
    return None


async def load_costcfg(r) -> tuple[dict, dict, dict, set]:
    """(fees_by_venue, cost_params, provenance, overridden_venues)。Redis 覆写合并在默认之上。"""
    fees = {k: dict(v) for k, v in FEE_DEFAULTS.items()}
    params = dict(COST_DEFAULTS)
    src = {"fees": "default_conservative", "params": "default"}
    overridden: set = set()
    try:
        raw = await r.get(COSTCFG_KEY)
        if raw:
            cfg = json.loads(raw)
            for v, d in cfg.items():
                if v in ("margin_ratio", "min_days", "min_net_ann_capital_pct"):
                    params[v] = float(d); src["params"] = "override"
                elif isinstance(d, dict):
                    base = dict(fees.get(v) or fees["_default"])
                    base.update({k: float(x) for k, x in d.items()})
                    fees[v] = base
                    overridden.add(v)
                    src["fees"] = "override"
    except Exception:  # noqa: BLE001  覆写坏了退默认,不炸采样
        pass
    return fees, params, src, overridden


def venue_fees(fees: dict, venue: str, overridden: set) -> tuple[float, str]:
    f = fees.get(venue) or fees["_default"]
    total = f["spot_taker_bps"] * 2 + f["fut_taker_bps"] + f["settle_bps"]
    tag = "override" if (venue in overridden or "_default" in overridden) else "default_conservative"
    return total, tag


def _vf(fees: dict, venue: str) -> dict:
    f = dict(fees["_default"])
    f.update(fees.get(venue) or {})
    return f


def fees_c5(fees: dict, venue: str, overridden: set) -> tuple[float, str]:
    """C5 同所 perp+交割:perp 开平双边 + 交割开 + 结算。"""
    f = _vf(fees, venue)
    total = f.get("perp_taker_bps", f["fut_taker_bps"]) * 2 + f["fut_taker_bps"] + f["settle_bps"]
    tag = "override" if (venue in overridden or "_default" in overridden) else "default_conservative"
    return total, tag


def fees_c6(fees: dict, va: str, vb: str, overridden: set) -> tuple[float, str]:
    """C6 跨所交割对:两腿开仓 taker + 两侧结算费(持有到期无平仓腿)。"""
    fa, fb = _vf(fees, va), _vf(fees, vb)
    total = fa["fut_taker_bps"] + fa["settle_bps"] + fb["fut_taker_bps"] + fb["settle_bps"]
    tag = "override" if ({va, vb} & overridden or "_default" in overridden) else "default_conservative"
    return total, tag


async def load_hash_feed(r, key_tmpl: str, venues, underlyings, stale_sec: float) -> dict:
    """{(venue, ul): mid} — 读 dcm:feed:{v}:perp 一类 hash(JSON bid/ask+ts ms),过龄弃。"""
    out = {}
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    for v in venues:
        try:
            h = await r.hgetall(key_tmpl.format(v=v))
        except Exception:  # noqa: BLE001
            h = {}
        for ul in underlyings:
            raw = h.get(f"{ul}USDT".encode()) or h.get(f"{ul}USDT")
            if not raw:
                continue
            try:
                j = json.loads(raw)
                ts = j.get("ts")
                if ts is not None:
                    ts = float(ts)
                    if ts > 1e12:
                        ts /= 1000.0
                    if now - ts > stale_sec:
                        continue
                m = _mid(j.get("bid"), j.get("ask"))
                if m:
                    out[(v, ul)] = m
            except (ValueError, TypeError):
                continue
    return out


async def load_funding(r, venues, underlyings) -> dict:
    """{(venue, ul): funding_daily_pct} — dcm:feed:funding:{v} 带预算好的 daily_pct;过龄弃。"""
    out = {}
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    for v in venues:
        try:
            h = await r.hgetall(f"dcm:feed:funding:{v}")
        except Exception:  # noqa: BLE001
            h = {}
        for ul in underlyings:
            raw = h.get(f"{ul}USDT".encode()) or h.get(f"{ul}USDT")
            if not raw:
                continue
            try:
                j = json.loads(raw)
                ts = float(j.get("ts") or 0)
                if ts > 1e12:
                    ts /= 1000.0
                if ts and now - ts > FUNDING_STALE_SEC:
                    continue
                if j.get("daily_pct") is not None:
                    out[(v, ul)] = float(j["daily_pct"])
            except (ValueError, TypeError):
                continue
    return out


async def fetch_future_prices(cli) -> tuple[dict, dict]:
    """{(venue, instrument_id): price},各所一次 bulk 调用,失败隔离。返回 (prices, errs)。"""
    px, errs = {}, {}
    async def binance():
        for base, tag in (("https://dapi.binance.com/dapi/v1/ticker/price", "dapi"),
                          ("https://fapi.binance.com/fapi/v1/ticker/price", "fapi")):
            try:
                for t in await _get(cli, base):
                    px[("binance", t["symbol"])] = float(t["price"])
            except Exception as e:  # noqa: BLE001
                errs[f"binance-{tag}"] = repr(e)[:80]
    async def okx():
        try:
            d = await _get(cli, "https://www.okx.com/api/v5/market/tickers?instType=FUTURES")
            for t in d.get("data", []):
                p = _mid(t.get("bidPx"), t.get("askPx")) or (float(t["last"]) if t.get("last") else None)
                if p:
                    px[("okx", t["instId"])] = p
        except Exception as e:  # noqa: BLE001
            errs["okx"] = repr(e)[:80]
    async def bybit():
        for cat in ("linear", "inverse"):
            try:
                d = await _get(cli, f"https://api.bybit.com/v5/market/tickers?category={cat}")
                for t in d.get("result", {}).get("list", []):
                    p = t.get("markPrice") or t.get("lastPrice")
                    if p and float(p) > 0:
                        px[("bybit", t["symbol"])] = float(p)
            except Exception as e:  # noqa: BLE001
                errs[f"bybit-{cat}"] = repr(e)[:80]
    async def gate():
        try:
            for t in await _get(cli, "https://api.gateio.ws/api/v4/delivery/usdt/tickers"):
                p = t.get("mark_price") or t.get("last")
                if t.get("contract") and p and float(p) > 0:
                    px[("gate", t["contract"])] = float(p)
        except Exception as e:  # noqa: BLE001
            errs["gate"] = repr(e)[:80]
    async def bitget():
        try:
            d = await _get(cli, "https://api.bitget.com/api/v2/mix/market/tickers?productType=COIN-FUTURES")
            for t in d.get("data", []):
                p = _mid(t.get("bidPr"), t.get("askPr")) or (float(t["lastPr"]) if t.get("lastPr") else None)
                if p:
                    px[("bitget", t["symbol"])] = p
        except Exception as e:  # noqa: BLE001
            errs["bitget"] = repr(e)[:80]
    await asyncio.gather(binance(), okx(), bybit(), gate(), bitget())
    return px, errs


async def load_spot(r, cli, venues, underlyings) -> dict:
    """{(venue, underlying): (mid, src)};同所 feed 优先,回退 binance 现货 bulk REST。"""
    out = {}
    now = dt.datetime.now(dt.timezone.utc).timestamp()
    for v in venues:
        try:
            h = await r.hgetall(f"dcm:feed:{v}:spot")
        except Exception:  # noqa: BLE001
            h = {}
        for ul in underlyings:
            raw = h.get(f"{ul}USDT".encode()) or h.get(f"{ul}USDT")
            if not raw:
                continue
            try:
                j = json.loads(raw)
                ts = j.get("ts") or j.get("timestamp") or j.get("time")
                if ts is not None:
                    ts = float(ts)
                    if ts > 1e12:
                        ts /= 1000.0
                    if now - ts > SPOT_STALE_SEC:
                        continue
                m = _mid(j.get("bid"), j.get("ask"))
                if m:
                    out[(v, ul)] = (m, f"feed:{v}")
            except (ValueError, TypeError):
                continue
    try:
        bmap = {t["symbol"]: float(t["price"]) for t in await _get(cli, "https://api.binance.com/api/v3/ticker/price")}
    except Exception:  # noqa: BLE001
        bmap = {}
    for v in venues:
        for ul in underlyings:
            if (v, ul) not in out and f"{ul}USDT" in bmap:
                out[(v, ul)] = (bmap[f"{ul}USDT"], "fallback:binance")
    return out


async def main():
    pg = await asyncpg.connect(DSN)
    await pg.execute(_DDL)
    specs = await pg.fetch(
        "SELECT venue,instrument_id,canonical_underlying ul,contract_type,linear_or_inverse,"
        "settlement_asset,expiry "
        "FROM instrument_spec WHERE market_type='future' AND expiry > now() "
        "AND expiry < now() + ($1||' days')::interval ORDER BY canonical_underlying, expiry", str(MAX_DAYS))
    venues = sorted({s["venue"] for s in specs})
    underlyings = sorted({s["ul"] for s in specs})
    r = aioredis.from_url(REDIS_URL)
    fees_cfg, params, cost_src, overridden = await load_costcfg(r)
    async with httpx.AsyncClient(timeout=10) as cli:
        px, errs = await fetch_future_prices(cli)
        spot = await load_spot(r, cli, venues, underlyings)

    now = dt.datetime.now(dt.timezone.utc)
    occ = 1.0 + params["margin_ratio"]
    rows, miss_px, miss_spot = [], 0, 0
    for s in specs:
        f = px.get((s["venue"], s["instrument_id"]))
        if f is None:
            miss_px += 1
            continue
        sp = spot.get((s["venue"], s["ul"]))
        if sp is None:
            miss_spot += 1
            continue
        spx, ssrc = sp
        days = max((s["expiry"] - now).total_seconds() / 86400.0, 0.01)
        basis = (f - spx) / spx
        basis_bps = basis * 1e4
        fee_bps, fee_src = venue_fees(fees_cfg, s["venue"], overridden)
        net_bps = basis_bps - fee_bps
        net_ann = net_bps * 365.0 / days / 100.0          # bps → pct 年化
        rows.append((s["venue"], s["instrument_id"], s["ul"], s["contract_type"],
                     s["linear_or_inverse"], s["expiry"], round(days, 4), f, spx, ssrc,
                     round(basis_bps, 4), round(basis * 365.0 / days * 100.0, 6),
                     round(fee_bps, 2), round(net_bps, 4), round(net_ann, 6),
                     round(net_ann / occ, 6), fee_src))

    if rows:
        await pg.executemany(
            "INSERT INTO c4_basis_sample(venue,instrument_id,underlying,contract_type,"
            "linear_or_inverse,expiry,days_to_exp,fut_price,spot_price,spot_src,basis_bps,ann_pct,"
            "fees_bps,net_basis_bps,net_ann_pct,net_ann_capital_pct,fee_src) "
            "VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)", rows)

    def _row(x):
        return {"venue": x[0], "instrument_id": x[1], "underlying": x[2],
                "contract_type": x[3], "linear_or_inverse": x[4], "expiry": x[5].isoformat(),
                "days": x[6], "fut": x[7], "spot": round(x[8], 8), "spot_src": x[9],
                "basis_bps": x[10], "ann_pct": x[11], "fees_bps": x[12],
                "net_basis_bps": x[13], "net_ann_pct": x[14],
                "net_ann_capital_pct": x[15], "fee_src": x[16]}

    board = sorted(rows, key=lambda z: -z[15])
    cands = [x for x in board
             if x[15] >= params["min_net_ann_capital_pct"] and x[6] >= params["min_days"]]
    snap = {"ts": now.isoformat(), "n": len(rows),
            "miss_px": miss_px, "miss_spot": miss_spot, "venue_errs": errs,
            "cost_model": {"fees": fees_cfg, "margin_ratio": params["margin_ratio"],
                           "occupancy": occ, "src": cost_src,
                           "note": "费率为保守默认,执行相位前须以真实VIP档覆写 dcm:c4:costcfg"},
            "candidates_n": len(cands),
            "candidate_params": {"min_net_ann_capital_pct": params["min_net_ann_capital_pct"],
                                 "min_days": params["min_days"]},
            "rows": [_row(x) for x in board]}
    await r.set(SNAP_KEY, json.dumps(snap, ensure_ascii=False), ex=3600)
    await r.set(CAND_KEY, json.dumps({
        "ts": now.isoformat(), "mode": "SHADOW", "params": snap["candidate_params"],
        "note": "仅展示;无消费者;不碰armed管道;执行相位须盯盘放行",
        "rows": [_row(x) for x in cands]}, ensure_ascii=False), ex=3600)

    # ===== C5 永续-交割(同所):基差硬锚 + 浮动资金费腿;双腿保证金→占用≈2/LEV =====
    perp = await load_hash_feed(r, "dcm:feed:{v}:perp", venues, underlyings, PERP_STALE_SEC)
    fund = await load_funding(r, venues, underlyings)
    c5_rows = []
    for s in specs:
        f = px.get((s["venue"], s["instrument_id"]))
        p = perp.get((s["venue"], s["ul"]))
        if f is None or p is None:
            continue
        days = max((s["expiry"] - now).total_seconds() / 86400.0, 0.01)
        basis_bps = (f - p) / p * 1e4
        direction = "LONG_PERP_SHORT_FUT" if basis_bps >= 0 else "SHORT_PERP_LONG_FUT"
        capture_ann = abs(basis_bps) * 365.0 / days / 100.0
        fd = fund.get((s["venue"], s["ul"]))
        # 多 perp 腿: funding>0 付费(carry 负);空 perp 腿: funding>0 收费
        f_daily = None if fd is None else (-fd if basis_bps >= 0 else fd)
        f_ann = None if f_daily is None else f_daily * 365.0
        fee_bps, fee_src = fees_c5(fees_cfg, s["venue"], overridden)
        net_ann_exf = capture_ann - fee_bps * 365.0 / days / 100.0
        net_ann = net_ann_exf + (f_ann or 0.0)
        occ5 = params["c5_occupancy"]
        c5_rows.append({"venue": s["venue"], "instrument_id": s["instrument_id"],
                        "underlying": s["ul"], "expiry": s["expiry"], "days": round(days, 4),
                        "fut": f, "perp": round(p, 10), "basis_bps": round(basis_bps, 4),
                        "capture_ann_pct": round(capture_ann, 6), "direction": direction,
                        "funding_daily_pct": fd,
                        "funding_ann_pct": None if f_ann is None else round(f_ann, 4),
                        "fees_bps": round(fee_bps, 2), "net_ann_pct": round(net_ann, 6),
                        "net_ann_capital_pct": round(net_ann / occ5, 6),
                        "net_ann_capital_ex_funding_pct": round(net_ann_exf / occ5, 6),
                        "fee_src": fee_src})
    if c5_rows:
        await pg.executemany(
            "INSERT INTO c5_basis_sample(venue,instrument_id,underlying,expiry,days_to_exp,"
            "fut_price,perp_price,basis_bps,capture_ann_pct,direction,funding_daily_pct,"
            "funding_ann_pct,fees_bps,net_ann_pct,net_ann_capital_pct,"
            "net_ann_capital_ex_funding_pct,fee_src) "
            "VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)",
            [(x["venue"], x["instrument_id"], x["underlying"], x["expiry"], x["days"],
              x["fut"], x["perp"], x["basis_bps"], x["capture_ann_pct"], x["direction"],
              x["funding_daily_pct"], x["funding_ann_pct"], x["fees_bps"], x["net_ann_pct"],
              x["net_ann_capital_pct"], x["net_ann_capital_ex_funding_pct"], x["fee_src"])
             for x in c5_rows])
    c5_board = sorted(c5_rows, key=lambda z: -z["net_ann_capital_ex_funding_pct"])
    c5_cands = [x for x in c5_board
                if x["net_ann_capital_ex_funding_pct"] >= params["min_net_ann_capital_pct"]
                and x["days"] >= params["min_days"]]

    def _c5row(x):
        d = dict(x)
        d["expiry"] = x["expiry"].isoformat()
        return d
    await r.set(C5_SNAP_KEY, json.dumps({
        "ts": now.isoformat(), "n": len(c5_rows), "candidates_n": len(c5_cands),
        "occupancy": params["c5_occupancy"],
        "note": "funding=当前瞬时日化×365 仅指示(浮动腿);候选闸=不含funding的硬边际(基差锚)",
        "rows": [_c5row(x) for x in c5_board]}, ensure_ascii=False), ex=3600)
    await r.set(C5_CAND_KEY, json.dumps({
        "ts": now.isoformat(), "mode": "SHADOW",
        "params": {"min_net_ann_capital_ex_funding_pct": params["min_net_ann_capital_pct"],
                   "min_days": params["min_days"]},
        "note": "仅展示;无消费者;执行相位未建,armed 须盯盘放行",
        "rows": [_c5row(x) for x in c5_cands]}, ensure_ascii=False), ex=3600)

    # ===== C6 跨所同到期交割配对:纯收敛,无资金费;结算指数差风险未建模(如实) =====
    groups: dict = {}
    for s in specs:
        f = px.get((s["venue"], s["instrument_id"]))
        if f is None:
            continue
        key = (s["ul"], s["expiry"].date(), f"{s['linear_or_inverse']}/{s['settlement_asset']}")
        groups.setdefault(key, []).append((s, f))
    c6_rows = []
    for (ul6, expd, cls6), legs in groups.items():
        if len(legs) < 2:
            continue
        for i in range(len(legs)):
            for j in range(i + 1, len(legs)):
                (sa, fa), (sb, fb) = legs[i], legs[j]
                if sa["venue"] == sb["venue"]:
                    continue
                (sr, fr_), (sc, fc_) = ((sa, fa), (sb, fb)) if fa >= fb else ((sb, fb), (sa, fa))
                days = max((sr["expiry"] - now).total_seconds() / 86400.0, 0.01)
                spread_bps = (fr_ - fc_) / fc_ * 1e4
                fee_bps, fee_src = fees_c6(fees_cfg, sr["venue"], sc["venue"], overridden)
                occ6 = params["c6_occupancy"]
                c6_rows.append({"underlying": ul6, "expiry": sr["expiry"], "days": round(days, 4),
                                "cls": cls6, "venue_rich": sr["venue"],
                                "instrument_rich": sr["instrument_id"], "price_rich": fr_,
                                "venue_cheap": sc["venue"],
                                "instrument_cheap": sc["instrument_id"], "price_cheap": fc_,
                                "spread_bps": round(spread_bps, 4),
                                "gross_ann_pct": round(spread_bps * 365.0 / days / 100.0, 6),
                                "fees_bps": round(fee_bps, 2),
                                "net_ann_pct": round((spread_bps - fee_bps) * 365.0 / days / 100.0, 6),
                                "net_ann_capital_pct": round((spread_bps - fee_bps) * 365.0 / days / 100.0 / occ6, 6),
                                "fee_src": fee_src})
    if c6_rows:
        await pg.executemany(
            "INSERT INTO c6_spread_sample(underlying,expiry,days_to_exp,cls,venue_rich,"
            "instrument_rich,price_rich,venue_cheap,instrument_cheap,price_cheap,spread_bps,"
            "gross_ann_pct,fees_bps,net_ann_pct,net_ann_capital_pct,fee_src) "
            "VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)",
            [(x["underlying"], x["expiry"], x["days"], x["cls"], x["venue_rich"],
              x["instrument_rich"], x["price_rich"], x["venue_cheap"], x["instrument_cheap"],
              x["price_cheap"], x["spread_bps"], x["gross_ann_pct"], x["fees_bps"],
              x["net_ann_pct"], x["net_ann_capital_pct"], x["fee_src"]) for x in c6_rows])
    c6_board = sorted(c6_rows, key=lambda z: -z["net_ann_capital_pct"])
    c6_cands = [x for x in c6_board
                if x["net_ann_capital_pct"] >= params["min_net_ann_capital_pct"]
                and x["days"] >= params["min_days"]]

    def _c6row(x):
        d = dict(x)
        d["expiry"] = x["expiry"].isoformat()
        return d
    await r.set(C6_SNAP_KEY, json.dumps({
        "ts": now.isoformat(), "n": len(c6_rows), "candidates_n": len(c6_cands),
        "occupancy": params["c6_occupancy"],
        "note": "同到期+同margin类型+同结算资产才配对(严格);结算指数差/交割时刻差风险未建模",
        "rows": [_c6row(x) for x in c6_board]}, ensure_ascii=False), ex=3600)
    await r.set(C6_CAND_KEY, json.dumps({
        "ts": now.isoformat(), "mode": "SHADOW",
        "params": {"min_net_ann_capital_pct": params["min_net_ann_capital_pct"],
                   "min_days": params["min_days"]},
        "note": "仅展示;无消费者;执行相位未建,armed 须盯盘放行",
        "rows": [_c6row(x) for x in c6_cands]}, ensure_ascii=False), ex=3600)

    await r.aclose()
    await pg.close()

    print(f"c4_basis n={len(rows)} miss_px={miss_px} miss_spot={miss_spot} "
          f"cands={len(cands)} fee_src={cost_src['fees']} errs={errs}")
    for x in board[:10]:
        print(f"  高 {x[2]:6s} {x[0]:8s} {x[1]:22s} 剩{x[6]:6.1f}d 毛={x[11]:+7.3f}% "
              f"费={x[12]:4.0f}bps 净={x[14]:+7.3f}% 净/占用={x[15]:+7.3f}%")
    for x in board[-3:]:
        print(f"  低 {x[2]:6s} {x[0]:8s} {x[1]:22s} 剩{x[6]:6.1f}d 毛={x[11]:+7.3f}% "
              f"费={x[12]:4.0f}bps 净={x[14]:+7.3f}% 净/占用={x[15]:+7.3f}%")
    print(f"c5_basis n={len(c5_rows)} cands={len(c5_cands)}(闸=不含funding硬边际≥{params['min_net_ann_capital_pct']}%)")
    for x in c5_board[:8]:
        print(f"  C5 {x['underlying']:6s} {x['venue']:8s} {x['instrument_id']:22s} 剩{x['days']:6.1f}d "
              f"基差={x['basis_bps']:+7.1f}bps {x['direction']:20s} "
              f"硬净/占用={x['net_ann_capital_ex_funding_pct']:+7.3f}% funding年化={x['funding_ann_pct'] if x['funding_ann_pct'] is not None else '—'}")
    print(f"c6_spread n={len(c6_rows)} cands={len(c6_cands)}")
    for x in c6_board[:8]:
        print(f"  C6 {x['underlying']:6s} {x['cls']:14s} 剩{x['days']:6.1f}d "
              f"{x['venue_rich']}({x['instrument_rich']}) vs {x['venue_cheap']}({x['instrument_cheap']}) "
              f"差={x['spread_bps']:+7.1f}bps 费={x['fees_bps']:.0f} 净/占用={x['net_ann_capital_pct']:+7.3f}%")


if __name__ == "__main__":
    asyncio.run(main())
