"""C2.C 收敛信号引擎 + C3.R 榜单持久化(研究面 SHADOW,零执行,10min timer)。

C2.C:基于 risk_guard.spread_sampler(risk_spread_sample,300s/币)的 gap_pct(跨所费差缺口 %/日),
逐币算 7 日分位与 z-score。收敛论文=当前缺口处于自身历史高分位(宽)→未来向均值收敛。
候选闸:样本≥100 且 分位≥0.90 且 缺口≥0.5%/日。仅 SHADOW(HOUSE_RND),无任何执行消费者。

C3.R:lending-advisor(B机,60s)发布 dcm:lending:ranking(三率净差 日化%=|funding|+earn−borrow,
单位已核实全日化);此处持久化 top20 时序供研究/回看,引擎侧不动。
"""
import os
import json
import asyncio
import datetime as dt

import asyncpg
import redis.asyncio as aioredis

DSN = os.environ["MIX_MAIN_DSN"]
REDIS_URL = os.environ.get("REDIS_URL", "redis://10.0.1.95:6379/0")
C2C_MIN_N = int(os.environ.get("DCM_C2C_MIN_N", "100"))
C2C_MIN_PCTILE = float(os.environ.get("DCM_C2C_MIN_PCTILE", "0.90"))
C2C_MIN_GAP = float(os.environ.get("DCM_C2C_MIN_GAP_PCT", "0.5"))
# 决策层(v2):自动落 DRY_RUN 提案的更严闸(提案≠执行:审批后才走 fastlane,不自动armed)
C2C_PROP_PCTILE = float(os.environ.get("DCM_C2C_PROP_PCTILE", "0.95"))
C2C_PROP_EDGE = float(os.environ.get("DCM_C2C_PROP_EDGE_PCT", "1.0"))     # 两腿funding差 %/日
C2C_PROP_BE_DAYS = float(os.environ.get("DCM_C2C_PROP_BE_DAYS", "2.0"))  # 回本天数上限
C2C_PROP_NOTIONAL = float(os.environ.get("DCM_C2C_PROP_NOTIONAL", "50"))
C3R_MIN_NET = float(os.environ.get("DCM_C3R_MIN_NET_PCT", "1.0"))        # 净差 %/日
VENUES = ("binance", "bybit", "okx", "gate", "bitget")

_DDL = """
CREATE TABLE IF NOT EXISTS c2c_signal_sample(
  id BIGSERIAL PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(),
  symbol text NOT NULL, gap_now_pct float8, pctile float8, zscore float8,
  n int, hist_mean float8, hist_std float8);
CREATE INDEX IF NOT EXISTS idx_c2c_ts ON c2c_signal_sample(ts);
CREATE TABLE IF NOT EXISTS c3r_ranking_sample(
  id BIGSERIAL PRIMARY KEY, ts timestamptz NOT NULL DEFAULT now(),
  coin text NOT NULL, net_daily_pct float8, funding_abs float8,
  earn float8, borrow float8, rank int);
CREATE INDEX IF NOT EXISTS idx_c3r_ts ON c3r_ranking_sample(ts);
"""

Q_C2C = """
WITH cur AS (
  SELECT DISTINCT ON (symbol) symbol, ts, gap_pct
  FROM risk_spread_sample WHERE ts > now() - interval '30 minutes'
  ORDER BY symbol, ts DESC),
hist AS (
  SELECT symbol, count(*) n, avg(gap_pct) mean, stddev_samp(gap_pct) sd
  FROM risk_spread_sample WHERE ts > now() - interval '7 days' GROUP BY symbol)
SELECT c.symbol, c.gap_pct AS gap_now, h.n, h.mean, h.sd,
  (SELECT count(*) FROM risk_spread_sample x
    WHERE x.symbol = c.symbol AND x.ts > now() - interval '7 days'
      AND x.gap_pct <= c.gap_pct)::float8 / NULLIF(h.n, 0) AS pctile
FROM cur c JOIN hist h ON h.symbol = c.symbol
"""


async def main():
    pg = await asyncpg.connect(DSN)
    await pg.execute(_DDL)
    r = aioredis.from_url(REDIS_URL)
    now = dt.datetime.now(dt.timezone.utc)

    # ---- C2.C ----
    rows = await pg.fetch(Q_C2C)
    c2c = []
    for x in rows:
        sd = float(x["sd"] or 0)
        z = (float(x["gap_now"]) - float(x["mean"] or 0)) / sd if sd > 1e-9 else None
        c2c.append({"symbol": x["symbol"], "gap_now_pct": round(float(x["gap_now"]), 5),
                    "pctile": round(float(x["pctile"] or 0), 4),
                    "zscore": round(z, 3) if z is not None else None,
                    "n": int(x["n"]), "hist_mean": round(float(x["mean"] or 0), 5),
                    "hist_std": round(sd, 5)})
    if c2c:
        await pg.executemany(
            "INSERT INTO c2c_signal_sample(symbol,gap_now_pct,pctile,zscore,n,hist_mean,hist_std) "
            "VALUES($1,$2,$3,$4,$5,$6,$7)",
            [(x["symbol"], x["gap_now_pct"], x["pctile"], x["zscore"], x["n"],
              x["hist_mean"], x["hist_std"]) for x in c2c])
    c2c.sort(key=lambda z2: -(z2["pctile"] or 0))
    cands = [x for x in c2c if x["n"] >= C2C_MIN_N and (x["pctile"] or 0) >= C2C_MIN_PCTILE
             and x["gap_now_pct"] >= C2C_MIN_GAP]
    await r.set("dcm:c2c:signal", json.dumps({
        "ts": now.isoformat(), "n": len(c2c), "candidates_n": len(cands),
        "params": {"min_n": C2C_MIN_N, "min_pctile": C2C_MIN_PCTILE, "min_gap_pct": C2C_MIN_GAP},
        "note": "收敛信号=gap_pct 7日分位(risk_spread_sample);SHADOW/HOUSE_RND,无执行消费者;"
                "归因走 pair.product=C2.C",
        "rows": c2c}, ensure_ascii=False), ex=3600)
    # ---- C2.C 决策层:腿向(逐所funding)+经济学(回本天数)+自动 DRY_RUN 提案 ----
    async def _fund(v, ul):
        raw = await r.hget(f"dcm:feed:funding:{v}", f"{ul}USDT")
        if not raw:
            return None
        try:
            j = json.loads(raw)
            ts = float(j.get("ts") or 0)
            if ts > 1e12:
                ts /= 1000.0
            if ts and now.timestamp() - ts > 3600:
                return None
            return float(j["daily_pct"]) if j.get("daily_pct") is not None else None
        except (ValueError, TypeError):
            return None

    costcfg = {}
    try:
        costcfg = json.loads(await r.get("dcm:c4:costcfg") or "{}")
    except Exception:  # noqa: BLE001
        pass

    def _perp_taker(v):
        return float((costcfg.get(v) or {}).get("perp_taker_bps") or 6.0)

    mgr_pairs = set()
    try:
        mcfg = json.loads(await r.get("dcm:exec:manager:config") or "{}")
        mgr_pairs = set((mcfg.get("pairs") or {}).keys())
    except Exception:  # noqa: BLE001
        pass

    decisions = []
    for c in cands:
        ul = c["symbol"][:-4] if c["symbol"].endswith("USDT") else c["symbol"]
        pv = {}
        for v in VENUES:
            fd2 = await _fund(v, ul)
            if fd2 is not None:
                pv[v] = fd2
        d = dict(c)
        if len(pv) >= 2:
            v_short = max(pv, key=pv.get)   # 空腿=funding最高所(空头收费)
            v_long = min(pv, key=pv.get)
            edge = pv[v_short] - pv[v_long]
            rt_bps = (_perp_taker(v_short) + _perp_taker(v_long)) * 2  # 双腿开+平
            be_days = (rt_bps / 100.0) / edge if edge > 1e-9 else None
            d.update({"venue_short": v_short, "venue_long": v_long,
                      "edge_daily_pct": round(edge, 4), "rt_cost_bps": round(rt_bps, 1),
                      "breakeven_days": round(be_days, 2) if be_days else None,
                      "funding_by_venue": {k: round(x, 4) for k, x in pv.items()}})
        # 提案闸+去重
        if c["symbol"] in mgr_pairs:
            d["proposal"] = "skip:already_held(manager pairs 已有该币,避免重复敞口)"
        elif len(pv) < 2:
            d["proposal"] = "skip:funding覆盖不足两所"
        elif (c["pctile"] or 0) < C2C_PROP_PCTILE or d.get("edge_daily_pct", 0) < C2C_PROP_EDGE \
                or (d.get("breakeven_days") or 99) > C2C_PROP_BE_DAYS:
            d["proposal"] = "skip:未过提案闸(分位/edge/回本)"
        else:
            dup = await pg.fetchval(
                "SELECT count(*) FROM dry_run_proposal WHERE symbol=$1 AND product='C2.C' "
                "AND state IN ('COOLDOWN','PENDING_APPROVAL','APPROVED') "
                "AND created_at > now() - interval '24 hours'", c["symbol"])
            if dup:
                d["proposal"] = "skip:24h内已有活跃C2.C提案"
            else:
                econ = {"c2c_signal": {k: d.get(k) for k in
                        ("gap_now_pct", "pctile", "zscore", "n", "edge_daily_pct",
                         "rt_cost_bps", "breakeven_days", "funding_by_venue")},
                        "snapped_at": int(now.timestamp())}
                pid = await pg.fetchval(
                    "INSERT INTO dry_run_proposal(symbol,product,venue_long,venue_short,"
                    "target_notional,econ_snapshot,state,cooldown_until,created_by,note) "
                    "VALUES($1,'C2.C',$2,$3,$4,$5::jsonb,'COOLDOWN',now()+interval '900 seconds',"
                    "'c2c-signal','收敛信号自动提案:审批后走fastlane(product=C2.C归因),不自动armed') "
                    "RETURNING id", c["symbol"], d["venue_long"], d["venue_short"],
                    C2C_PROP_NOTIONAL, json.dumps(econ, ensure_ascii=False))
                d["proposal"] = f"filed:#{pid}"
        decisions.append(d)

    await r.set("dcm:c2c:candidates", json.dumps({
        "ts": now.isoformat(), "mode": "SHADOW→ADVISORY(自动提案,人工审批)",
        "prop_gate": {"pctile": C2C_PROP_PCTILE, "edge_pct": C2C_PROP_EDGE,
                      "breakeven_days": C2C_PROP_BE_DAYS, "notional": C2C_PROP_NOTIONAL},
        "rows": decisions}, ensure_ascii=False), ex=3600)

    # ---- C3.R 持久化 + 决策层(净差∩可借性;执行域=coin组,本层只产候选) ----
    c3n = 0
    c3_cands = []
    raw = await r.get("dcm:lending:ranking")
    if raw:
        rank = json.loads(raw)
        age = now.timestamp() - float(rank.get("ts") or 0)
        if age < 1800:
            top = rank.get("top") or []
            await pg.executemany(
                "INSERT INTO c3r_ranking_sample(coin,net_daily_pct,funding_abs,earn,borrow,rank) "
                "VALUES($1,$2,$3,$4,$5,$6)",
                [(t["coin"], t.get("net_daily_pct"), t.get("funding_abs"),
                  t.get("earn"), t.get("borrow"), i + 1) for i, t in enumerate(top[:20])])
            c3n = min(len(top), 20)
            for i, t in enumerate(top[:20]):
                net = float(t.get("net_daily_pct") or 0)
                if net < C3R_MIN_NET:
                    break
                braw = await r.hget("dcm:borrow:avail", f"binance:{t['coin']}")
                amt, borrowable = None, None
                if braw:
                    try:
                        bj = json.loads(braw)
                        if now.timestamp() - float(bj.get("ts") or 0) < 7200:
                            amt = float(bj.get("amount") or 0)
                            borrowable = amt > 0
                    except (ValueError, TypeError):
                        pass
                c3_cands.append({"coin": t["coin"], "rank": i + 1,
                                 "net_daily_pct": net,
                                 "funding_abs": t.get("funding_abs"),
                                 "earn": t.get("earn"), "borrow": t.get("borrow"),
                                 "borrow_avail": amt, "borrowable": borrowable})
    await r.set("dcm:c3r:candidates", json.dumps({
        "ts": now.isoformat(), "min_net_daily_pct": C3R_MIN_NET,
        "note": "净差∩可借性(dcm:borrow:avail,仅binance覆盖,>2h龄弃);执行域=coin-py组,"
                "本层只产候选不执行;borrowable=false 即『高费差币无券』命门实况",
        "rows": c3_cands}, ensure_ascii=False), ex=3600)

    await r.aclose()
    await pg.close()
    print(f"c2c n={len(c2c)} cands={len(cands)} | c3r persisted={c3n} cands={len(c3_cands)}")
    for x in decisions[:5]:
        print(f"  C2C {x['symbol']:12s} 分位={x['pctile']:.2f} edge={x.get('edge_daily_pct')}%/d "
              f"{x.get('venue_long','?')}多/{x.get('venue_short','?')}空 回本={x.get('breakeven_days')}d "
              f"→ {x.get('proposal')}")
    for x in c3_cands[:6]:
        print(f"  C3R {x['coin']:8s} 净={x['net_daily_pct']:+7.3f}%/d 可借={x['borrowable']} "
              f"额度={x['borrow_avail']}")


if __name__ == "__main__":
    asyncio.run(main())
