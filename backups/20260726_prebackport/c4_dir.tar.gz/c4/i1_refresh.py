"""I1 合约矩阵日度刷新 —— 复用生产采集/写入代码(app.i1_collectors + ops._upsert_instruments),
不另造轮子避免口径漂移。公开端点无需 key。单所失败隔离。"""
import os
import sys
import asyncio

sys.path.insert(0, "/data/mix/backend")

import asyncpg  # noqa: E402

VENUES = ["binance", "bybit", "okx", "gate", "bitget", "hyperliquid"]


async def main():
    from app import i1_collectors
    from app.routers import ops as opsmod
    pool = await asyncpg.create_pool(os.environ["MIX_MAIN_DSN"], min_size=1, max_size=2)
    res, errs = {}, {}
    for v in VENUES:
        try:
            if v == "binance":
                res[v] = (await opsmod._populate_binance_instruments(pool))["upserted"]
            else:
                res[v] = await opsmod._upsert_instruments(pool, await i1_collectors.collect(v))
        except Exception as e:  # noqa: BLE001 单所失败隔离
            errs[v] = repr(e)[:150]
    # 资金费元数据补采(best-effort;内部走 ds.rds() 需 REDIS_URL)
    fr, fe = {}, {}
    for v in VENUES:
        try:
            fr[v] = await opsmod._enrich_funding_meta(pool, v)
        except Exception as e:  # noqa: BLE001
            fe[v] = repr(e)[:100]
    await pool.close()
    print(f"i1_refresh upserted={res} errors={errs} funding_meta={list(fr)} funding_errs={fe}")
    if errs and not res:
        raise SystemExit(1)


if __name__ == "__main__":
    asyncio.run(main())
