# P0 BTC 5m strategy audit and Paper shadow

Generated UTC: 2026-09-12T15:31:11.033874+00:00

## Safety

- Paper shadow uses isolated database p0-shadow-btc.db.
- shadow_live_orders=0.
- BTC_LIVE_ENABLED=False; ETH_TRADING_ENABLED=False.

## Config (redacted)
{
  "MIN_NET_EDGE": "0.01",
  "LATE_EDGE_ENTRY_ENABLED": "false",
  "LATE_EDGE_ENTRY_MIN_PRICE": "0.840",
  "LATE_EDGE_ENTRY_MAX_PRICE": "0.900",
  "BTC_LIVE_ENABLED": "false",
  "ETH_TRADING_ENABLED": "false",
  "PRICE_SIGNAL_SOURCE": "rtds",
  "RTDS_MAX_AGE_SEC": "5",
  "RTDS_STALE_MAX_AGE_SEC": "12"
}

## Paper entry audit

| Asset | Entries | Resolved | Wins | Losses | Win rate | Avg price | Gross PnL | Net PnL after assumed 0.07/share fee |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| BTC | 26 | 25 | 25 | 0 | 100.00% | 0.9800 | 1.0153 | -2.5382 |
| ETH | 17 | 16 | 16 | 0 | 100.00% | 0.9800 | 1.1396 | -2.8490 |

## Shadow runtime

{
  "path": "/home/ec2-user/polymarketbot-auto/p0-shadow-btc.db",
  "exists": true,
  "tables": {
    "decisions": {
      "rows": 98,
      "columns": [
        "id",
        "ts",
        "asset",
        "market_slug",
        "condition_id",
        "token_id",
        "side",
        "t_remaining",
        "ask_price",
        "ask_size",
        "action",
        "reason",
        "dry_run"
      ]
    },
    "orders": {
      "rows": 0,
      "columns": [
        "id",
        "ts",
        "asset",
        "market_slug",
        "condition_id",
        "token_id",
        "side",
        "size",
        "price",
        "order_id",
        "status",
        "filled_size",
        "error",
        "entry_rule",
        "dry_run"
      ]
    },
    "resolutions": {
      "rows": 0,
      "columns": [
        "condition_id",
        "winning_token",
        "resolved_ts"
      ]
    }
  },
  "range": [
    "2026-09-12T15:28:25.109151+00:00",
    "2026-09-12T15:30:00.002320+00:00"
  ],
  "decision_actions": [
    {
      "action": "SKIP_PRICE",
      "n": 38
    },
    {
      "action": "SKIP_TIME",
      "n": 36
    },
    {
      "action": "SKIP_EDGE",
      "n": 24
    }
  ],
  "order_statuses": [],
  "dry_run_counts": {},
  "missing_telemetry_columns": {
    "decisions": [
      "fee",
      "fee_rate",
      "slippage",
      "quote_age",
      "latency_ms",
      "filled_size",
      "fill_ratio",
      "settlement_source"
    ],
    "orders": [
      "fee",
      "fee_rate",
      "slippage",
      "quote_age",
      "latency_ms",
      "fill_ratio",
      "settlement_source"
    ],
    "resolutions": [
      "fee",
      "fee_rate",
      "slippage",
      "quote_age",
      "latency_ms",
      "filled_size",
      "fill_ratio",
      "settlement_source"
    ]
  },
  "paper_entry_audit": {
    "BTC": {
      "paper_entries": 0,
      "resolved_entries": 0,
      "unresolved_entries": 0,
      "wins": 0,
      "losses": 0,
      "win_rate": null,
      "avg_entry_price": null,
      "min_entry_price": null,
      "max_entry_price": null,
      "gross_pnl_before_fee": 0,
      "fee_assumption_per_share": 0.07,
      "net_pnl_after_0_07_fee_assumption": 0,
      "resolved_notional": 0,
      "entry_rules": []
    },
    "ETH": {
      "paper_entries": 0,
      "resolved_entries": 0,
      "unresolved_entries": 0,
      "wins": 0,
      "losses": 0,
      "win_rate": null,
      "avg_entry_price": null,
      "min_entry_price": null,
      "max_entry_price": null,
      "gross_pnl_before_fee": 0,
      "fee_assumption_per_share": 0.07,
      "net_pnl_after_0_07_fee_assumption": 0,
      "resolved_notional": 0,
      "entry_rules": []
    }
  }
}

## Conclusion

The audit confirms the data path and isolated Paper process only. It does not prove positive net EV. Add fee, slippage, quote age, latency, fill, and settlement telemetry before strategy changes.